<?php

defined('PHPFOX') or exit('NO DICE!');

?>
{foreach from=$aMostViewed name=aMiniVideo item=aMiniVideo}
{template file='videochannel.block.mini'}
{/foreach}


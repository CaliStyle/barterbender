<?php 

defined('PHPFOX') or exit('NO DICE!'); 

?>
<div class="video_user_link_holder"><a href="#" class="video_user_link" rel="{$aVideo.user_id}"><span>{$aVideo.full_name}</span>: {$aVideo.total_user_videos|number_format} Videos</a></div>
<div class="video_user_bar"><div class="video_user_bar_loader">Loading...</div></div>
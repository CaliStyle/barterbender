<?php
/**
 * [PHPFOX_HEADER]
 */

defined('PHPFOX') or exit('NO DICE!');

class Videochannel_Service_Category_Process extends Phpfox_Service 
{
	/**
	 * Class constructor
	 */
	private $_iStringLengthCategoryName;

	public function __construct()
	{	
		$this->_sTable = Phpfox::getT('channel_category');
		$this->_iStringLengthCategoryName = 255;
	}
	
	public function add($aVals)
	{
        $aLanguages = Language_Service_Language::instance()->getAll();
        $name = $aVals['name_'.$aLanguages[0]['language_id']];
        $phrase_var_name = 'videochannel_category_' . md5('Video Channel Category'. $name . PHPFOX_TIME);

        $iLimit = 40;

        //Add phrases
        $aText = [];
        foreach ($aLanguages as $aLanguage){
            if (isset($aVals['name_' . $aLanguage['language_id']]) && !empty($name = strip_tags($aVals['name_' . $aLanguage['language_id']]))){
                Phpfox::getService('ban')->checkAutomaticBan($aVals['name_' . $aLanguage['language_id']]);
                $aText[$aLanguage['language_id']] = $name;
            }
            else {
                return Phpfox_Error::set((_p('provide_a_language_name_name', ['language_name' => $aLanguage['title']])));
            }

            if (strlen($aVals['name_' . $aLanguage['language_id']]) > $this->_iStringLengthCategoryName) {
                return Phpfox_Error::set(_p('category_language_name_name_must_beLess_than_limit', ['limit' => $iLimit, 'language_name' => $aLanguage['title']]));
            }
        }

        $aValsPhrase = [
            'var_name' => $phrase_var_name,
            'text' => $aText
        ];

        $finalPhrase = Language_Service_Phrase_Process::instance()->add($aValsPhrase);
		
		$iId = $this->database()->insert($this->_sTable, array(
				'parent_id' => (!empty($aVals['parent_id']) ? (int) $aVals['parent_id'] : 0),
				'is_active' => 1,
				'name' => $finalPhrase,
				'time_stamp' => PHPFOX_TIME
			)
		);
		
		$this->cache()->remove('videochannel', 'substr');
		
		return $iId;
	}
	
	public function update($iId, $aVals)
	{
        if ($iId == $aVals['parent_id']) {
            return Phpfox_Error::set(_p('parent_category_and_child_is_the_same'));
        }

        $aLanguages = Language_Service_Language::instance()->getAll();

        // Update phrase
        if (Phpfox::isPhrase($aVals['name'])){
            foreach ($aLanguages as $aLanguage){
                if (isset($aVals['name_' . $aLanguage['language_id']]) && !empty($name = strip_tags($aVals['name_' . $aLanguage['language_id']]))){
                    Phpfox::getService('ban')->checkAutomaticBan($aVals['name_' . $aLanguage['language_id']]);

                    Language_Service_Phrase_Process::instance()->updateVarName($aLanguage['language_id'], $aVals['name'], $name);
                }
                else {
                    return Phpfox_Error::set((_p('provide_a_language_name_name', ['language_name' => $aLanguage['title']])));
                }

                if (strlen($aVals['name_' . $aLanguage['language_id']]) > $this->_iStringLengthCategoryName) {
                    return Phpfox_Error::set(_p('category_language_name_name_must_beLess_than_limit', ['limit' => $this->_iStringLengthCategoryName, 'language_name' => $aLanguage['title']]));
                }
            }
        } else {
            $name = $aVals['name_'.$aLanguages[0]['language_id']];
            $phrase_var_name = 'videochannel_category_' . md5('Video Channel Category'. $name . PHPFOX_TIME);

            //Validate phrases
            $aText = [];
            foreach ($aLanguages as $aLanguage){
                if (isset($aVals['name_' . $aLanguage['language_id']]) && !empty($name = strip_tags($aVals['name_' . $aLanguage['language_id']]))){
                    Phpfox::getService('ban')->checkAutomaticBan($aVals['name_' . $aLanguage['language_id']]);
                    $aText[$aLanguage['language_id']] = $name;
                }
                else {
                    return Phpfox_Error::set((_p('provide_a_language_name_name', ['language_name' => $aLanguage['title']])));
                }

                if (strlen($aVals['name_' . $aLanguage['language_id']]) > $this->_iStringLengthCategoryName) {
                    return Phpfox_Error::set(_p('category_language_name_name_must_beLess_than_limit', ['limit' => $this->_iStringLengthCategoryName, 'language_name' => $aLanguage['title']]));
                }
            }

            $aValsPhrase = [
                'var_name' => $phrase_var_name,
                'text' => $aText
            ];

            $aVals['name'] = Language_Service_Phrase_Process::instance()->add($aValsPhrase);
        }


        $aVideos = $this->database()->select('video_id')->from(Phpfox::getT('channel_category_data'))->where('category_id = ' . (int) $iId)->execute('getSlaveRows');
        $sStrVideo = '';
        foreach($aVideos as $Video)
        {
            if(!empty($Video['video_id']))
            {
                $sStrVideo .= 	$Video['video_id'].',';
            }
        }
        if($sStrVideo) {
            $sStrVideo = substr($sStrVideo, 0, strlen($sStrVideo) - 1);
            $this->database()->update(Phpfox::getT('channel_category_data'), array('category_id' => (int)$aVals['parent_id']), ' category_id !=' . (int)$iId . ' AND video_id IN (' . $sStrVideo . ')');
        }
		
		$this->database()->update($this->_sTable, array('name' => Phpfox::getLib('parse.input')->clean($aVals['name'], 255), 'parent_id' => (int) $aVals['parent_id']), 'category_id = ' . (int) $iId);
		$this->cache()->remove('videochannel', 'substr');
		
		return true;
	}
	
	public function delete($iId)
	{
	  
		$this->database()->update($this->_sTable, array('parent_id' => 0), 'parent_id = ' . (int) $iId);
		
                /* http://www.phpfox.com/tracker/view/6349/ 
                 * To fix this we can create a setting letting the admin choose 
                 * whether to delete the videos belonging to the category being
                 * deleted or to simply remove the category from them
                 */
                if ( false /* Phpfox::getParam('videochannel.keep_video_after_category_delete') */)
                {
                    $this->database()->delete($this->_sTable, 'category_id = ' . (int) $iId);
                    $this->database()->delete(Phpfox::getT('channel_category_data'), 'category_id = ' . (int)$iId);
                    $this->cache()->remove('videochannel', 'substr');
                    return true;
                }
		$aVideos = $this->database()->select('m.video_id, m.user_id, m.image_path')
			->from(Phpfox::getT('channel_category_data'), 'mcd')
			->join(Phpfox::getT('channel_video'), 'm', 'm.video_id = mcd.video_id')
			->where('mcd.category_id = ' . (int) $iId)
			->execute('getRows');		
			
		foreach ($aVideos as $aVideo)
		{
			Phpfox::getService('videochannel.process')->delete($aVideo['video_id'], $aVideo);
		}
		$aVideos = $this->database()->select('m.video_id, m.user_id, m.image_path')
			->from(Phpfox::getT('channel_category_data'), 'mcd')
			->join(Phpfox::getT('channel_video'), 'm', 'm.video_id = mcd.video_id')
			->where('mcd.category_id = ' . (int) $iId)
			->execute('getRows');		
			
		foreach ($aVideos as $aVideo)
		{
			Phpfox::getService('videochannel.process')->delete($aVideo['video_id'], $aVideo);
		}
		
		$aChannels = $this->database()->select('m.channel_id')
			->from(Phpfox::getT('channel_category_data'), 'mcd')
			->join(Phpfox::getT('channel_channel'), 'm', 'm.channel_id = mcd.channel_id')
			->where('mcd.category_id = ' . (int) $iId)
			->execute('getRows');
		
		foreach ($aChannels as $aChannel)
		{
			Phpfox::getService('videochannel.channel.process')->deleteChannel($aChannel['channel_id'],true);
		}
			
		$this->database()->delete($this->_sTable, 'category_id = ' . (int) $iId);
		
		$this->cache()->remove('videochannel', 'substr');
		
		return true;
	}
	
	public function updateOrder($aVals)
	{
		foreach ($aVals as $iId => $iOrder)
		{
			$this->database()->update($this->_sTable, array('ordering' => $iOrder), 'category_id = ' . (int) $iId);
		}
		
		$this->cache()->remove('videochannel', 'substr');
		
		return true;
	}
	
	/**
	 * If a call is made to an unknown method attempt to connect
	 * it to a specific plug-in with the same name thus allowing 
	 * plug-in developers the ability to extend classes.
	 *
	 * @param string $sMethod is the name of the method
	 * @param array $aArguments is the array of arguments of being passed
	 */
	public function __call($sMethod, $aArguments)
	{
		/**
		 * Check if such a plug-in exists and if it does call it.
		 */
		if ($sPlugin = Phpfox_Plugin::get('videochannel.service_category_process__call'))
		{
			return eval($sPlugin);
		}
			
		/**
		 * No method or plug-in found we must throw a error.
		 */
		Phpfox_Error::trigger('Call to undefined method ' . __CLASS__ . '::' . $sMethod . '()', E_USER_ERROR);
	}

    public function updateActivity($iId, $iType)
    {
        Phpfox::isAdmin(true);
        $this->database()->update(($this->_sTable), array('is_active' => (int)($iType == '1' ? 1 : 0)), 'category_id' . ' = ' . (int)$iId);

        $this->cache()->remove('videochannel_category', 'substr');
    }
}

?>
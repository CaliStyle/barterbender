<?php

defined('PHPFOX') or exit('NO DICE!');

?>
{foreach from=$aMostDiscussed name=aMiniVideo item=aMiniVideo}
{template file='videochannel.block.mini'}
{/foreach}

<?php 
 
defined('PHPFOX') or exit('NO DICE!'); 

?>
<form method="post" action="{url link='admincp.videochannel.add'}">
{if $bIsEdit}
	<div><input type="hidden" name="id" value="{$aForms.category_id}" /></div>
    <div><input type="hidden" name="val[name]" value="{$aForms.name}" /></div>
{/if}

    <div class="panel panel-default">
        <div class="panel-heading">
            <div class="panel-title">
                {phrase var='videochannel.video_category_details'}
            </div>
        </div>
        <div class="panel-body">
            <div class="form-group">
                <label for="">{phrase var='videochannel.parent_category'}:</label>
                {$selectBox}
            </div>

            {foreach from=$aLanguages item=aLanguage}
            <div class="form-group">
                <label for="">{required} {phrase var='title'}&nbsp;<strong>{$aLanguage.title}</strong>:</label>
                {assign var='value_name' value="name_"$aLanguage.language_id}
                <input class="form-control" type="text" name="val[name_{$aLanguage.language_id}]" value="{value id=$value_name type='input'}" size="30" />
            </div>
            {/foreach}
        </div>

        <div class="panel-footer">
            <input type="submit" value="{phrase var='videochannel.submit'}" class="btn btn-primary" />
        </div>
    </div>
</form>
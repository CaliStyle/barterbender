<?php

defined('PHPFOX') or exit('NO DICE!');

?>

{foreach from=$aFeatured item=aMiniVideo}
{template file='videochannel.block.mini'}
{/foreach}

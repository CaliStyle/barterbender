<?php 
defined('PHPFOX') or exit('NO DICE!');
?>

<div id="welcome_message">
    <div class="welcome-content">
        <div class="welcome-title custom_flavor_content" style="white-space: pre-wrap;">{$sWelcomeContent}</div>
        <div class="welcome-image"><img src="{$image.image}"></div>
    </div>
</div>
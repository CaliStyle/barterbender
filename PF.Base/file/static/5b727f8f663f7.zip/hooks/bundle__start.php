<?php

$aBundleScripts[] = [
    'autoload.js' => 'flavors_yncfbclone',
    'autoload.css' => 'flavors_yncfbclone',
];

$aBundleScripts[] = [
    'autoload.js' => 'flavors_bootstrap',
];

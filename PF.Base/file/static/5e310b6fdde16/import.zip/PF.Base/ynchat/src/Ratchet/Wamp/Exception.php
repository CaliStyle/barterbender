<?php
namespace Ratchet\Wamp;

class Exception extends \Exception {
}

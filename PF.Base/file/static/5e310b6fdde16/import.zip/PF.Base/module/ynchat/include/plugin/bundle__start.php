<?php

$aBundleScripts[] = [
    'ynchat.css' => 'ynchat',
    'ynchatmobile.css' => 'ynchat',
    'ynchat.js' => 'ynchat',
    'ynhelper.js' => 'ynchat',
];

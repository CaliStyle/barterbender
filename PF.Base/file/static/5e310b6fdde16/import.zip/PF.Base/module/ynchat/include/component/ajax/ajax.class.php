<?php
/**
 * [PHPFOX_HEADER]
 */

defined('PHPFOX') or exit('NO DICE!');

class Ynchat_Component_Ajax_Ajax extends Phpfox_Ajax
{

}
?>
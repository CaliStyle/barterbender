    <?php
defined('PHPFOX') or exit('NO DICE!');
define("YNAP_START_YEAR",2017);
define("YNAP_END_YEAR",2040);

class Ynadvancedpayment_Component_Controller_GoPay extends Phpfox_Component
{
	public function process()
	{

		// get data for GoPay
		$aTransactionItem = Phpfox::getLib('session')->get('item_info');

		if($this->request()->get('item_name')){
			$aTransactionItem['item_name'] = $this->request()->get('item_name');
			$aTransactionItem['item_number'] = $this->request()->get('item_number');
			$aTransactionItem['currency_code'] = $this->request()->get('currency_code');
			$aTransactionItem['notify_url'] = $this->request()->get('notify_url');
			$aTransactionItem['return'] = $this->request()->get('return');
			$aTransactionItem['cmd'] = $this->request()->get('cmd');
			$aTransactionItem['amount'] = round($this->request()->get('amount'));
			$aTransactionItem['recurring_cost'] = $this->request()->get('recurring_cost');
			$aTransactionItem['recurrence'] = $this->request()->get('recurrence');
			$aTransactionItem['recurrence_type'] = $this->request()->get('recurrence_type');

			Phpfox::getLib('session')->set('item_info',$aTransactionItem);

		}

		if(empty($aTransactionItem)){
                return $this->url()->send('',array(),Phpfox::getPhrase('ynadvancedpayment.transaction_is_expired'));
		}

		if($aTransactionItem['currency_code'] != 'EUR' && $aTransactionItem['currency_code'] != 'CZK'){
                return $this->url()->send('',array(),Phpfox::getPhrase('ynadvancedpayment.gopay_getway_only_support_eur_czk'));
		}

		/*if(!isset($aData['goid']) || empty($aData['goid'])){
			return $this->url()->send($aParts[0], null, null);
		}*//*==> temporary disabled*/

		/*$aGoPaySetting = Phpfox::getService('ynadvancedpayment.paymentgateway')->getGatewayById('gopay', false);
        $aToken = Phpfox::getService('ynadvancedpayment.gopayaim')->createToken();*/

		/*this is quick test*/
/*		$aShippingInfo = '{"first_name":"Tri","last_name":"Ly Minh","company":"Developer YouNet","address":"2nd floor, Lu Gia Plaza, 70 Lu Gia St., Dist. 11, HCM City","city":"Ho Chi Minh, Vietnam","country_code":"Vi\u1ec7t Nam","state":"TPHCM","zip":"70000","phone":"(123)123-1234","fax":"","email_address":"lmtkg1992@gmail.com","credit_card_number":"6771960000000033","CVV2":"123","expiration_month":"01","expiration_year":"2014","confirm":"Confirm Payment","goid":"app01@eshop.cz","secure_key":"AAAbbbDc","is_test":"1","item_name":"package|","item_number":"directory|10","currency_code":"USD","notify_url":"http:\/\/product-dev.younetco.com\/trilm\/phpfox377x2\/fox\/upload\/index.php?do=\/api\/gateway\/callback\/gopay\/","return":"http:\/\/product-dev.younetco.com\/trilm\/phpfox377x2\/fox\/upload\/index.php?do=\/directory\/detail\/21\/fds\/businesspayment_done\/","cmd":"not_recurring","amount":"5.00","recurring_cost":"","recurrence":"","recurrence_type":"","total":"5.00"}';
        $aShippingInfo = json_decode($aShippingInfo,true);

		$aDataEncode = '{"goid":"8767728948","client_id":"1373654271","secure_key":"Lxy7RCec","is_test":"1","item_name":"package|","item_number":"directory|17","currency_code":"USD","notify_url":"http:\/\/product-dev.younetco.com\/trilm\/phpfox377x2\/fox\/upload\/index.php?do=\/api\/gateway\/callback\/gopay\/","return":"http:\/\/product-dev.younetco.com\/trilm\/phpfox377x2\/fox\/upload\/index.php?do=\/directory\/detail\/28\/fsd\/businesspayment_done\/","cmd":"not_recurring","amount":"5.00","recurring_cost":"","recurrence":"","recurrence_type":""}'; 
		$aData =  json_decode($aDataEncode,true);
    	
    	$aTransactionItemForTest = '{"item_name":"lmtkg1","item_number":"10","currency_code":"CZK","notify_url":"http:\/\/product-dev.younetco.com\/trilm\/phpfox377x2\/fox\/upload\/index.php?do=\/api\/gateway\/callback\/gopay\/","return":"http:\/\/product-dev.younetco.com\/trilm\/phpfox377x2\/fox\/upload\/index.php?do=\/advancedmarketplace\/invoice\/payment_done\/","cmd":"not_recurring","amount":"20","recurring_cost":"","recurrence":"","recurrence_type":"","first_name":"Tri","last_name":"LyMinh","address":"133\/1,duong Phu Hoa,phuong 8,quan Tan Binh","city":"HCM","country_code":"VietNam","zip":"70000","phone":"+420777456123","email_address":"lmtkg1992@gmail.com","payment_method":"bank_transfer","confirm":"ConfirmPayment"}';
		$aTransactionItemForTest =  json_decode($aTransactionItemForTest,true);
		$aCreatedPayment = Phpfox::getService('ynadvancedpayment.gopayaim')->process_payment($aTransactionItemForTest);
*/
		/*echo '<pre>';
		print_r($aToken);
		die;*/
    	/*==> for testing*/

		$aValidationParam = $this->_getValidationParams();
        $oValid = Phpfox::getLib('validator')->set(array(
                'sFormName' => 'ynap_gopay_form',
                'aParams' => $aValidationParam
            )
        );

        if ($this->_checkIfSubmittingAForm()) {
            $aVals = $this->request()->getArray('val');
            
            $aValidationParam = $this->_getValidationParams($aVals);

            $oValid = Phpfox::getLib('validator')->set(array(
                    'sFormName' => 'ynap_gopay_form',
                    'aParams' => $aValidationParam
                )
            );

            $check2 = $oValid->isValid($aVals);
            $check1 = $this->_verifyCustomForm($aVals);

            if ($check1 && $check2)
            {
				Phpfox::getService('ynadvancedpayment.gopayaim')->process_payment($aVals);

            }
        }

		$months = array(
			"01"	=> Phpfox::getPhrase('core.january'),
			"02"	=> Phpfox::getPhrase('core.february'),
			"03"	=> Phpfox::getPhrase('core.march'),
			"04"	=> Phpfox::getPhrase('core.april'),
			"05"	=> Phpfox::getPhrase('core.may'),
			"06"	=> Phpfox::getPhrase('core.june'),
			"07"	=> Phpfox::getPhrase('core.july'),
			"08"	=> Phpfox::getPhrase('core.august'),
			"09"	=> Phpfox::getPhrase('core.september'),
			"10"	=> Phpfox::getPhrase('core.october'),
			"11"	=> Phpfox::getPhrase('core.november'),
			"12"	=> Phpfox::getPhrase('core.december')
			); 
		$years = array();
		for($i = YNAP_START_YEAR; $i < YNAP_END_YEAR; $i++){
			$years[$i] = $i;
		}

        $this->template()->setTitle((Phpfox::getPhrase('ynadvancedpayment.gopay_billing_info')))
            ->setFullSite()
            ->setPhrase(array(
            ))
            ->setHeader('cache', array(
                'jquery/plugin/jquery.highlightFade.js' => 'static_script',
                'switch_legend.js' => 'static_script',
                'switch_menu.js' => 'static_script',
                'quick_edit.js' => 'static_script',
                'progress.js' => 'static_script',
            ))
            ->assign(array(
                'sCreateJs' => $oValid->createJS(),
                'sGetJsForm' => $oValid->getJsForm(),
                'months' => $months,
                'years' => $years,
                'aData' => $aTransactionItem,
            ));		

	}

    private function _verifyCustomForm($aVals)
    {
    	$result = true;
        /*if(isset($aVals['phone'])) {
			if(!preg_match("/^\([0-9]{3}\)[0-9]{3}-[0-9]{4}$/", $aVals['phone'])) 
			{
				Phpfox_Error::set(Phpfox::getPhrase('ynadvancedpayment.please_enter_a_valid_phone_number'));			
				$result = false;
			}
        }*/
        if(isset($aVals['email_address'])) {/*
	        #verify email
	        $email_pattern = '/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/i';
	        if(!preg_match($email_pattern, $aVals['email_address']))
	        {
	            Phpfox_Error::set(Phpfox::getPhrase('ynadvancedpayment.email_format_is_not_valid'));
	            $result = false;
	        }
        */}

        return $result;
    }	

    private function _checkIfSubmittingAForm() {
        if ($this->request()->getArray('val')) {
            return true;
        } else {
            return false;
        }
    }	

    private function _getValidationParams($aVals = array()) {

        $aParam = array(/*
            'first_name' => array(
                'def' => 'required',
                'title' => Phpfox::getPhrase('ynadvancedpayment.please_fill_first_name'),
            ),
            'last_name' => array(
                'def' => 'required',
                'title' => Phpfox::getPhrase('ynadvancedpayment.please_fill_last_name'),
            ),
            'address' => array(
                'def' => 'required',
                'title' => Phpfox::getPhrase('ynadvancedpayment.please_fill_address'),
            ),
            'city' => array(
                'def' => 'required',
                'title' => Phpfox::getPhrase('ynadvancedpayment.please_fill_city'),
            ),
            'country_code' => array(
                'def' => 'required',
                'title' => Phpfox::getPhrase('ynadvancedpayment.please_fill_country'),
            ),
            'zip' => array(
                'def' => 'required',
                'title' => Phpfox::getPhrase('ynadvancedpayment.please_fill_zip_code'),
            ),
            'phone' => array(
                'def' => 'required',
                'title' => Phpfox::getPhrase('ynadvancedpayment.please_enter_a_valid_phone_number'),
            )
        */);

        return $aParam;
    }


	/**
	 * Garbage collector. Is executed after this class has completed
	 * its job and the template has also been displayed.
	 */
	public function clean()
	{
		(($sPlugin = Phpfox_Plugin::get('ynadvancedpayment.component_controller_authorizenet_clean')) ? eval($sPlugin) : false);
	}

}

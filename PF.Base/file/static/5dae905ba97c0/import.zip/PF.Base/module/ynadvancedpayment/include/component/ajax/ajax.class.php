<?php

class Ynadvancedpayment_Component_Ajax_Ajax extends Phpfox_Ajax
{
	
}
?>
<div style="position: relative !important; height: 30px; margin-left: 30px" class='yc_entry_next_prev'>
	<b> <a href="#" onclick="$Core.box('contest.showInvitePopup',800,'&contest_id={$aEntryViewTemplateParam.aEntry.contest_id}&entry_id={$aEntryViewTemplateParam.aEntry.entry_id}'); return false;">{phrase var='contest.invite_friends_to_view_this_campaign'}</a> </b>
</div>

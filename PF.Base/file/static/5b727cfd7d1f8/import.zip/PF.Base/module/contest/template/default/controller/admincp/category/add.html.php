<?php

defined('PHPFOX') or exit('NO DICE!');

?>
<form method="post" action="{url link='admincp.contest.category.add'}">
    <div class="panel panel-default">
    {if $bIsEdit}
        <div><input type="hidden" name="id" value="{$aForms.category_id}" /></div>
        <div><input type="hidden" name="val[name]" value="{$aForms.name}" /></div>
    {/if}
        <div class="panel-heading">
            {phrase var='contest_category_detail'}
        </div>
        <div class="panel-body">
            <div class="form-group">
                <label for="">{phrase var='parent_category'}:</label>
                <select name="val[parent_id]" class="form-control">
                    <option value="">{phrase var='select_form_select'}:</option>
                    {$sOptions}
                </select>
            </div>
            {foreach from=$aLanguages item=aLanguage}
            <div class="form-group">
                <label for="">{phrase var='title'}&nbsp;<strong>{$aLanguage.title}</strong>:</label>
                {assign var='value_name' value="name_".$aLanguage.language_id}
                <input type="text" name="val[name_{$aLanguage.language_id}]" value="{value id=$value_name type='input'}" class="form-control"/>
            </div>
            {/foreach}
        </div>
        <div class="panel-footer">
            <input type="submit" value="{phrase var='contest.submit'}" class="button btn-primary" />
        </div>
    </div>
</form>
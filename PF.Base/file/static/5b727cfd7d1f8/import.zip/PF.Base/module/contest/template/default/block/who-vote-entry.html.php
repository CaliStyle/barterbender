<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>

{foreach from=$aVotes item=aVote}
    {img user=$aVote suffix='_50_square' max_width=50 max_height=50}
{/foreach}
<?php

defined('PHPFOX') or exit('NO DICE!');
?>
<!-- Main entry -->
<div class="yc_small_item">
	<div class="item_left" onclick="window.location.href='{permalink module='contest' id=$aItem.contest_id title=$aItem.contest_name}'" style="background-image:url('{img return_url=true server_id=$aItem.server_id path='core.url_pic' file="contest/".$aItem.image_path suffix=''}');">
	</div>
	<div class="item_right">
		<p>
			<a class="small_title" href="{permalink module='contest' id=$aItem.contest_id title=$aItem.contest_name}" title="{$aItem.contest_name|clean}">
				{$aItem.contest_name|clean}
			</a>
			<div class="extra_info">
				<p>{phrase var='contest.participants'}: {$aItem.total_participant}</p>
				<p>{phrase var='contest.entries'}: {$aItem.total_entry}</p>
				<p>{phrase var='contest.end'}: {$aItem.end_time_parsed}</p>
			</div>
		</p>
	</div>
</div>

<div id="js_block_border_contest_contest_statics">
	<ul class="yc_view_statistic">
		<li class="ycstat ycparticipants">
			<span>{phrase var='contest.participants'}:</span>
			<b>{$aItem.total_participant}</b>
		</li>
		<li class="ycstat ycentries">
			<span>{phrase var='contest.entries'}:</span>
			<b>{$aItem.total_entry}</b>
		</li>
		<li class="ycstat yclikes">
			<span>{phrase var='contest.likes'}:</span>
			<b>{$aItem.total_like}</b>
		</li>
		<li class="ycstat ycviews">
			<span>{phrase var='contest.views'}:</span>
			<b>{$aItem.total_view}</b>
		</li>
	</ul>
</div>

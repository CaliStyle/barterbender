<ul class="statistic">
    <li>
        {phrase var='contest.all_contests'}: <strong>{$aStatistic.total_contests}</strong>
    </li>
    <li>
        {phrase var='contest.participants'}: <strong>{$aStatistic.total_participants}</strong>
    </li>
    <li>
        {phrase var='contest.blog_contest'}: <strong>{$aStatistic.total_blog_contests}</strong>
    </li>
    <li>
        {phrase var='contest.music_contest'}: <strong>{$aStatistic.total_music_contests}</strong>
    </li>
    <li>
        {phrase var='contest.video_contest'}: <strong>{$aStatistic.total_video_contests}</strong>
    </li>
    <li>
        {phrase var='contest.photo_contest'}: <strong>{$aStatistic.total_photo_contests}</strong>
    </li>
</ul>
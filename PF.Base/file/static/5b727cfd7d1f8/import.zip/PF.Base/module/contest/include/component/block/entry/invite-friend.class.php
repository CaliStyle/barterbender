<?php

defined('PHPFOX') or exit('NO DICE!');

class Contest_Component_Block_Entry_Invite_Friend extends Phpfox_component{

	public function process ()
	{
		
	}
}
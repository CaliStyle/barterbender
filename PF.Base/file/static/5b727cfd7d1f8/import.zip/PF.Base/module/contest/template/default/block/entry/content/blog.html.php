{if Phpfox::isModule('ynblog') && $aBlogEntry.image_path}
<?php $this->_aVars['appPath'] = Phpfox::getParam('core.path_actual').'PF.Site/Apps/yn_blog/'; ?>
<div class="yncontest_preview_ynblog">
    <div class="ynadvblog_avatar">
        <a href="" class="ynadvblog_cover_inner item_image full" style="background-image: url(
                {if $aBlogEntry.image_path}
                    {img server_id=$aBlogEntry.server_id path='core.url_pic' file=$aBlogEntry.image_path suffix='_big' return_url=true}
                {else}
                    {$appPath}/assets/image/blog_photo_default.png
                {/if}
            )">
        </a>
    </div>
</div>
{/if}

{$aBlogEntry.blog_content_parsed}

{if isset($aBlogEntry) && $aBlogEntry.total_attachment}
	{if $bIsPreview}
		 {module name='contest.entry.content.attachment.list' sType=blog iItemId=$aBlogEntry.blog_id}
	{else}
	    {module name='contest.entry.content.attachment.list' sType=contest_entry_blog iItemId=$aBlogEntry.entry_id}
	{/if}
{/if}


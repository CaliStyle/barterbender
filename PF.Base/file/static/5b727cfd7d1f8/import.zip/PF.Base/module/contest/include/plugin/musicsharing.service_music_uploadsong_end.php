<?php

Phpfox::getService('contest.contest')->handlerAfterAddingEntry('music', $song_id);

?>
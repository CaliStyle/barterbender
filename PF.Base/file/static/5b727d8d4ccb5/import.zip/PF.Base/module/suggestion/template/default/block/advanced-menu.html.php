<?php
/*
 * @copyright        [YouNet_COPYRIGHT]
 * @author           YouNet Company
 * @package          Module_Suggestion
 * @version          3.04
 *
 */
defined('PHPFOX') or exit('NO DICE!');
?>
<div class="suggestion-categories sub_section_menu">
	{$html}
</div>


{literal}
<script type="text/javascript">
	function showSub(id)
		{
			var ul = $('#'+id);
			if(ul.parent().hasClass('open'))
			{
				ul.parent().removeClass();
			}
			else{
				ul.parent().addClass('open');
			}
			
		}
</script>
{/literal}

{if Phpfox::isMobile() }
{literal}
<script type="text/javascript">
	$Behavior.supportMenuMobile = function(){
		var active = $('#suggestion_menu .active a').attr('id');
		var parent = '';
		if(active.substring(0,12) == 'view_friends'){
			parent = 'view_friends';
			active = active.substring(12);
		}
		if(active.substring(0,7) == 'view_my'){
			parent = 'view_my';
			active = active.substring(7);
		}

		$('#'+parent+' > a > span').append(' - '+ucfirst(active));
		
		if($('#'+parent).hasClass('open')) {
			$('#'+parent).removeClass('open');
		}
	};

	function ucfirst(string)
	{
	    return string.charAt(0).toUpperCase() + string.slice(1);
	}

</script>
{/literal}
{/if}
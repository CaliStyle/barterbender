<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<script lang="javascript">   
//    $Behavior.initAppendAvatar = function(){        
    //$.ajaxCall('suggestion.appendSelected');
    
//    $('span[id^="js_friend_"]').each(function(){        
//        var _id = $(this).attr('id').split("_");
//        if (_id.length>0){
//            _iUserId = _id[2];            
//            $.ajaxCall('suggestion.append_user_image','iUserId='+_iUserId);            
//        }
//    })};           
//    $Behavior.initAppendAvatar();
</script>

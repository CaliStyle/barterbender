<form id="yndirectory_promotebusiness" style="text-align: center;">
	<div>
		<div class="table_right">
			<textarea id="yndirectory_promotebusiness_badge_code_textarea" readonly="readonly" cols="40" rows="15" style="width:300px; height:150px;">{$sBadgeCode}</textarea>
		</div>

		<div class="clear" style="margin-bottom: 10px;"></div>
	</div>

	<div>
		<div id ="yndirectory_promotebusiness_iframe">{$sBadgeCode}</div>
	</div>
</form>


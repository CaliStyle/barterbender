<div id="yndirectory_business_detail_module_custompage" class="yndirectory_business_detail_module_custompage">	
	<div class="yndirectory-about-content">{$aCustomPage.contentpage_parsed|parse|convert}</div>
</div>

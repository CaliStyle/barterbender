<?php 


$_SESSION['aUserRoleDirectory'] = $aUser;

?>
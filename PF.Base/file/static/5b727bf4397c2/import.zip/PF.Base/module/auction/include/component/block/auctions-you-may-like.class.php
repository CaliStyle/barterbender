<?php

defined('PHPFOX') or exit('NO DICE!');

class Auction_Component_Block_Auctions_You_May_Like extends Phpfox_Component {

    public function process()
    {
        $aYnAuctionDetail = $this->getParam('aYnAuctionDetail');
        $aAuction = $aYnAuctionDetail['aAuction'];
        // Auctions you may like
        $aAuctionsYouMayLike = Phpfox::getService('auction')->getAuctionsYouMayLike($aAuction['product_id']);
        
        if (!$aAuctionsYouMayLike)
        {
            return false;
        }
        
        $this->template()->assign(array(
            'aAuctionsYouMayLike' => $aAuctionsYouMayLike
                )
        );
        
        return 'block';
    }

}

?>
<div id="ynauction_menu_seller_link" class="page_section_menu page_section_menu_header">
    <ul>
        <li class="ynauction-seller-insight"  >
        	<a href="{url link='auction.manageauction'}">{phrase var='manage_auctions'}</a>
        </li>

    </ul> 
</div>

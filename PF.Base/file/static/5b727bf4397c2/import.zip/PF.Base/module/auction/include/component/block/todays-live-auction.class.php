<?php

defined('PHPFOX') or exit('NO DICE!');

class Auction_Component_Block_Todays_Live_Auction extends Phpfox_Component {

    public function process()
    {
        
        return 'block';
    }

}

?>
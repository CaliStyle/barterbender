<?php

defined('PHPFOX') or exit('NO DICE!');

class Auction_Component_Block_Featured_Auctions extends Phpfox_Component {

    public function process()
    {
        $iLimit = Phpfox::getParam('auction.max_items_block_featured_auctions');
        
        $aFeaturedAuctions = Phpfox::getService('auction')->getFeaturedAuctions($iLimit);
        
        if (!$aFeaturedAuctions)
        {
            return false;
        }
        
        $this->template()->assign(array(
            'aFeaturedAuctions' => $aFeaturedAuctions,
            'sHeader' => _p('featured_auctions')
                )
        );
        
        return 'block';
    }

}

?>
<div class="auction-app feed {if empty($aAuction.image_path)}no-photo{/if}">
    <div class="auction-media">
        {if !empty($aAuction.image_path)}
        <a class="item-media-bg" href="{permalink module='auction.detail' id=$aAuction.product_id title=$aAuction.name}"
           style="background-image: url({img ynauction_overridenoimage=true server_id = $aAuction.image_server_id return_url=true  path='core.url_pic' file=$aAuction.image_path suffix='_1024'})">
        </a>
        {/if}
    </div>
    <div class="auction-inner pl-2 pr-2">
        <a href="{permalink id=$aAuction.product_id module='auction.detail' title=$aAuction.name}" class="auction-title fw-bold">{$aAuction.name|clean}</a>
        <div class="auction-description item_view_content">{$aAuction.description_parsed|stripbb|feed_strip|split:55|max_line}</div>
    </div>
</div>
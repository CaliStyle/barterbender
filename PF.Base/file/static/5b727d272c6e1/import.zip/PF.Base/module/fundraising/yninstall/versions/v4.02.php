<?php
defined('PHPFOX') or exit('NO DICE!');

function ynfundraising_install402()
{
    $oDatabase = db();

    // Insert some block in homepage
    _ynfundraisingInsertBlocks();

    // Update settings
    db()->update(':block', array('params' => json_encode(array('limit' => Phpfox::getParam('fundraising.number_of_donors_in_highlight_campaign_block', 6)))), 'component = \'highlight-campaign\' AND module_id = \'fundraising\' AND params IS NULL');
    db()->update(':block', array('params' => json_encode(array('limit' => Phpfox::getParam('fundraising.number_of_donors_on_top_donors_block', 12)))), 'component = \'top-donors\' AND module_id = \'fundraising\' AND params IS NULL');
    db()->update(':block', array('params' => json_encode(array('limit' => Phpfox::getParam('fundraising.number_of_supporters_on_top_suporters_block', 12)))), 'component = \'top-supporters\' AND module_id = \'fundraising\' AND params IS NULL');

    // Delete settings
    $oDatabase->delete(':setting', 'module_id=\'fundraising\' AND var_name=\'number_of_donors_in_highlight_campaign_block\'');
    $oDatabase->delete(':setting', 'module_id=\'fundraising\' AND var_name=\'number_of_campaigns_on_featured_slideshow\'');
    $oDatabase->delete(':setting', 'module_id=\'fundraising\' AND var_name=\'number_of_donors_on_top_donors_block\'');
    $oDatabase->delete(':setting', 'module_id=\'fundraising\' AND var_name=\'number_of_supporters_on_top_suporters_block\'');
    $oDatabase->delete(':setting', 'module_id=\'fundraising\' AND var_name=\'subcategories_to_show_at_first\'');
    $oDatabase->delete(':setting', 'module_id=\'fundraising\' AND var_name=\'google_api_key_location\'');
    $oDatabase->delete(':setting', 'module_id=\'fundraising\' AND var_name=\'fundraising_time_stamp\'');
    $oDatabase->delete(':setting', 'module_id=\'fundraising\' AND var_name=\'is_use_shorten_form\'');
    $oDatabase->delete(':setting', 'module_id=\'fundraising\' AND var_name=\'currency_display_type\'');

    // Delete all redundant component
    _ynfundraisingRemoveComponents();

    $oDatabase->update(':module',['menu' => 'a:6:{s:40:"fundraising.admin_menu_manage_categories";a:1:{s:3:"url";a:2:{i:0;s:11:"fundraising";i:1;s:8:"category";}}s:39:"fundraising.admin_menu_add_new_category";a:1:{s:3:"url";a:3:{i:0;s:11:"fundraising";i:1;s:8:"category";i:2;s:3:"add";}}s:38:"fundraising.admin_menu_manage_campaign";a:1:{s:3:"url";a:2:{i:0;s:11:"fundraising";i:1;s:9:"statistic";}}s:34:"fundraising.admin_menu_manage_help";a:1:{s:3:"url";a:2:{i:0;s:11:"fundraising";i:1;s:5:"email";}}s:39:"fundraising.admin_menu_manage_campaigns";a:1:{s:3:"url";a:1:{i:0;s:11:"fundraising";}}s:45:"fundraising.admin_menu_manage_payment_gateway";a:1:{s:3:"url";a:2:{i:0;s:11:"fundraising";i:1;s:7:"gateway";}}}'],'module_id = \'fundraising\'');
    $oDatabase->delete(':block', 'm_connection = \'fundraising.add\' AND component=\'edit-menu \'');
}

function _ynfundraisingRemoveComponents() {
    $oDatabase = db();

    $oDatabase->delete(':component', 'module_id = \'fundraising\' AND component = \'recent\'');
    $oDatabase->delete(':component', 'module_id = \'fundraising\' AND component = \'direct\'');
    $oDatabase->delete(':component', 'module_id = \'fundraising\' AND component = \'featured\'');
}

function _ynfundraisingInsertBlocks() {
    $oDatabase = db();
    // Insert Featured Campaigns block
    $aFeatureBlocks = $oDatabase->select('*')->from(':block')->where('component = \'homepage.featured-slideshow\' AND module_id = \'fundraising\' AND m_connection = \'fundraising.index\'')->execute('getSlaveRow');
    if (empty($aFeatureBlocks)) {
        $oDatabase->insert(':block', array(
            'title' => 'Featured Campaigns SlideShow',
            'type_id' => 0,
            'm_connection' => 'fundraising.index',
            'module_id' => 'fundraising',
            'product_id' => 'younet_fundraising4',
            'component' => 'homepage.featured-slideshow',
            'location' => 2,
            'is_active' => 1,
            'ordering' => 1,
            'params' => json_encode(array('limit' => Phpfox::getParam('fundraising.number_of_campaigns_on_featured_slideshow')))
        ));
    }

    // Insert Most Donated Campaigns block
    $aMostDonated = $oDatabase->select('*')->from(':block')->where('component = \'homepage.most-donated\' AND module_id = \'fundraising\' AND m_connection = \'fundraising.index\'')->execute('getSlaveRow');
    if (empty($aMostDonated)) {
        $oDatabase->insert(':block', array(
            'title' => 'Most Donated Campaigns',
            'type_id' => 0,
            'm_connection' => 'fundraising.index',
            'module_id' => 'fundraising',
            'product_id' => 'younet_fundraising4',
            'component' => 'homepage.most-donated',
            'location' => 2,
            'is_active' => 1,
            'ordering' => 2
        ));
    }

    // Insert Most Liked Campaigns block
    $aMostLiked = $oDatabase->select('*')->from(':block')->where('component = \'homepage.most-liked\' AND module_id = \'fundraising\' AND m_connection = \'fundraising.index\'')->execute('getSlaveRow');
    if (empty($aMostLiked)) {
        $oDatabase->insert(':block', array(
            'title' => 'Most Liked Campaigns',
            'type_id' => 0,
            'm_connection' => 'fundraising.index',
            'module_id' => 'fundraising',
            'product_id' => 'younet_fundraising4',
            'component' => 'homepage.most-liked',
            'location' => 2,
            'is_active' => 1,
            'ordering' => 3
        ));
    }

    // Insert Latest Campaigns block
    $aMostLiked = $oDatabase->select('*')->from(':block')->where('component = \'homepage.latest\' AND module_id = \'fundraising\' AND m_connection = \'fundraising.index\'')->execute('getSlaveRow');
    if (empty($aMostLiked)) {
        $oDatabase->insert(':block', array(
            'title' => 'Latest Campaigns',
            'type_id' => 0,
            'm_connection' => 'fundraising.index',
            'module_id' => 'fundraising',
            'product_id' => 'younet_fundraising4',
            'component' => 'homepage.latest',
            'location' => 2,
            'is_active' => 1,
            'ordering' => 4
        ));
    }
}

ynfundraising_install402();

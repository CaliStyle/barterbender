<?php
/**
 * [PHPFOX_HEADER]
 */

defined('PHPFOX') or exit('NO DICE!');

?>
{*
<div id="js_fundraising_block_financial_configuration" class="js_fundraising_block page_section_menu_holder" style="display:none;">
	<form method="post" action="{url link='current'}" id="ynfr_edit_campaign_financial_configuration_form" onsubmit="" enctype="multipart/form-data">
		<div class="table_clear">
			<input type="submit" name="val[submit_financial_configuration]" value="{phrase var='save'}" class="button" />
		</div>

	 </form>
</div>
*}
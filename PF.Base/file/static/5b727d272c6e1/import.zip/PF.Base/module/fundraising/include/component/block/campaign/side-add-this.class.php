<?php
/**
 * [PHPFOX_HEADER]
 */

defined('PHPFOX') or exit('NO DICE!');

class Fundraising_Component_Block_Campaign_Side_Add_This extends Phpfox_Component
{
    /**
     * Class process method wnich is used to execute this component.
     */
    public function process()
    {
        //create token for this current user
        $iId = $this->getParam('id');
        $aCampaign = Phpfox::getService('fundraising.campaign')->getCampaignById($iId);
		if(!$aCampaign)
		{
			return false;
		}
        $sToken = md5(Phpfox::getUserId());
        $iBackId = $this->request()->get('user');
        if(isset($iBackId) && !empty($iBackId)) {
            if($iBackId != Phpfox::getUserId()) {
                $aUserId = Phpfox::getService('fundraising.user')->getUserIdList();
                foreach($aUserId as $iUserId) {
                    if($iUserId['user_id'] == $iBackId) {
                        Phpfox::getService('fundraising.user')->updateSupporter('comeback', $iBackId);
                        break;
                    }
                }
            }
        }
        // get share , click ...

        list($iShare, $iClick) = Phpfox::getService('fundraising.user')->getShareClick($aCampaign['campaign_id']);
        $iViralLift = ($iShare!=0)?round(($iClick*100)/$iShare,2):'0';

		if(!$iClick)
		{
			$iClick = 0;
		}

		if(!$iShare)
		{
			$iShare = 0;
		}
        $this->template()->assign(array(
                'sHeader' => '',
                'aCampaign' => $aCampaign,
                'sToken' => $sToken,
                'iShare' => $iShare,
                'iClick' => $iClick,
                'iViralLift' => $iViralLift,
                'sAddThisShareButton' => '',
                'sAddThisPubId' => setting('core.addthis_pub_id', 'younet'),
            )
        );

        // add support responsiveclean template
        if ( $this->template()->getThemeFolder() == 'ynresponsiveclean' ) {
            $this->template()->assign(array(
                    'sHeader' => 'shares',                    
                )
            );            
        }
        return 'block';
    }

}

?>
(function(window, undefined) {
var ynvalidator = {
		

};

window.ynvalidator = ynvalidator;

})(window);
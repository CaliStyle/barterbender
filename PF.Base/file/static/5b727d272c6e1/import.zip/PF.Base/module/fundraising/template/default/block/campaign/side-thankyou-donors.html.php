<?php
/**
 * [PHPFOX_HEADER]
 */

defined('PHPFOX') or exit('NO DICE!');

?>

{foreach from=$aDonors item=aUser name=aUser}
	{template file='fundraising.block.campaign.user-entry'}
{/foreach}

{if count($aDonors) > 0}
	<div class="text-center">
		<a href="{url link='fundraising.user' view='donor' id=$iCampaignId}" class="btn btn-sm btn-success"><i class="fa fa-caret-right"></i>  {phrase var='view_all'} </a>
	</div>
{/if}
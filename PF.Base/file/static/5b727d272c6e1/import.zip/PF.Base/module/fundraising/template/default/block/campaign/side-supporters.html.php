<?php
/**
 * [PHPFOX_HEADER]
 */

defined('PHPFOX') or exit('NO DICE!');

?>

{foreach from=$aSupporters item=aUser name=aUser}
	{template file='fundraising.block.campaign.user-entry'}
{/foreach}

<div class="clear"> </div>

{if count($aSupporters) > 0} 
	<div class="text-center">
		<a href="{url link='fundraising.user' view='supporter' id=$iCampaignId}" class="btn btn-sm btn-success"><i class="fa fa-caret-right"></i>  {phrase var='view_all'} </a>
	</div>
{/if}
<?php
/**
 * [PHPFOX_HEADER]
 */

defined('PHPFOX') or exit('NO DICE!');

?>
<div style="width:250px">
	{module name='fundraising.highlight-campaign' iCampaignId=$iCampaignId is_badge=true}
</div>
<div id="ynauction_auction_compareitem" class="ynauction_auction_compareitem">	
</div>

{literal}
<script type="text/javascript">
    ;$Behavior.ynauction_compareitem_init = function() {
    	if($('#ynauction_auction_compareitem').length > 0){
    		ynauction.initCompareItemBlock();
    	} 
    };        
</script>
{/literal}


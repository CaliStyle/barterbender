<?php

$aPluginFiles[] = 'PF.Base/module/resume/include/plugin/theme_template_body__start.php';
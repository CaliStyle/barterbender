<?php
/**
 * [PHPFOX_HEADER]
 */

defined('PHPFOX') or exit('NO DICE!');

/**
 *
 * @copyright      YouNet Company
 * @author         VuDP, TienNPL, TrucPTM
 * @package        Module_Resume
 * @version        3.01
 * 
 */?>
 
{phrase var='favorite.successfully_added_to_your_favorites'}
<ul class="action">
	<li><a href="{$sLink}"><b style="color:#3B5998;">{phrase var='favorite.view_your_favorites'}</a></b></li>
</ul>
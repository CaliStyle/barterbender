<?php

$_SESSION['aUserResume'] = $aUser;

?>

<?php

defined('PHPFOX') or exit('NO DICE!');
?>
{if Phpfox::isMobile()}
	{literal}
	<script language="JavaScript" type="text/javascript">
		$Behavior.removeAddCoupon = function(){

			var flag = $('#breadcrumb_holder > a')[0];
			//onsole.log(flag);
			if(flag == undefined)
			{
				$('#breadcrumb_holder').hide();
			}
			else{
				flag.style.display = 'none';
			}
			
		};
	</script>
	{/literal}
{/if}

{if $bIsHomepage}

	{if !count($aItems)}
			<div class="extra_info">
				{phrase var='no_coupons_found'}
			</div>
	{else}

		<div class="yncoupon-homepage">
			{module name='coupon.featured-slideshow'}

			{module name='coupon.most-claimed'}

			{* module name='coupon.most-rated' *}

			{module name='coupon.most-comment'}
		</div>

	{/if}
{else}

	{if $sView == 'faq'}

		{module name='coupon.faq'}
	{else}

		{if !count($aItems)}
            {if !PHPFOX_IS_AJAX}
			<div class="extra_info">
				{phrase var='no_coupons_found'}
			</div>
            {/if}
		{else}
            <div class="ync_grid_my_coupon clearfix">
                <div class="ync_grid_most_block clearfix">
                {foreach from=$aItems  name=coupon item=aCoupon}
                    {if phpFox::isMobile() }
                        { template file='coupon.block.mobile.mobile-entry'}
                    {else}
                        { template file='coupon.block.entry'}
                    {/if}
                {/foreach}
                </div>
            </div>
            <div class="clear"></div>

            {if !Phpfox::isMobile()
                && $sView == 'pending'
            }
                {moderation}
            {/if}

            {pager}

		{/if}

	{/if}
{/if}
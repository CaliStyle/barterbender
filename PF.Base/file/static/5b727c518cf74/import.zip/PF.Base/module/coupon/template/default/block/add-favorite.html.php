<?php

/**
 * [PHPFOX_HEADER]
 */
defined('PHPFOX') or exit('NO DICE!');

/**
 * 
 * @copyright      YouNet Company
 * @author         TienNPL, DatLV
 * @package        Module_Coupon
 * @version        3.01
 * 
 */

?>

{phrase var='successfully_added_to_your_favorites'}

<ul class="action">
	<li>
		<strong>
			<a href="{$sLink}" style="color:#3B5998;">
				{phrase var='view_your_favorites'}
			</a>
		</strong>
	</li>
	
</ul>
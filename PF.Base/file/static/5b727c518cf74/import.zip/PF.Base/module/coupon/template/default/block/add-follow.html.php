<?php

/**
 * [PHPFOX_HEADER]
 */
defined('PHPFOX') or exit('NO DICE!');

/**
 * 
 * @copyright      YouNet Company
 * @author         TienNPL, DatLV
 * @package        Module_Coupon
 * @version        3.01
 * 
 */

?>

{phrase var='the_coupon_had_been_added_to_your_following_list'}

<ul class="action">
	<li>
		<strong>
			<a href="{$sLink}" style="color:#3B5998;">
				{phrase var='view_your_following'}
			</a>
		</strong>
	</li>
	
</ul>
<?php
/*
 * @copyright        [YouNet_COPYRIGHT]
 * @author           YouNet Company
 * @package          Module_FeedBack
 * @version          3.01p1
 *
 */
defined('PHPFOX') or exit('NO DICE!');
?>
<?php

class FeedBack_Component_Controller_Detail extends Phpfox_Component
{
    public function process()
    {
        Phpfox::getUserParam('feedback.can_view_feedback', true);
        if (isset($_SESSION['data_search'])) {
            unset($_SESSION['data_search']);
        }

        // Phpfox::isUser(true);
        $fb_id = $this->request()->get('feedback');
        $sTitle = $this->request()->get('req3');
        $core_url = Phpfox::getParam('core.path');

        if (!empty($fb_id)) {
            $sFeedBacks = Phpfox::getService('feedback')->getFeedBackDetailById($fb_id);
        } else {

            $sFeedBacks = Phpfox::getService('feedback')->getFeedBackDetailByAlias($sTitle);
        }

        if (empty($sFeedBacks)) {
            return Phpfox_Error::display(_p('feedback.feedback_not_found'));
        }
        $sFeedBacks['total_view'] = Phpfox::getService('feedback.process')->numberAbbreviation($sFeedBacks['total_view']);
        $sFeedBacks['total_comment'] = Phpfox::getService('feedback.process')->numberAbbreviation($sFeedBacks['total_comment']);
        $sFeedBacks['total_like'] = Phpfox::getService('feedback.process')->numberAbbreviation($sFeedBacks['total_like']);
        $sFeedBacks['total_vote'] = Phpfox::getService('feedback.process')->numberAbbreviation($sFeedBacks['total_vote']);

        if ($sFeedBacks['is_approved'] == 0) {
            if (((Phpfox::getUserId() == $sFeedBacks['user_id']) && Phpfox::getUserId()) || Phpfox::getUserParam('feedback.can_approve_feedbacks')) {
            } else {
                $this->url()->send('subscribe');
            }
        }
        $iPrivacy = 0;
        if ($sFeedBacks['privacy'] == '2') {
            $iPrivacy = 3;
        } else {
            $iPrivacy = 0;
        }
        Phpfox::getService('privacy')->check('feedback', $sFeedBacks['feedback_id'], $sFeedBacks['user_id'], $iPrivacy, $sFeedBacks['is_friend']);

        if (Phpfox::isModule('track') && phpfox::isUser() && count($sFeedBacks) > 0 && !$sFeedBacks['is_viewed']) {
            Phpfox::getService('track.process')->add('feedback', $sFeedBacks['feedback_id']);
            Phpfox::getService('feedback.process')->updateView($sFeedBacks['feedback_id']);
        }
        if (!empty($sFeedBacks['category_name'])) {
            $sCategory = ' <a href="' . Phpfox::getLib('url')->makeUrl('feedback', array('category', $sFeedBacks['feedback_category_id'], $sFeedBacks['category_name'])) . '">' . $sFeedBacks['category_name'] . '</a>';
            $sFeedBacks['category_url'] = $sCategory;
        }

        $link = phpfox::getLib('url')->makeURL($sFeedBacks['user_name']);
        $time_stamp = Phpfox::getTime(Phpfox::getParam('core.global_update_time'), $sFeedBacks['time_stamp']);
        if (empty($sFeedBacks['full_name'])) {
            $sFeedBacks['info'] = _p('feedback.visitor_posted_feedback', array('time_stamp' => $time_stamp, 'visitor' => $sFeedBacks['visitor']));
        } else {

            $sFeedBacks['info'] = _p('feedback.posted_time_link_by_user', array('time_stamp' => $time_stamp, 'link' => $link, 'full_name' => $sFeedBacks['full_name']));
        }
        $aFilterMenu = array();
        if (Phpfox::getUserId()) {
            $iMyFeedbackTotal = Phpfox::getService('feedback')->getMyFeedbacksTotal();
        }
        if (!defined('PHPFOX_IS_USER_PROFILE')) {
            if (Phpfox::getUserId() && $iMyFeedbackTotal > 0) {
                $aFilterMenu = array(
                    _p('feedback.all_feedbacks') => '',
                    _p('feedback.my_feedbacks').'<span class="my count-item">' . ($iMyFeedbackTotal > 99 ? '99+' : $iMyFeedbackTotal) . '</span>' => 'my'
                );
            }
            else {
                $aFilterMenu = array(
                    _p('feedback.all_feedbacks') => '',
                    _p('feedback.my_feedbacks').'<span class="my"></span>' => 'my'
                );
            }

            if (Phpfox::isModule('friend') && !Phpfox::getParam('core.friends_only_community')) {
                $aFilterMenu[_p('feedback.friend_feedbacks')] = 'friend';
            }

            if (Phpfox::getUserParam('feedback.can_approve_feedbacks')) {
                $iPendingTotal = Phpfox::getService('feedback')->getPendingTotal();
                if ($iPendingTotal) {
                    $aFilterMenu[_p('feedback.pending_feedbacks') . (Phpfox::getUserParam('feedback.can_approve_feedbacks') ? '<span class="pending count-item"> ' . $iPendingTotal . '</span>' : 0)] = 'pending';
                }
            }
        }
        $this->template()->buildSectionMenu('feedback', $aFilterMenu);
        $isVoted = Phpfox::getLib('database')->select('fv.*')
            ->from(Phpfox::getT('feedback_vote'), 'fv')
            ->where('fv.user_id = ' . Phpfox::getUserId() . ' and fv.feedback_id = ' . $sFeedBacks['feedback_id'])
            ->execute('getRow');
        if (empty($isVoted)) {
            $sFeedBacks['isVoted'] = false;
        } else {
            $sFeedBacks['isVoted'] = true;
        }
        $aSorts = array(
            'fb.date_modify' => _p('feedback.most_recent'),
            'fb.total_vote' => _p('feedback.most_voted'),
            'fb.total_view' => _p('feedback.most_viewed'),
            'fb.total_comment' => _p('feedback.most_comment'),
            'fb.is_featured' => _p('feedback.featured')
        );
        $sCats = phpfox::getService('feedback')->getFeedBackCat();
        $aTypes = $sCats;
        //	$aTypes['All'] = 'All';
        $aStatus = Phpfox::getService('feedback')->getFeedBackStatus();

        $aFilters = array(
            'type_cats' => array(
                'type' => 'select',
                'options' => $aTypes,
                'add_any' => true,
                'search' => "fb.feedback_category_id = [VALUE]"
            ),
            'type_status' => array(
                'type' => 'select',
                'options' => $aStatus,
                'add_any' => true,
                'search' => "fb.feedback_status_id = [VALUE]"
            ),
            'sort' => array(
                'type' => 'select',
                'options' => $aSorts,
                'default' => 'fb.time_stamp'
            ),
            'sort_by' => array(
                'type' => 'select',
                'options' => array(
                    'DESC' => _p('core.descending'),
                    'ASC' => _p('core.ascending')
                ),
                'default' => 'DESC'
            ),
            'keyword' => array(
                'type' => 'input:text',
            )

        );

        Phpfox::getLib('search')->set(array(
                'type' => 'feedback',
                'filters' => $aFilters,
                'cache' => true,
                'field' => 'fb.feedback_id',
                'search' => 'keyword'
            )
        );
        //use to show social share
        $public_id_addthis = Phpfox::getParam('core.addthis_pub_id');
        $public_id_addthis = empty($public_id_addthis) ? 'younet' : $public_id_addthis;
        $sFormUrl = $this->url()->makeUrl('feedback');
        $bookmark_url = Phpfox::getLib('url')->makeUrl('feedback', array('detail', $sFeedBacks['title_url']));
        $login = phpfox::getLib('url')->makeURL('login');

        //support tag 
        if (Phpfox::isModule('tag')) {
            $aTags = Phpfox::getService('tag')->getTagsById('feedback',
                $sFeedBacks['feedback_id']);
            if (isset($aTags[$sFeedBacks['feedback_id']])) {
                $sFeedBacks['tag_list'] = $aTags[$sFeedBacks['feedback_id']];
            }
        }

        // Add tags to meta keywords
        if (!empty($sFeedBacks['tag_list']) && $sFeedBacks['tag_list'] && Phpfox::isModule('tag')) {
            $this->template()->setMeta('keywords', Phpfox::getService('tag')->getKeywords($sFeedBacks['tag_list']));
        }
        
        $this->template()->setTitle($sFeedBacks['title'])
            ->setBreadCrumb(_p('feedback.feedbacks'), $this->url()->makeUrl('feedback'), false)
            ->setHeader('cache', array(
                'jquery/plugin/jquery.highlightFade.js' => 'static_script',
                'jquery/plugin/jquery.scrollTo.js' => 'static_script',
                'jquery/plugin/imgnotes/jquery.tag.js' => 'static_script',
                'quick_edit.js' => 'static_script',
                'feed.js' => 'module_feed',
                'pager.css' => 'style_css',
                'switch_legend.js' => 'static_script',
                'switch_menu.js' => 'static_script',
                'feedback.js' => 'module_feedback',
            ))
            ->setPhrase(array('are_you_sure_you_want_to_delete_this_photo', 'feedback_photo','description_of_feedback_cannot_be_empty','title_cannot_be_empty'))
            ->assign(array(
                'aFeedBack' => $sFeedBacks,
                'core_url' => $core_url,
                'link' => $link,
                'login' => $login,
                'full_name' => isset($sFeedBacks['full_name']) ? $sFeedBacks['full_name'] : $sFeedBacks['visitor'],
                'info' => $sFeedBacks['info'],
                'feedback_link' => phpfox::getLib('url')->makeUrl('feedback.detail', $sFeedBacks['title_url']),
                'core_path' => phpfox::getParam('core.path'),
                'sFormUrl' => $sFormUrl,
                'bFeedbackView' => true,
                'public_id_addthis' => $public_id_addthis,
                'sShareDescription' => str_replace(array("\n","\r","\r\n"),'', $sFeedBacks['feedback_description']),
                'sBookmarkUrl' => $bookmark_url
            ));
        $iPrivacy = 0;
        if ($sFeedBacks['privacy'] != 1) {
            $iPrivacy = 3;
        }
        // in fact that feed back doesn't have comment privacy , so we use user setting here for privacy comment
        $this->setParam('aFeed', array(
                'comment_type_id' => 'feedback',
                'privacy' => $iPrivacy,
                'comment_privacy' => (Phpfox::getUserParam('feedback.can_you_post_on_feedback') ? 0 : 3),//(isset($sFeedBacks['privacy_comment']) ? $sFeedBacks['privacy_comment'] : '0'),
                'like_type_id' => 'feedback',
                'feed_is_liked' => $sFeedBacks['is_liked'],
                'feed_is_friend' => (isset($sFeedBacks['is_friend']) ? $sFeedBacks['is_friend'] : '0'),
                'item_id' => $sFeedBacks['feedback_id'],
                'user_id' => $sFeedBacks['user_id'],
                'total_comment' => $sFeedBacks['total_comment'],
                'total_like' => $sFeedBacks['total_like'],
                'feed_link' => Phpfox::permalink('feedback.detail', $sFeedBacks['title_url']),
                'feed_title' => $sFeedBacks['title'],
                'feed_display' => 'view',
                'feed_total_like' => $sFeedBacks['total_like'],
                'report_module' => 'feedback',
                'report_phrase' => _p('feedback.report_this_feedback')
            )
        );
        if (Phpfox::getUserId()) {
            $this->template()->setEditor(array(
                    'load' => 'simple',
                    'wysiwyg' => ((Phpfox::isModule('comment')))
                )
            );
        }
        if (Phpfox::getUserParam('feedback.can_approve_feedbacks'))
        {
            if ($sFeedBacks['is_approved'] != 1) {
                $aTitleLabel['label']['pending'] = [
                    'title' => '',
                    'title_class' => 'flag-style-arrow',
                    'icon_class' => 'clock-o'

                ];
                $aPendingItem = [
                    'message' => _p('feedback_is_pending_approval'),
                    'actions' => []
                ];
                if (Phpfox::getUserParam('feedback.can_approve_feedbacks')) {
                    $aPendingItem['actions']['approve'] = [
                        'is_ajax' => true,
                        'label' => _p('approve'),
                        'action' => '$.ajaxCall(\'feedback.approve\', \'inline=true&amp;id='.$sFeedBacks['feedback_id'].'\', \'POST\')'
                    ];
                }
                if ($sFeedBacks['user_id'] == Phpfox::getUserId()) {
                    $aPendingItem['actions']['edit'] = [
                        'is_ajax' => true,
                        'label' => _p('edit'),
                        'action' => '$Core.box(\'feedback.editFeedBack\', 500, \'feedback_id='.$sFeedBacks['feedback_id'].'\')',
                    ];
                }
                if ($sFeedBacks['user_id'] == Phpfox::getUserId()) {
                    $aPendingItem['actions']['delete'] = [
                        'is_confirm' => true,
                        'confirm_message' => _p('are_you_sure_you_want_to_delete_this_feedback_permanently'),
                        'label' => _p('delete'),
                        'action' => $this->url()->makeUrl('feedback/delete',['id' => $sFeedBacks['feedback_id']]),
                    ];
                }

                $this->template()->assign([
                    'aPendingItem' => $aPendingItem
                ]);
            }
        }

        $this->template()->assign([
            'bCanApprove' => Phpfox::getUserParam('feedback.can_approve_feedbacks')
        ]);

    }

}

?>

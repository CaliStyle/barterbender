<?php
	if($sType == 'comment_feedback')
	{
		$sType = 'comment_feedfeedback';
	}
	if($sType == 'comment_feedback_tag')
	{
		$sType = 'comment_feedfeedback_tag';
	}
?>
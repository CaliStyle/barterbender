<?php
?>
{if (Phpfox::getUserParam('feedback.can_upload_pictures') && Phpfox::getUserId() == $aFeedBack.user_id)|| phpfox::isAdmin()}
<li>
	<a  class="buttonlink icon_feedback_image_new" href="{url link='feedback.up' feedback =$aFeedBack.feedback_id}">{_p var='add_picture'}</a>
</li>
{/if}

{if ((Phpfox::getUserParam('feedback.edit_own_feedback') && Phpfox::getUserId() == $aFeedBack.user_id) || Phpfox::getUserParam('feedback.edit_user_feedback'))} 
<li>
	<a class="buttonlink inlinePopup" href="#?call=feedback.editFeedBack&amp;height=400&amp;width=500&amp;feedback_id={$aFeedBack.feedback_id}" title="{_p var='edit_feedback'}">{_p var='edit'}</a>
</li>
{/if}

{if (Phpfox::getUserParam('feedback.delete_own_feedback') && Phpfox::getUserId() == $aFeedBack.user_id) || Phpfox::getUserParam('feedback.delete_user_feedback')} 
	{if $bFeedbackView}
		<li class="item_delete">
			<a href="{url link="feedback.delete" id=""$aFeedBack.feedback_id""}" class="no_ajax_link sJsConfirm">{_p var='delete'}</a>
		</li>
	{else}
		<li class="item_delete">
			<a class="buttonlink icon_feedback_delete" href="#" onclick="$Core.jsConfirm({l}{r}, function(){l}deleteFeedBack({$aFeedBack.feedback_id}){r}, function(){l}{r}); return false;">{_p var='delete'}</a>
		</li>
	{/if}
{/if}

{*{if (Phpfox::getUserParam('feedback.can_approve_feedbacks') || Phpfox::getUserParam('feedback.delete_user_feedback')) && $aFeedBack.is_approved == 0}
    <li class="item_delete">
    <a  class="buttonlink icon_feedback_image_new" href="javascript:void(0);" onclick="javascript:approve({$aFeedBack.feedback_id});return false;">{_p var='approve'}</a>
</li>
{/if}*}

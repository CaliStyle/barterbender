<?php 
 
defined('PHPFOX') or exit('NO DICE!'); 

?>
this is profilemanagerssprovider ... 
<?php
?>

<script language="javascript" type="text/javascript">	
$Core.foxfeedspro_message = new Array(); 
$Core.foxfeedspro_message["foxfeedspro.no_selected_news_to_delete"] = "{phrase var='foxfeedspro.no_selected_news_to_delete'}";
$Core.foxfeedspro_message["foxfeedspro.no_selected_feeds_to_delete"] = "{phrase var='foxfeedspro.no_selected_feeds_to_delete'}";
$Core.foxfeedspro_message["foxfeedspro.no_selected_categories_to_delete"] = "{phrase var='foxfeedspro.no_selected_categories_to_delete'}";
$Core.foxfeedspro_message["foxfeedspro.you_have_not_permisssion_to_delete_this_category"] = "{phrase var='foxfeedspro.you_have_not_permisssion_to_delete_this_category'}";
$Core.foxfeedspro_message["foxfeedspro.are_you_sure_you_want_to_delete_this_action_will_delete_all_feeds"] = "{phrase var='foxfeedspro.are_you_sure_you_want_to_delete_this_action_will_delete_all_feeds'}";
$Core.foxfeedspro_message["foxfeedspro.are_you_sure"] = "{phrase var='foxfeedspro.are_you_sure'}";
$Core.foxfeedspro_message["foxfeedspro.there_is_no_selected_feeds_to_approve"] = "{phrase var='foxfeedspro.there_is_no_selected_feeds_to_approve'}";
$Core.foxfeedspro_message["foxfeedspro.there_is_no_selected_news_to_approve"] = "{phrase var='foxfeedspro.there_is_no_selected_news_to_approve'}";
$Core.foxfeedspro_message["foxfeedspro.there_is_no_selected_feeds_to_get_data"] = "{phrase var='foxfeedspro.there_is_no_selected_feeds_to_get_data'}";
$Core.foxfeedspro_message["foxfeedspro.there_is_no_selected_category_to_update_status"] = "{phrase var='foxfeedspro.there_is_no_selected_category_to_update_status'}";
$Core.foxfeedspro_message["foxfeedspro.there_is_no_selected_feeds_to_update_status"] = "{phrase var='foxfeedspro.there_is_no_selected_feeds_to_update_status'}";
</script>
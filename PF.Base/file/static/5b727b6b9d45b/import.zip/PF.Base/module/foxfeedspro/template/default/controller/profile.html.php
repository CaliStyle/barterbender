<?php 
 
defined('PHPFOX') or exit('NO DICE!'); 

?>
this is profile html page ...
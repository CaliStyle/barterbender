<module>
	<data>
		<module_id>foxfeedspro</module_id>
		<product_id>FoxFeedsPro</product_id>
		<is_core>0</is_core>
		<is_active>1</is_active>
		<is_menu>0</is_menu>
		<menu />
		<phrase_var_name>module_foxfeedspro</phrase_var_name>
		<writable />
	</data>
	
</module>
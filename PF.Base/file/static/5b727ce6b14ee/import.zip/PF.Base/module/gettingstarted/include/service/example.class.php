<?php
defined('PHPFOX') or exit('NO DICE!');
require_once (PHPFOX_DIR . 'module' . PHPFOX_DS . 'gettingstarted' . PHPFOX_DS . 'include' . PHPFOX_DS . 'service' . PHPFOX_DS . 'libs.class.php');
class GettingStarted_Service_Example extends Younet_Service
{    
    public function __construct()
	{		
			
	}
	
}
?>
<?php
define('PHPFOX') or exit('NO DICE!');
?>
<?php
 class GettingStarted_Component_Controller_Languages extends Phpfox_Component{
     
     public function process(){
         
         
     }
     
 }

?>

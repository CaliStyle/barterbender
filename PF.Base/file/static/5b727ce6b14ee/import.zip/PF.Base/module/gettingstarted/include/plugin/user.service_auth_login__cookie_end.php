<?php

$_SESSION['check_login'] = true;
/*$settings = phpfox::getService('gettingstarted.settings')->getSettings(0);

if($settings["active_getting_started"])
{
	
	$corepath=phpfox::getParam("core.path");
	echo "<script src='".$corepath."module/gettingstarted/static/jscript/gettingstarted.js' type='text/javascript'></script>";
	echo "<link href='".$corepath."module/gettingstarted/static/css/default/default/gettingstarted.css' type='text/css' rel='stylesheet'>";
	echo "<link href='".$corepath."module/gettingstarted/static/css/default/default/thickbox.css' type='text/css' rel='stylesheet'>";
	Phpfox::getService("gettingstarted.todolist")->showTodoList();

}*/
?>

<?php
/**
 * [PHPFOX_HEADER]
 */

defined('PHPFOX') or exit('NO DICE!');

class Videochannel_Service_Convert extends Phpfox_Service 
{
	private $_sFfmpeg = 'ffmpeg';
	
	private $_sMencoder = 'mencoder';

	private $_sFlvtool2 = 'flvtool2';

	private $_sLastLineCode = '';
	
	private $_aVideoDetails = array();
	
	/**
	 * Class constructor
	 */	
	public function __construct()
	{	
		$this->_sTable = Phpfox::getT('channel_video');
		
		$this->_sFfmpeg = Phpfox::getParam('videochannel.ffmpeg_path');
		$this->_sMencoder = Phpfox::getParam('videochannel.mencoder_path');
		$this->_sFlvtool2 = Phpfox::getParam('videochannel.flvtool2_path');
		
		
	}
	
	public function process($iId = null, $bIsAttachment = false)
	{
		$aVals = array('ffmpeg_path' => Phpfox::getParam('videochannel.ffmpeg_path'),
				   'mencoder_path' => Phpfox::getParam('videochannel.mencoder_path'));
		
		if (!($mReturn = Phpfox::getService('videochannel')->requirementCheck($aVals)))
		{			
			$sSiteTitle = Phpfox::getParam('core.site_title');
			$sErrorFFMPEG = _p('videochannel.must_set_the_path_to_ffmpeg_for_sitename_before_uploading_of_videos',array('sSiteName' =>$sSiteTitle));
			Phpfox_Error::set($sErrorFFMPEG);			
		}
		$aCondition = array();
		if ($iId !== null)
		{
			$aCondition[] = 'video_id = ' . (int) $iId . ' AND ';
		}
		$aCondition[] = 'in_process = 1';
		if ($iId !== null)
		{
			$aCondition[] = 'AND user_id = ' . Phpfox::getUserId() . '';
		}
		
		if ($bIsAttachment)
		{
			$aVideos = $this->database()->select('attachment_id AS video_id, user_id, destination, extension AS file_ext')
				->from(Phpfox::getT('attachment'))
				->where('attachment_id = ' . (int) $iId)
				->limit(1)
				->execute('getSlaveRows');					
		}
		else 
		{
			$aVideos = $this->database()->select('*')
				->from($this->_sTable)
				->where($aCondition)
				->limit(1)
				->execute('getSlaveRows');		
		}
				
		if (!count($aVideos))
		{
			$this->_debug(_p('videochannel.nothing_to_convert'));

			exit;
		}		
			
		$this->_debug(_p('videochannel.started_converting_process'));
		
		if (defined('PHPFOX_CLI'))
		{
			touch(PHPFOX_DIR_CACHE . 'video.lock');
		}
		
		if (!$bIsAttachment)
		{
			foreach ($aVideos as $aVideo)
			{
				// 'Converting (store in cache): ' . $aVideo['video_id']
				$this->_debug(_p('videochannel.converting_store_in_cache_video_id'));
				
				$this->database()->update($this->_sTable, array('in_process' => '2'), 'video_id = ' . $aVideo['video_id']);
				
				$this->_debug(_p('videochannel.updated_process_id'));
			}
		}
		
		foreach ($aVideos as $aVideo)
		{
			if (Phpfox::getParam('videochannel.close_sql_connection_while_converting'))
			{
				$this->database()->close();
			}
			
			// 'Start converting process: ' . $aVideo['video_id']
			$this->_debug(_p('videochannel.start_converting_process_video_id', array('video_id' => $aVideo['video_id'])));
			
			$sNewPath = substr_replace(sprintf($aVideo['destination'], ''), '', -(strlen($aVideo['file_ext']) + 1)) . '.flv';
			$sSource = Phpfox::getParam(($bIsAttachment ? 'core.dir_attachment' : 'core.dir_pic')) . sprintf($aVideo['destination'], '');
			if (Phpfox::getParam(array('balancer', 'enabled')) && !file_exists($sSource))
			{
				preg_match('/(.*)\/(.*)_(.*?)/i', $sSource, $aLbMatches);
				if (isset($aLbMatches[2]))
				{
					$aServers = Phpfox::getParam(array('balancer', 'servers'));
					foreach ($aServers as $iIp => $aServer)
					{
						if ($aServer['id'] == $aLbMatches[2])
						{
							$sSource = str_replace(PHPFOX_DIR, $aServer['url'], $sSource);
							
							break;
						}				
					}	
				}	
			}					
			
			$sDestination = Phpfox::getParam(($bIsAttachment ? 'core.dir_attachment' : 'core.dir_pic')) . $sNewPath;
			if ($bIsAttachment)
			{
				$sImageLocation = Phpfox::getParam('core.dir_attachment') . substr_replace($sNewPath, '%s.jpg', -4);	
			}
			else 
			{
				$sImageLocation = Phpfox::getLib('file')->getBuiltDir(Phpfox::getParam(($bIsAttachment ? 'core.dir_attachment' :'core.dir_pic'))) . md5($aVideo['video_id'].'videochannel') . '%s.jpg';
			}

			if (file_exists($sDestination) && $aVideo['file_ext'] != 'flv')
			{
				$this->_debug(_p('videochannel.file_exists_sdestination'));
				
				continue;
			}
			
			$iWidth = 620;
			$iHeight = 386;		

			// 'Converting: ' . $sSource
			$this->_debug(_p('videochannel.converting_ssource', array('sSource' => $sSource)));
			$aFind = array(
					'{source}',
					'{destination}',
					'{width}',
					'{height}'
			);
			$aReplace = array(
					$sSource,
					$sDestination,
					$iWidth,
					$iHeight
			);
			
			$sFfmpegParams = str_replace($aFind, $aReplace, Phpfox::getParam('videochannel.params_for_ffmpeg'));

			if ($aVideo['file_ext'] != 'flv')			
			{				
				$this->_exec($this->_sFfmpeg . ' ' . $sFfmpegParams);
							
				if (!$this->_check($sDestination))
				{				
					if (file_exists($sDestination))
					{
						unlink($sDestination);
					}
					$sMencoderParams = str_replace($aFind, $aReplace, Phpfox::getParam('videochannel.params_for_mencoder'));
					$this->_exec($this->_sMencoder . ' ' . $sMencoderParams);
				}
				
				if (!$this->_check($sDestination))
				{
					if (file_exists($sDestination))
					{
						unlink($sDestination);
					}				
					
					$this->_exec($this->_sMencoder . ' ' . str_replace($aFind, $aReplace, Phpfox::getParam('videochannel.params_for_mencoder_fallback')));
				}				
			}
			
			if (!($bReturn = $this->_check($sDestination)))
			{
				// 'Can\'t convert: ' . $sSource
				$this->_debug(_p('videochannel.cant_convert_ssource', array('sSource' => $sSource)));
					
				return $bReturn;
			}			
			if (Phpfox::getParam('videochannel.enable_flvtool2'))
			{
					$this->_exec($this->_sFlvtool2 . ' ' . str_replace($aFind, $aReplace, Phpfox::getParam('videochannel.params_for_flvtool2')));
			}
			// 'Converting completed: ' . $sDestination
			$this->_debug(_p('videochannel.converting_completed_sdestination', array('sDestination' => $sDestination)));
			
			if ($bIsAttachment)
			{
				$aSql = array();				
			}
			else
			{
				$aSql  = array(
					'view_id' => (($aVideo['module_id'] == 'videochannel' && Phpfox::getUserParam('videochannel.approve_video_before_display')) ? 2 : 0),
					'in_process' => 0,
					'destination' => $sNewPath,				
					'image_path' => str_replace(Phpfox::getParam('core.dir_pic'), '', $sImageLocation),
					'image_server_id' => Phpfox::getLib('request')->getServer('PHPFOX_SERVER_ID')
				);
			}
				
			// Temp. disable error reporting
			Phpfox_Error::skip(true);	
			
			require_once(PHPFOX_DIR_LIB . 'getid3' . PHPFOX_DS . 'getid3' . PHPFOX_DS . 'getid3.php');
				
			$oGetId3 = new getID3;
				
			$aMetaData = $oGetId3->analyze($sDestination);
			
			if (isset($aMetaData['playtime_string']))
			{
				$aSql['duration'] = $aMetaData['playtime_string'];
			}	
				
			if (isset($aMetaData['video']['resolution_x']))
			{
				$aSql['resolution_x'] = $aMetaData['video']['resolution_x'];
			}
				
			if (isset($aMetaData['video']['resolution_y']))
			{
				$aSql['resolution_y'] = $aMetaData['video']['resolution_y'];
			}			
			
			// Return back error reporting
			Phpfox_Error::skip(false);									
				
			$this->_debug(_p('videochannel.updated_database_video_table'));
				
			if (Phpfox::getParam('videochannel.close_sql_connection_while_converting'))
			{
				$this->database()->connect(Phpfox::getParam(array('db', 'host')), Phpfox::getParam(array('db', 'user')), Phpfox::getParam(array('db', 'pass')), Phpfox::getParam(array('db', 'name')));
			}
				
			if (!$bIsAttachment)
			{
				// Update user space usage
				Phpfox::getService('user.space')->update($aVideo['user_id'], 'video', filesize($sDestination));	
				
				$this->_debug(_p('videochannel.updated_user_points'));
			}
			
			if ($aVideo['file_ext'] != 'flv' && substr($sSource, 0, 4) != 'http')			
			{
				@unlink($sSource);
			
				$this->_debug(_p('videochannel.removed_source_file'));
			}			
  		
			if (!file_exists(sprintf($sImageLocation, '')))
			{
				$this->_exec($this->_sFfmpeg . ' -y -i ' . $sDestination . ' -t 00:00:01 -r 1 -f mjpeg ' . sprintf($sImageLocation, ''));	
			}			
    			
    		if (!file_exists(sprintf($sImageLocation, '')))
    		{
    			$this->_exec($this->_sFfmpeg . ' -y -i ' . $sDestination . ' -t 00:00:01 -r 1 -f image2 ' . sprintf($sImageLocation, ''));
    		}

			if (class_exists('ffmpeg_movie') && !file_exists(sprintf($sImageLocation, '')))
			{
				$oFfmpegMovie = new ffmpeg_movie($sDestination);
				if (is_object($oFfmpegMovie) && method_exists($oFfmpegMovie, 'getFrame'))
				{
					$oFrame = $oFfmpegMovie->getFrame(10);
					if (is_object($oFrame) && method_exists($oFrame, 'toGDImage'))
					{
						$mImage = $oFrame->toGDImage();			
						if ($mImage)
						{
							//@imagejpeg($mImage, sprintf($sImageLocation, ''), 120);
							@imagejpeg($mImage, sprintf($sImageLocation, ''), 480);
							@imagedestroy($mImage);
						}
					}
				}
			}    		   		

			// 'Completed Image: ' . sprintf($sImageLocation, '')
    		$this->_debug(_p('videochannel.completed_image_simagelocation',array('sImageLocation' => sprintf($sImageLocation, ''))));

    		Phpfox::getLib('image')->createThumbnail(sprintf($sImageLocation, ''), sprintf($sImageLocation, '_120'), 120, 120);
			Phpfox::getLib('image')->createThumbnail(sprintf($sImageLocation, ''), sprintf($sImageLocation, '_480'), 480, 480);
    		
    		@unlink(sprintf($sImageLocation, ''));    		    		

			// 'Completed: ' . $sDestination
			$this->_debug(_p('videochannel.completed_sdestination', array('sDestination' => $sDestination)));

			$aSql['image_server_id'] = Phpfox::getLib('request')->getServer('PHPFOX_SERVER_ID');

			Phpfox::getLib('cdn')->put($sDestination);
			$aSql['server_id'] = Phpfox::getLib('request')->getServer('PHPFOX_SERVER_ID');

			if ($bIsAttachment)
			{
				$this->_aVideoDetails = array(
					'video_id' => $aVideo['video_id'],
					'destination' => $sNewPath,
					'extension' => 'flv',
					'duration' => (isset($aSql['duration']) ? $aSql['duration'] : null)				
				);			
			}
			else
			{
				$this->database()->update($this->_sTable, $aSql, 'video_id = ' . $aVideo['video_id']);
				
				if ($aVideo['module_id'] != 'videochannel' && Phpfox::hasCallback($aVideo['module_id'], 'uploadVideo'))
				{
					$aCallback = Phpfox::callback($aVideo['module_id'] . '.uploadVideo', $aVideo['item_id']);		
				}							
				
				$bUpdatePoints = ($aVideo['module_id'] == 'videochannel' ? (Phpfox::getUserParam('videochannel.approve_video_before_display') ? false : true) : true);
				
				if ($bUpdatePoints === true)
				{
					$aCallback = null;
					if ($aVideo['module_id'] != 'videochannel' && Phpfox::hasCallback($aVideo['module_id'], 'convertVideo'))
					{
						$aCallback = Phpfox::callback($aVideo['module_id'] . '.convertVideo', $aVideo);	
					}					
				
					(Phpfox::isModule('feed') ? Phpfox::getService('feed.process')->callback($aCallback)->add('videochannel', $aVideo['video_id'], $aVideo['privacy'], $aVideo['privacy_comment'], $aVideo['item_id']) : null);
					
					// Update user activity
					Phpfox::getService('user.activity')->update(Phpfox::getUserId(), 'videochannel');
				}			
			}
		}
		
		if (defined('PHPFOX_CLI'))
		{
			unlink(PHPFOX_DIR_CACHE . 'video.lock');
		}
		if (!Phpfox_Error::isPassed())
		{
			return false;
		}
		return true;
	}
	
	public function getDetails()
	{
		return $this->_aVideoDetails;
	}
	
	/**
	 * If a call is made to an unknown method attempt to connect
	 * it to a specific plug-in with the same name thus allowing 
	 * plug-in developers the ability to extend classes.
	 *
	 * @param string $sMethod is the name of the method
	 * @param array $aArguments is the array of arguments of being passed
	 */
	public function __call($sMethod, $aArguments)
	{
		/**
		 * Check if such a plug-in exists and if it does call it.
		 */
		if ($sPlugin = Phpfox_Plugin::get('videochannel.service_convert__call'))
		{
			return eval($sPlugin);
		}
			
		/**
		 * No method or plug-in found we must throw a error.
		 */
		Phpfox_Error::trigger('Call to undefined method ' . __CLASS__ . '::' . $sMethod . '()', E_USER_ERROR);
	}	
	
	private function _exec($sCmd)
	{
		$this->_debug($sCmd);
		
		$this->_sLastLineCode = exec($sCmd . ' 2>&1', $aOutput);		
		
		if (defined('PHPFOX_CLI'))
		{
			echo implode("\n", $aOutput);
		}
		
		$this->_debug(implode("\n", $aOutput));
		
		return $this;
	}
	
	private function _debug($sMessage)
	{
		if (defined('PHPFOX_CLI'))
		{
			echo $sMessage . "\n";
		}		
		
		// if (PHPFOX_DEBUG)
		{
			$sCacheName = PHPFOX_DIR . 'file' . PHPFOX_DS . 'log' . PHPFOX_DS . 'phpfox_video_log_' . date('d_m_y', time()) . '.log.php';				
			
			if ($hFile = @fopen($sCacheName, 'a'))
			{			
				$sData = "#### " . microtime() . " ####\n";
				$sData .= "[" . Phpfox::getLib('file')->filesize(memory_get_usage()) . "]" . "{$sMessage}\n";
				$sData .= "####\n";
	
				fwrite($hFile, $sData);
				fclose($hFile);		
			}	
		}
	}
	
	private function _check($sDestination)
	{
		if (!file_exists($sDestination))
		{
			$this->_debug(_p('videochannel.unable_to_convert_video'));
				
			if (!empty($this->_sLastLineCode))
			{
				Phpfox_Error::set($this->_sLastLineCode);
			}				
							
			return Phpfox_Error::set(_p('videochannel.unable_to_convert_video'));
		}		
			
		// Temp. disable error reporting
		Phpfox_Error::skip(true);	
			
		require_once(PHPFOX_DIR_LIB . 'getid3' . PHPFOX_DS . 'getid3' . PHPFOX_DS . 'getid3.php');
			
		$oGetId3 = new getID3;
			
		$aMetaData = $oGetId3->analyze($sDestination);	
		
		// Return back error reporting
		Phpfox_Error::skip(false);			
			
		if (isset($aMetaData['error']) && count($aMetaData['error']))
		{			
			if (!empty($this->_sLastLineCode))
			{
				Phpfox_Error::set($this->_sLastLineCode);
			}
				
			return Phpfox_Error::set(implode('<br />', array_map('ucfirst', $aMetaData['error'])));
		}		
			
		return true;
	}
}

?>

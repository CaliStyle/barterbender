<?php

$aBundleScripts[] = [
    'channel.js' => 'module_videochannel',
    'videochannel.js' => 'module_videochannel',
    'jquery.cycle.all.js' => 'module_videochannel',
    'jhslide.js' => 'module_videochannel'
];
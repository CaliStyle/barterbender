<?php 
/**
 * [PHPFOX_HEADER]
 */
 
defined('PHPFOX') or exit('NO DICE!'); 

?>
{literal}
<style>
div.newline{
	padding:0px;
}
</style>
{/literal}
{module name='petition.helplogo'}
{$aItem.content_parsed|parse}
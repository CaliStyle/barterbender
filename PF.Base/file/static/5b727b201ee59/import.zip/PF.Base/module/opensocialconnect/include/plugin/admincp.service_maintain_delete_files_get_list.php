<?php
$aPluginFiles = array_merge($aPluginFiles, [
    'PF.Base/module/opensocialconnect/include/plugin/core.template_block_template_menu_1.php'
]);

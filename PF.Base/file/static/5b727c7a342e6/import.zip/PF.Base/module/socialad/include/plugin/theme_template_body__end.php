<?php 
;
/*
 * @todo : remove later
$sYnSaAdScriptPath = Phpfox::getParam('core.path') .  'module/socialad/static/jscript/ad.js';

echo "
<script src='$sYnSaAdScriptPath'> 
</script>
";
 */

if(Phpfox::isModule('socialad')){
	echo "
	<style type=\"text/css\">
		.activity_feed_content_image{
			float: none;
		}
	</style>";
}

;
?>


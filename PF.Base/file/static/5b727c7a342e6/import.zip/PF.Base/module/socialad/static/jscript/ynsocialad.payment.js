;
(function(window, undefined) {
	var payment = {
	};
	window.ynsocialad.payment = payment;
}(window, undefined));




<?php
/**
 * [PHPFOX_HEADER]
 */

defined('PHPFOX') or exit('NO DICE!');

/**
 * 
 * 
 * @copyright		[YOUNET_COPPYRIGHT]
 * @author  		MinhTA
 * @package  		Module_socialad
 */

// Add and edit request both go here 
class Socialad_Component_Controller_Payment_Index extends Phpfox_Component 
{
	/**
	 * Class process method wnich is used to execute this component.
	 */
	public function process()
	{
		Phpfox::isUser(true);
		// Phpfox::getService('socialad.helper')->buildMenu();

		// Phpfox::getLib('template')->setBreadCrumb(_p('ad'));
		$this->template()->assign(array( 
		))
			->setHeader(array(
				)
			)
			->setFullSite();

		Phpfox::getService('socialad.helper')->loadSocialAdJsCss();
		$this->template()
			->setBreadcrumb(_p('ad'), $this->url()->makeUrl('socialad.ad'))
			->setBreadcrumb(_p('payments'), $this->url()->makeUrl('socialad.payments'), true);
	}

	/**
	 * Garbage collector. Is executed after this class has completed
	 * its job and the template has also been displayed.
	 */
	public function clean()
	{
	
	}

}


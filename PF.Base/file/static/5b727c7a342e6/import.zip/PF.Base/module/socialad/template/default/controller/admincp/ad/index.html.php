{module name='socialad.ad.ad-filter'}
<div class="clear"></div>
<div id="js_ynsa_ad_list">
{module name='socialad.ad.ad-list'}
</div>



{module name='socialad.payment.transaction-filter'}

<div class="clear"></div>
<div id="js_ynsa_payment_list">
{module name='socialad.payment.transaction-list'}
</div>


{php}
	Phpfox::getLib('template')->getBuiltFile($this->_aVars['sSaTemplate']);
{/php}

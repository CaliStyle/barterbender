
{literal}
<style type="text/css">
      h1{margin:0;padding:0;font-size:2em;}
      p,dl{font-size:1.2em;line-height:170%;margin-bottom:20px}
      dl,dt,dd{padding:0;margin:0}
    .faqs{padding-top:20px}
    .faqs dt{font-weight:bold;background:url('{/literal}{$corePath}{literal}module/socialad/static/image/q.gif') 0 4px no-repeat;padding:3px 0 15px 30px;position:relative;}
    .faqs dt:hover{cursor:pointer}
    .faqs dd{background:url('{/literal}{$corePath}{literal}module/socialad/static/image/a.gif') 0 2px no-repeat;padding:0 0 20px 30px;position:relative;color:#333}
    .faqs .hover{color:#990000;text-decoration:underline}
</style>
{/literal}

{module name='socialad.sub-menu'}


<button
	id="js_ynsa_addfaq_btn"
	class="btn btn-success btn-sm"
	onclick="tb_show('{phrase var='add_new_faq'}', $.ajaxBox('socialad.showAddNewFAQPopup', 'height=400&width=350')); return false;"
 >{phrase var='add_new_faq'}</button>
<div class="clear"></div>
{if $aFAQ}
    <div>
        <dl class="faqs">
            {foreach from=$aFAQ item=FAQ}
                <dt>{$FAQ.question}</dt>
                <dd>{$FAQ.answer}</dd>
            {/foreach}
        </dl>
    </div>
{else}
    {phrase var='no_faq_available'}
{/if}


{literal}
    <script type="text/javascript">
        $Behavior.ynsaFaq = function() {
            $('.faqs dd').hide();  /*Hide all DDs inside .faqs*/
            $('.faqs dt').hover(function(){$(this).addClass('hover')},function(){$(this).removeClass('hover')}).click(function(){  /*Add class "hover" on dt when hover*/
            $(this).next().slideToggle('normal');  /*Toggle dd when the respective dt is clicked*/
            });
        }
    </script>
{/literal}

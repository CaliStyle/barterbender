<?php 
return array(
  'package' => array(
    'type' => 'library',
    'name' => 'openinviter',
    'version' => '1.1',
    'path' => 'application/libraries/openinviter',
    'repository' => 'socialengine.net',
    'meta' => array(
      'title' => 'openinviter',
      'author' => 'YouNet integration',
    ),
    'directories' => array(
      'application/libraries/openinviter',
    )
  )
);
?>
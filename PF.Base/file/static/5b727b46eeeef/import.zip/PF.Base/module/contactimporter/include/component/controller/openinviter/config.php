<?php
$openinviter_settings=array(
'username'=>"tigertest", 'private_key'=>"278c54a410d4ff247ffa646e21cfc4c4", 'cookie_path'=>"/file/cache", 'message_body'=>"You are invited to http://modules2buy.com/youlog_se4_advanced", 'message_subject'=>" is inviting you to http://modules2buy.com/youlog_se4_advanced", 'transport'=>"curl", 'local_debug'=>"on_error", 'remote_debug'=>"", 'hosted'=>"0", 'proxies'=>array(),
'stats'=>"", 'plugins_cache_time'=>"18000000000", 'plugins_cache_file'=>"oi_plugins.php", 'update_files'=>"1", 'stats_user'=>"", 'stats_password'=>"");
?>
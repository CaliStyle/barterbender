<?php
$_pluginInfo=array(
	'name'=>'Twitter',
	'version'=>'1.1.1',
	'description'=>"Get the contacts from a Twitter account",
	'base_version'=>'1.8.0',
	'type'=>'social',
	'check_url'=>'http://twitter.com',
	'requirement'=>'user',
	'allowed_domains'=>false,
    'photo_import'=>true,
	);
/**
 * Twitter Plugin
 * 
 * Imports user's contacts from Twitter and
 * posts a new tweet from the user as a invite.
 * 
 * @author OpenInviter
 * @version 1.0.3
 */
class twitter extends OpenInviter_Base
	{
	private $login_ok=false;
	public $showContacts=true;
	public $requirement='user';
	public $internalError=false;
	public $allowed_domains=false;
	protected $timeout=30;
	protected $maxUsers=100;
	
	public $debug_array=array(
				'initial_get'=>'username',
				'login_post'=>'inbox',
				'friends_url'=>'list-tweet',
				'wall_message'=>'latest_text',
				'send_message'=>'inbox'
				);
	
	/**
	 * Login function
	 * 
	 * Makes all the necessary requests to authenticate
	 * the current user to the server.
	 * 
	 * @param string $user The current user.
	 * @param string $pass The password for the current user.
	 * @return bool TRUE if the current user was authenticated successfully, FALSE otherwise.
	 */
	public function login_imobile($user,$pass)
		{
		$this->resetDebugger();
		$this->service='twitter';
		$this->service_user=$user;
		$this->service_pass=$pass;
		if (!$this->init()) return false;
		$res=$this->get("https://mobile.twitter.com/session/new",true);
		if ($this->checkResponse('initial_get',$res))
			$this->updateDebugBuffer('initial_get',"https://mobile.twitter.com/session/new",'GET');
		else 
			{
			$this->updateDebugBuffer('initial_get',"https://mobile.twitter.com/session/new",'GET',false);
			$this->debugRequest();
			$this->stopPlugin();	
			return false;
			}
		
		$form_action="https://mobile.twitter.com/session";
        $auth = $this->getElementString($res,'name="authenticity_token" type="hidden" value="','"');

        
		$post_elements=array('authenticity_token'=>$auth,'username'=>$user,'password'=>$pass);
		$res=$this->post($form_action,$post_elements,true);
		if ($this->checkResponse('login_post',$res))
			$this->updateDebugBuffer('login_post',"{$form_action}",'POST',true,$post_elements);
		else 
			{
			$this->updateDebugBuffer('login_post',"{$form_action}",'POST',false,$post_elements);
			$this->debugRequest();
			$this->stopPlugin();	
			return false;
			}	
        $_SESSION['twitter_user_'.$this->session_id] = $user;
        $_SESSION['twitter_pass_'.$this->session_id] = $pass;			
		$this->login_ok="http://mobile.twitter.com/{$user}/followers";
		return true;
		}
    public function login($user,$pass)
        {
        $this->resetDebugger();
        $this->service='twitter';
        $this->service_user=$user;
        $this->service_pass=$pass;
        if (!$this->init()) return false;
        $res=$this->get("https://twitter.com/login",true);
        if ($this->checkResponse('initial_get',$res))
            $this->updateDebugBuffer('initial_get',"https://twitter.com/login",'GET');
        else 
            {
            $this->updateDebugBuffer('initial_get',"https://twitter.com/login",'GET',false);
            $this->debugRequest();
            $this->stopPlugin();    
            return false;
            }
        
        $form_action="https://twitter.com/sessions";
        $auth = $this->getElementString($res,'name="authenticity_token" type="hidden" value="','"');

         
        $post_elements=array('authenticity_token'=>$auth,'session[username_or_email]'=>$user,'session[password]'=>$pass,'return_to_ssl'=>'return_to_ssl','redirect_after_login'=>'redirect_after_login','commit'=>'Sign In');
        $res=$this->post($form_action,$post_elements,true);
        if ($this->checkResponse('login_post',$res))
            $this->updateDebugBuffer('login_post',"{$form_action}",'POST',true,$post_elements);
        else 
            {
            $this->updateDebugBuffer('login_post',"{$form_action}",'POST',false,$post_elements);
            $this->debugRequest();
            $this->stopPlugin();    
            return false;
            }
        $_SESSION['twitter_user_'.$this->session_id] = $user;
        $_SESSION['twitter_pass_'.$this->session_id] = $pass;            
        $this->login_ok="http://twitter.com/{$user}/followers";
        return true;
        }
	/**
	 * Get the current user's contacts
	 * 
	 * Makes all the necesarry requests to import
	 * the current user's contacts
	 * 
	 * @return mixed The array if contacts if importing was successful, FALSE otherwise.
	 */	
    
	public function getMyContacts()
		{
            
        $this->login_ok = "http://twitter.com/{$this->service_user}/followers";
		if (!$this->login_ok)
			{
			$this->debugRequest();
			$this->stopPlugin();
			return false;
			}
		else $url=$this->login_ok;
		$res=$this->get($url);
        // SMALL CHANGE TO MAIN FREIND PAGE
        $this->debug_array['friends_url'] = 'thumb vcard';
        
		if ($this->checkResponse('friends_url',$res))
			$this->updateDebugBuffer('friends_url',"{$url}",'GET');
		else 
			{
			$this->updateDebugBuffer('friends_url',"{$url}",'GET',false);
			$this->debugRequest();
			$this->stopPlugin();	
			return false;
			}	
            
            
        $contacts=array();$countUsers=0;
        do
        {
            $bulk=array();    
            $nextPage=false;
            $res=str_replace(array('  ','    ',PHP_EOL,"\n","\r\n"),array('','','','',''),$res); 
            preg_match_all("#\<td class=\"thumb vcard\"\>\<a href=\"http\:\/\/twitter\.com\/(.+)\" hreflang=\".{2}\"\>\<img alt=\"\" border=\"0\" height=\"48\" src=\"(.+)\" style=\"#U",$res,$bulk); 
            
            if (!empty($bulk))
                {
                foreach($bulk[1] as $key=>$user)
                    {
                        if (!empty($user))
                        {
                            $contacts[$user] = array('name'=>$user,'pic'=>$bulk[2][$key]);
                            $countUsers++;
                        }                
                    
                    }
                }
            if ($countUsers>$this->maxUsers) break; 
            $next_arr = array();    
            preg_match_all("#class=\"pagination\"\>\<a href=\"(.+)\" class=\"section_links\" rel=\"me next\"#U",$res,$next_arr);               
            if (!empty($next_arr[1][0]))
                $nextPage = $next_arr[1][0];                    
            
            if (!empty($nextPage)) $res=$this->get('http://twitter.com'.$nextPage);
            unset($bulk);
        } 
        while ($nextPage);
        
       
	
		
		return $contacts;	
		}
    
    public function getMyContacts_mobile()
        {
        if (!$this->login_ok)
            {
            $this->debugRequest();
            $this->stopPlugin();
            return false;
            }
        else $url=$this->login_ok;
        $res=$this->get($url);
        if ($this->checkResponse('friends_url',$res))
            $this->updateDebugBuffer('friends_url',"{$url}",'GET');
        else 
            {
            $this->updateDebugBuffer('friends_url',"{$url}",'GET',false);
            $this->debugRequest();
            $this->stopPlugin();    
            return false;
            }    
        $contacts=array();$countUsers=0;        
        do
            {            
            $nextPage=false;
            $doc=new DOMDocument();libxml_use_internal_errors(true);if (!empty($res)) $doc->loadHTML($res);libxml_use_internal_errors(false);
            $xpath=new DOMXPath($doc);
            $query="//a[@name]";$data=$xpath->query($query);
            foreach ($data as $node)
                {
                $user=(string)$node->getAttribute("name");
                if (!empty($user)) {$contacts[$user]=$user; $countUsers++; }                                    
                }            
            $query="//div[@class='list-more']/a";$data=$xpath->query($query);
            foreach($data as $node) { $nextPage=$node->getAttribute("href");break; }                    
            if ($countUsers>$this->maxUsers) break; 
            if (!empty($nextPage)) $res=$this->get('http://mobile.twitter.com'.$nextPage);            
            }
        while ($nextPage);            
        return $contacts;    
        }


	/**
	 * Send message to contacts
	 * 
	 * Sends a message to the contacts using
	 * the service's inernal messaging system
	 * 
	 * @param string $cookie_file The location of the cookies file for the current session
	 * @param string $message The message being sent to your contacts
	 * @param array $contacts An array of the contacts that will receive the message
	 * @return mixed FALSE on failure.
	 */
	public function sendMessage($session_id,$message,$contacts)
		{
            
        if (!isset($_SESSION['twitter_user_'.$session_id])) return false;
        $user = $_SESSION['twitter_user_'.$session_id];
        $pass = $_SESSION['twitter_pass_'.$session_id];
        unset($_SESSION['twitter_user_'.$session_id]);
        unset($_SESSION['twitter_pass_'.$session_id]);
        $this->login_imobile($user,$pass);
		$countMessages=0;
        $res=$this->get("http://mobile.twitter.com");$auth=$this->getElementString($res,'name="authenticity_token" type="hidden" value="','"');
        unset($_COOKIE['twitter_authenticity_token']);
		$message['body'] = "Join us at:\nhttp://".$this->getElementString($message['body'],'http://',"\n");
        
		$form_action="http://mobile.twitter.com";
		$post_elements=array("authenticity_token"=>$auth,'tweet[text]'=>$message['body'],'tweet[in_reply_to_status_id]'=>false,'tweet[lat]'=>false,'tweet[long]'=>false,'tweet[place_id]'=>false,'tweet[display_coordinates]'=>false);	
        
		$res=$this->post($form_action,$post_elements,true);					
		
		foreach($contacts as $screen_name)
			{
			$countMessages++;$form_action='http://mobile.twitter.com/inbox';						
			$post_elements=array('authenticity_token'=>$auth,'message[text]'=>$message['body'],'message[recipient_screen_name]'=>$screen_name,'return_to'=>false,);
			$res=$this->post($form_action,$post_elements,true);
			if ($this->checkResponse('send_message',$res))
				$this->updateDebugBuffer('send_message',"{$form_action}",'POST',true,$post_elements);
			else 
				{
				$this->updateDebugBuffer('send_message',"{$form_action}",'POST',false,$post_elements);
				$this->debugRequest();
				$this->stopPlugin();	
				return false;
				}											
			sleep($this->messageDelay);
			if ($countMessages>$this->maxMessages) {$this->debugRequest();$this->resetDebugger();$this->stopPlugin();break;}
			}
		}

	/**
	 * Terminate session
	 * 
	 * Terminates the current user's session,
	 * debugs the request and reset's the internal 
	 * debudder.
	 * 
	 * @return bool TRUE if the session was terminated successfully, FALSE otherwise.
	 * 
	 */	
	public function logout()
		{
         if (isset($_SESSION['twitter_user_'.$this->getSessionID()])) 
         {
             unset($_SESSION['twitter_user_'.$this->getSessionID()]);
             unset($_SESSION['twitter_pass_'.$this->getSessionID()]);    
         }
		if (!$this->checkSession()) return false;
		$this->get("http://twitter.com/logout");
		$this->debugRequest();
		$this->resetDebugger();
		$this->stopPlugin();
		return true;	
		}
	}	

?>
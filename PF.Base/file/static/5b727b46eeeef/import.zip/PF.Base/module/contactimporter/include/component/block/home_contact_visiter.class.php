<?php
/**
 * [PHPFOX_HEADER]
 */

defined('PHPFOX') or exit('NO DICE!');

class Contactimporter_Component_Block_Home_contact_visiter extends Phpfox_Component
{    
    public function process()
    {
    }
}

?>
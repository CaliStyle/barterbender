<?php

defined('PHPFOX') or exit('NO DICE!');


class AdvancedMarketplace_Component_Controller_Add extends Phpfox_Component
{
    /**
     * Class process method wnich is used to execute this component.
     */
    public function process()
    {
        Phpfox::isUser(true);
        $bIsEdit = false;
        $bIsSetup = ($this->request()->get('req4') == 'setup' ? true : false);
        $sAction = $this->request()->get('req3');
        $sModule = $this->request()->get('module');
        $iItemId = $this->request()->getInt('item');

        $cfInfors = PHPFOX::getService("advancedmarketplace")->backend_getcustomfieldinfos();
        $aListing = array();
        if ($iEditId = $this->request()->get('id')) {
            if (($aListing = Phpfox::getService('advancedmarketplace')->getForEdit($iEditId, true))) {
                $bIsEdit = true;
                if (Phpfox::isModule('tag') && isset($aListing['listing_id'])) {
                    $aTags = Phpfox::getService('tag')->getTagsById('advancedmarketplace', $aListing['listing_id']);
                    if (isset($aTags[$aListing['listing_id']])) {
                        $aListing['tag_list'] = '';
                        foreach ($aTags[$aListing['listing_id']] as $aTag) {
                            $aListing['tag_list'] .= ' ' . $aTag['tag_text'] . ',';
                        }
                        $aListing['tag_list'] = trim(trim($aListing['tag_list'], ','));
                    }
                }
                (Phpfox::getUserId() == $aListing['user_id'] ? Phpfox::getUserParam('advancedmarketplace.can_edit_own_listing',
                    true) : Phpfox::getUserParam('advancedmarketplace.can_edit_other_listing', true));
                $this->setParam('aListing', $aListing);
                $this->setParam(array(
                        'country_child_value' => $aListing['country_iso'],
                        'country_child_id' => $aListing['country_child_id']
                    )
                );
                // custom field
                $iCatId = $aListing["category"]["category_id"];
                $iListingId = $aListing["listing_id"];
                $aCustomFields = PHPFOX::getService("advancedmarketplace.customfield.advancedmarketplace")->frontend_loadCustomFields($iCatId,
                    $iListingId);
                ///custom field
                $this->template()->setHeader(array(
                        '<script type="text/javascript">$Behavior.advancedmarketplaceEditCategory = function(){ var aCategories = explode(\',\', \'' . $aListing['categories'] . '\'); for (i in aCategories) { $(\'#js_mp_holder_\' + aCategories[i]).show(); $(\'#js_mp_category_item_\' + aCategories[i]).attr(\'selected\', true); } }</script>'
                    )
                )
                    ->assign(array(
                            'aForms' => $aListing,
                            'aCustomFields' => $aCustomFields,
                            'cfInfors' => $cfInfors,
                        )
                    );
            }
            $sModule = $aListing['module_id'];
            $iItemId = $aListing['item_id'];
        } else {
            $this->template()->assign('aForms', array('price' => '0.00'));
            $this->template()
                ->assign(array(
                        'aCustomFields' => array(),
                        'cfInfors' => $cfInfors,
                    )
                );
        }
        $aValidation = array(
            'title' => _p('advancedmarketplace.provide_a_name_for_this_listing'),
            'country_iso' => _p('advancedmarketplace.provide_a_location_for_this_listing'),
            'price' => array(
                'def' => 'money',
                'title' => _p('provide_a_valid_price')
            )
        );
        $oValidator = Phpfox::getLib('validator')->set(array(
                'sFormName' => 'js_advancedmarketplace_form',
                'aParams' => $aValidation
            )
        );

        if (!empty($sModule) && Phpfox::hasCallback($sModule, 'getItem')) {
            $aCallback = Phpfox::callback($sModule . '.getItem', $iItemId);
            if ($aCallback === false) {
                return Phpfox_Error::display(_p('Cannot find the parent item.'));
            }
        }
        if ($aVals = $this->request()->getArray('val')) {
            $integrateParams = array();
            if ($module_id = $this->request()->get('module', false)) {
                $integrateParams['module_id'] = $module_id;
            }
            if ($item_id = $this->request()->get('item', false)) {
                $integrateParams['item_id'] = $item_id;
            }
            if (count($integrateParams)) {
                $aVals = array_merge($aVals, $integrateParams);
            }

            $aCustomFields = $this->request()->get('customfield');

            // valid for custom field...
            $aCustomFieldsReq = $this->request()->get('customfield_req');
            if (!$aCustomFieldsReq) {
                $aCustomFieldsReq = array();
            }
            $aCusValidation = array();
            foreach ($aCustomFieldsReq as $key => $aReq) {
                $aCusValidation[$key] = _p("advancedmarketplace.afield_is_required", array("afield" => _p($aReq)));
            }
            // bad way to valid... :(
            $oCusValidator = clone Phpfox::getLib('validator');
            $oCusValidator = $oCusValidator->set(array(
                    'sFormName' => 'js_advancedmarketplace_form',
                    'aParams' => $aCusValidation
                )
            );
            $cFieldValid = $oCusValidator->isValid($aCustomFields);
            ///valid for custom field...
            if ($cFieldValid && $oValidator->isValid($aVals)) {
                if ($aVals['price'] < 0) {
                    Phpfox_Error::set(_p('provide_a_valid_price'));
                }
                if ($bIsEdit) {
                    if (isset($aVals['draft_publish'])) {
                        $aVals['post_status'] = 1;
                    } else {
                        $aVals['time_stamp'] = PHPFOX_TIME;
                        $aVals['update_timestamp'] = PHPFOX_TIME;
                    }
                    if (Phpfox::getService('advancedmarketplace.process')->update($aListing['listing_id'], $aVals,
                        $aListing['user_id'], $aListing)) {
                        if ($aCustomFields) {
                            Phpfox::getService('advancedmarketplace.customfield.process')->frontend_updateCustomFieldData($aCustomFields,
                                $aListing['listing_id']);
                        }
                        $aCustom = $this->request()->get('custom');
                        if (!empty($aCustom)) {
                            phpfox::getService('advancedmarketplace.custom.process')->addCustomListing($aListing['listing_id'],
                                $aCustom);
                        }

                        (($sPlugin = Phpfox_Plugin::get('advancedmarketplace.component_controller_add_process_update_complete')) ? eval($sPlugin) : false);

                        if (Phpfox::isMobile()) {
                            $this->url()->send('advancedmarketplace.add', array('id' => $aListing['listing_id']),
                                _p('advancedmarketplace.listing_successfully_updated'));
                        } else {
                            if ($bIsSetup) {
                                switch ($sAction) {
                                    case 'customize':
                                        $this->url()->send('advancedmarketplace.add.invite.setup',
                                            array('id' => $aListing['listing_id']),
                                            _p('advancedmarketplace.successfully_uploaded_images_for_this_listing'));
                                        break;
                                    case 'invite':
                                        $this->url()->permalink('advancedmarketplace.detail', $aListing['listing_id'],
                                            $aListing['title'], true,
                                            _p('advancedmarketplace.successfully_invited_users_for_this_listing'));
                                        break;
                                }
                            } else {
                                switch ($this->request()->get('page_section_menu')) {
                                    case 'js_mp_block_customize':
                                        $this->url()->send('advancedmarketplace.add.customize',
                                            array('id' => $aListing['listing_id']),
                                            _p('advancedmarketplace.successfully_uploaded_images'));
                                        break;
                                    case 'js_mp_block_invite':
                                        $this->url()->send('advancedmarketplace.add.invite',
                                            array('id' => $aListing['listing_id']),
                                            _p('advancedmarketplace.successfully_invited_users'));
                                        break;
                                    default:
                                        $this->url()->send('advancedmarketplace.add',
                                            array('id' => $aListing['listing_id']),
                                            _p('advancedmarketplace.listing_successfully_updated'));
                                        break;
                                }
                            }
                        }
                    }
                } else {
                    if (($iFlood = Phpfox::getUserParam('advancedmarketplace.flood_control_advancedmarketplace')) !== 0) {
                        $aFlood = array(
                            'action' => 'last_post', // The SPAM action
                            'params' => array(
                                'field' => 'time_stamp', // The time stamp field
                                'table' => Phpfox::getT('advancedmarketplace'), // Database table we plan to check
                                'condition' => 'user_id = ' . Phpfox::getUserId(), // Database WHERE query
                                'time_stamp' => $iFlood * 60 // Seconds);
                            )
                        );

                        // actually check if flooding
                        if (Phpfox::getLib('spam')->check($aFlood)) {
                            Phpfox_Error::set(_p('advancedmarketplace.you_are_creating_a_listing_a_little_too_soon') . ' ' . Phpfox::getLib('spam')->getWaitTime());
                        }
                    }

                    if (Phpfox_Error::isPassed()) {
                        if (isset($aVals['draft'])) {
                            $aVals['post_status'] = 2;
                        }

                        if ($iId = Phpfox::getService('advancedmarketplace.process')->add($aVals)) {
                            if ($aCustomFields) {
                                Phpfox::getService('advancedmarketplace.customfield.process')->frontend_updateCustomFieldData($aCustomFields,
                                    $iId);
                            }
                            $aCustom = $this->request()->get('custom');
                            if (!empty($aCustom)) {

                                phpfox::getService('advancedmarketplace.custom.process')->addCustomListing($aListing['listing_id'],
                                    $aCustom);
                            }
                            if (Phpfox::isMobile()) {
                                $this->url()->send('advancedmarketplace.add', array('id' => $iId),
                                    _p('advancedmarketplace.listing_successfully_added'));
                            } else {
                                $this->url()->send('advancedmarketplace.add.customize.setup', array('id' => $iId),
                                    _p('advancedmarketplace.listing_successfully_added'));
                            }
                        }
                    }
                }
            }
        }

        $aCurrencies = Phpfox::getService('core.currency')->get();
        foreach ($aCurrencies as $iKey => $aCurrency) {
            $aCurrencies[$iKey]['is_default'] = '0';

            if (Phpfox::getService('core.currency')->getDefault() == $iKey) {
                $aCurrencies[$iKey]['is_default'] = '1';
            }
        }

        $iTotalImage = 0;
        if ($bIsEdit) {
            $aMenus['detail'] = _p('advancedmarketplace.listing_details');
            if (!Phpfox::isMobile()) {
                $aMenus['customize'] = _p('advancedmarketplace.photos');
                $aMenus['invite'] = _p('advancedmarketplace.invite');
            }
            if (!$bIsSetup) {
                $aMenus['manage'] = _p('advancedmarketplace.manage_invites');
            }

            $iTotalImage = Phpfox::getService('advancedmarketplace')->countImages($aListing['listing_id']);
            $this->template()->buildPageMenu('js_mp_block',
                $aMenus,
                array(
                    'link' => $this->url()->permalink('advancedmarketplace.detail',
                        isset($aListing['listing_id']) ? $aListing['listing_id'] : "", $aListing['title']),
                    'phrase' => _p('advancedmarketplace.view_this_listing')
                )
            );
        }

        $this->template()
            ->setPhrase(array(
                    'advancedmarketplace.you_can_upload_a_jpg_gif_or_png_file',
                    'core.name',
                    'core.status',
                    'core.in_queue',
                    'core.upload_failed_your_file_size_is_larger_then_our_limit_file_size',
                    'core.more_queued_than_allowed'
                )
            );

        $this->template()->setTitle(($bIsEdit ? _p('advancedmarketplace.editing_listing') . ': ' . $aListing['title'] : _p('advancedmarketplace.create_a_advancedmarketplace_listing')))
            ->setBreadcrumb(_p('advancedmarketplace.advancedmarketplace'), $this->url()->makeUrl('advancedmarketplace'))
            ->setBreadcrumb(($bIsEdit ? _p('advancedmarketplace.editing_listing') . ': ' . $aListing['title'] : _p('advancedmarketplace.create_a_listing')),
                $this->url()->makeUrl('advancedmarketplace.add',
                    array('id' => isset($aListing['listing_id']) ? $aListing['listing_id'] : "")), true)
            ->setEditor()
            ->setPhrase(array(
                    'core.select_a_file_to_upload'
                )
            )
            ->setHeader(array(
                    'add.js' => 'module_advancedmarketplace',
                    'progress.js' => 'static_script',
                    '<script type="text/javascript"> var googleApiKey = "' . Phpfox::getParam('core.google_api_key') . '"; $Behavior.marketplaceProgressBarSettings = function(){ if ($Core.exists(\'#js_marketplace_form_holder\')) { oProgressBar = {holder: \'#js_marketplace_form_holder\', progress_id: \'#js_progress_bar\', uploader: \'#js_progress_uploader\', add_more: true, max_upload: ' . (int)Phpfox::getUserParam('advancedmarketplace.total_photo_upload_limit') . ', total: 1, frame_id: \'js_upload_frame\', file_id: \'image[]\'}; $Core.progressBarInit(); } }</script>',
                    'map.js' => 'module_advancedmarketplace',
                    'add.css' => 'module_advancedmarketplace',
                    'pager.css' => 'style_css',
                    'country.js' => 'module_core'
                )
            )
            ->assign(array(
                    'sType' => $this->request()->get('req3'),
                    'sType1' => $this->request()->get('req3'),
                    'sMyEmail' => Phpfox::getUserBy('email'),
                    'sCreateJs' => $oValidator->createJS(),
                    'sGetJsForm' => $oValidator->getJsForm(false),
                    'bIsEdit' => $bIsEdit,
                    'sCategories' => Phpfox::getService('advancedmarketplace.category')->get(),
                    'iMaxFileSize' => (Phpfox::getUserParam('advancedmarketplace.max_upload_size_listing') === 0 ? null : ((Phpfox::getUserParam('advancedmarketplace.max_upload_size_listing') / 1024) * 1048576)),
                    'iTotalImage' => $iTotalImage,
                    'iTotalImageLimit' => Phpfox::getUserParam('advancedmarketplace.total_photo_upload_limit'),
                    'iRemainUpload' => Phpfox::getUserParam('advancedmarketplace.total_photo_upload_limit') - $iTotalImage,
                    'aParamsUpload' => array(
                        'total_image' => $iTotalImage,
                        'total_image_limit' => Phpfox::getUserParam('advancedmarketplace.total_photo_upload_limit'),
                        'remain_upload' => Phpfox::getUserParam('advancedmarketplace.total_photo_upload_limit') - $iTotalImage
                    ),
                    'aCurrencies' => $aCurrencies,
                    'sUserSettingLink' => $this->url()->makeUrl('user.setting'),
                    'googleApiKey' => Phpfox::getParam('core.google_api_key')
                )
            );
        (($sPlugin = Phpfox_Plugin::get('advancedmarketplace.component_controller_add_process')) ? eval($sPlugin) : false);
    }

    /**
     * Garbage collector. Is executed after this class has completed
     * its job and the template has also been displayed.
     */
    public function clean()
    {
        (($sPlugin = Phpfox_Plugin::get('advancedmarketplace.component_controller_add_clean')) ? eval($sPlugin) : false);
    }
}

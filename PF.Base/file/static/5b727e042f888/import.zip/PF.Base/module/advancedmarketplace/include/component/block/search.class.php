<?php
/**
 * [PHPFOX_HEADER]
 */

defined('PHPFOX') or exit('NO DICE!');

/**
 *
 *
 * @copyright       [YOUNET_COPYRIGHT]
 * @author          YouNet Company
 * @package         YouNet_Event
 */
class Advancedmarketplace_Component_Block_Search extends Phpfox_Component
{
    public function process()
    {
        // We'll do not use it anymore. https://jira.younetco.com/browse/FLIST-494
        return false;
    }

    /**
     * Garbage collector. Is executed after this class has completed
     * its job and the template has also been displayed.
     */
    public function clean()
    {
        (($sPlugin = Phpfox_Plugin::get('fevent.component_block_search_clean')) ? eval($sPlugin) : false);
    }
}

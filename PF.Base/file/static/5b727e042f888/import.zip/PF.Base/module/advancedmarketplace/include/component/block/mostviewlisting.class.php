<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class AdvancedMarketplace_Component_Block_MostViewListing extends Phpfox_Component
{

    public function process()
    {
        $iLimit = $this->getParam('limit', 4);

        if (!$iLimit) {
            return false;
        }

        $aConds = ['l.privacy = 0', 'l.post_status != 2', 'l.view_id = 0'];
        list($count, $aMostViewListing) = PHPFOX::getService("advancedmarketplace")->frontend_getListings($aConds,
            'total_view DESC, time_stamp DESC', 0, $iLimit);

        if (count($aMostViewListing) <= 0) {
            $this->template()->assign(array(
                'aMostViewListing' => null,
                'sCustomClassName' => 'ync-block',
            ));
        } else {
            $this->template()->assign(array(
                'sHeader' => _p('advancedmarketplace.most_view_listing'),
                'corepath' => phpfox::getParam('core.path'),
                'aMostViewListing' => $aMostViewListing,
                'bIsViewMore' => $count > $iLimit,
                'sCustomClassName' => 'ync-block',
            ));

            if ($count > $iLimit) {
                $this->template()->assign(array(
                    'aFooter' => array(
                        _p('advancedmarketplace.view_more') => $this->url()->makeUrl('advancedmarketplace.search.sort_most-viewed')
                    )
                ));
            }
        }

        return 'block';
    }

    /**
     * Block settings
     *
     * @return array
     */
    public function getSettings()
    {
        return [
            [
                'info' => _p('advancedmarketplace_block_mostviewlisting_limit_info'),
                'description' => _p('advancedmarketplace_block_mostviewlisting_limit_description'),
                'value' => Phpfox::getParam('advancedmarketplace.total_listing_more_from'),
                'var_name' => 'limit',
                'type' => 'integer'
            ]
        ];
    }

    /**
     * Validation
     *
     * @return array
     */
    public function getValidation()
    {
        return [
            'limit' => [
                'def' => 'int:required',
                'min' => 0,
                'title' => _p('advancedmarketplace_limit_must_greater_or_equal_0',
                    ['var_name' => _p('advancedmarketplace_block_mostviewlisting_limit_info')])
            ]
        ];
    }

    /**
     * Garbage collector. Is executed after this class has completed
     * its job and the template has also been displayed.
     */
    public function clean()
    {
        (($sPlugin = Phpfox_Plugin::get('advancedmarketplace.component_block_mostviewlisting_clean')) ? eval($sPlugin) : false);
    }
}

<?php
function ynam_install401p4()
{
    $oDb = Phpfox::getLib('phpfox.database');
    $oDb->query("UPDATE `" . Phpfox::getT('setting') . "` SET `is_hidden` = 1 WHERE `module_id` = 'advancedmarketplace' AND `var_name` = 'google_api_key_location';");

}

ynam_install401p4();
?>
<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
{if $aMostViewListing !== NULL}

<ul class="ynmarketplace-most-view-block ync-listing-container-mini ync-list-layout">
    {foreach from=$aMostViewListing key=iKey item=aListing}
        <li class="ynmarketplace-most__item ync-item">
            <div class="item-outer">
                {if $aListing.image_path != NULL}
                    <a href="{$aListing.url}" title="{$aListing.title|parse|clean}" class="item-media-src">
                        <span style="background-image: url(
                                {img title=$aListing.title server_id=$aListing.server_id path='advancedmarketplace.url_pic' file=$aListing.image_path suffix='' return_url=true}
                        );"></span>
                    </a>
                {/if}

                <div class="item-inner">
                    <div class="item-title"><a href="{$aListing.url}" title="{$aListing.title|parse|clean}">{$aListing.title}</a></div>
                    <p class="item-price mt-h1 mb-0 {if $aListing.price == '0.00'}text-free{else}text-warning{/if}">
                        {if $aListing.price == '0.00'}
                            {phrase var='advancedmarketplace.free'}
                        {else}
                            {$aListing.currency_id|currency_symbol}{$aListing.price}
                        {/if}
                    </p>
                    <div class="total-view">
                        <span>{$aListing.total_view} {if (int)$aListing.total_view > 1}{phrase var='advancedmarketplace.views'}{else}{phrase var='advancedmarketplace.one_view'}{/if}</span>
                    </div>
                </div>
            </div>
        </li>
    {/foreach}
</ul>
{/if}
<?php


defined('PHPFOX') or exit('NO DICE!');


class AdvancedMarketplace_Component_Block_Invite extends Phpfox_Component
{
    /**
     * Class process method wnich is used to execute this component.
     */
    public function process()
    {
        $iLimit = $this->getParam('limit', 5);

        if (!Phpfox::isUser() || !$iLimit) {
            return false;
        }

        list($iCnt, $aEventInvites) = Phpfox::getService('advancedmarketplace')->getUserInvites($iLimit);

        if (empty($aEventInvites)) {
            $this->template()->assign(array(
                'aEventInvites' => null,
            ));

            return false;
        }

        foreach ($aEventInvites as $iKey => $aEventInvite) {
            $aEventInvites[$iKey]['rating'] = (int)$aEventInvites[$iKey]['rating']/2;
        }

        $this->template()->assign(array(
            'sHeader' => _p('advancedmarketplace.invites'),
            'corepath' => phpfox::getParam('core.path'),
            'aEventInvites' => $aEventInvites,
            'sCustomClassName' => 'ync-block',
        ));

        if ($iCnt > $iLimit) {
            $this->template()->assign(array(
                    'aFooter' => array(
                        _p('advancedmarketplace.view_more') => $this->url()->makeUrl('advancedmarketplace',
                            array('view' => 'invites'))
                    )
                )
            );
        }

        return 'block';
    }

    /**
     * Block settings
     *
     * @return array
     */
    public function getSettings()
    {
        return [
            [
                'info' => _p('advancedmarketplace_block_invite_limit_info'),
                'description' => _p('advancedmarketplace_block_invite_limit_description'),
                'value' => 4,
                'var_name' => 'limit',
                'type' => 'integer'
            ]
        ];
    }

    /**
     * Validation
     *
     * @return array
     */
    public function getValidation()
    {
        return [
            'limit' => [
                'def' => 'int:required',
                'min' => 0,
                'title' => _p('advancedmarketplace_limit_must_greater_or_equal_0',
                    ['var_name' => _p('advancedmarketplace_block_invite_limit_info')])
            ]
        ];
    }

    /**
     * Garbage collector. Is executed after this class has completed
     * its job and the template has also been displayed.
     */
    public function clean()
    {
        (($sPlugin = Phpfox_Plugin::get('advancedmarketplace.component_block_invite_clean')) ? eval($sPlugin) : false);
    }
}

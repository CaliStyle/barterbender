<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
{if $aRecentListing !== NULL}

<div class="ynmarketplace-listing-wapper item-container ync-listing-container ync-list-layout">
    {foreach from=$aRecentListing key=iKey item=aListing}
        <article class="ynmarketplace-listing-inner ync-item">
            <div class="item-outer">
                <div class="ynmarketplace_listing-photo">
                    <a href="{$aListing.url}" class="ynmarketplace_listing-thumb" style="background-image: url({if $aListing.image_path != NULL}
                            {img server_id=$aListing.server_id path='advancedmarketplace.url_pic' return_url=true file=$aListing.image_path suffix='_400' title=$aListing.title }
                        {else}
                           {$corepath}module/advancedmarketplace/static/image/default/noimage.png
                        {/if})" >
                    </a>
                    {if isset($aListing.is_expired)}
                        <div class="ynmarketplace-item-flag">
                            <div class="sticky-label-icon sticky-closed-icon" {if !$aListing.is_featured} style="display:none;"{/if}>
                                <span class="flag-style-arrow"></span>
                                <i class="ico ico-warning"></i>
                            </div>
                        </div>
                    {else}
                        {if $aListing.is_featured || $aListing.is_sponsor}
                            <div class="ynmarketplace-item-flag">
                                {if isset($sView) && $sView == 'featured'}
                                {else}
                                    <div class="sticky-label-icon sticky-featured-icon" {if !$aListing.is_featured} style="display:none;"{/if}>
                                        <span class="flag-style-arrow"></span>
                                        <i class="ico ico-diamond"></i>
                                    </div>                  
                                {/if}   
                                <div class="sticky-label-icon sticky-sponsored-icon" {if !$aListing.is_sponsor} style="display:none;"{/if}>
                                    <span class="flag-style-arrow"></span>
                                    <i class="ico ico-sponsor"></i>
                                </div>
                            </div>
                        {/if}
                    {/if}
                </div>
                <div class="ynmarketplace_listing-infomation">		
                    <a href="{$aListing.url}" class="advynmarketplace_listing-title" title="{$aListing.title|clean}">{$aListing.title}</a>
                    <!-- author -->
                    <div class="item-author mt-1">
                        <span class="item-author-info">{_p var='by_full_name' full_name=$aListing|user:'':'':50:'':'author'}</span>
                        <span>{_p var='on'} {$aListing.time_stamp|convert_time}</span>
                    </div>
                    <!-- description -->
                    <div class="ynmarketplace_listing-description item_view_content">{$aListing.short_description|parse|highlight:'search'|split:25|shorten:200:'...'}</div>  
                    <!-- location -->
                    <a class="ynmarketplace_listing-location fz-12 text-gray-dark space-left error-icon d-block mt-1" href="{url link='advancedmarketplace' val[country_iso]=$aListing.country_iso}"><i class="ico ico-checkin"></i>{$aListing.country_iso|location}</a>
                    <!-- price -->
                     <div class="ynmarketplace_listing-price mt-1 {if $aListing.price == '0.00'}text-free{else}text-warning{/if}">
                        {if $aListing.price == '0.00'}
                            {phrase var='advancedmarketplace.free'}
                        {else}
                            {$aListing.currency_id|currency_symbol}{$aListing.price}
                        {/if}
                    </div>
                </div>
            </div>
        </article>
    {/foreach}
</div>
{if $iTotal>$iLimit}
<div class="ync-viewmore">
    <a href="{url link='advancedmarketplace.search.sort_latest'}" class="item-viewmore">{_p var='core.view_more'}</a>
</div>
{/if}
{/if}
<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<div class="ynmarketplace-seller">
    {if $aCoverPhoto !== ''}
        <div class="ynmarketplace-seller__cover {if $aCoverPhoto !== ''}has_cover{/if}" style="background-image:url({if $aCoverPhoto !== ''}{img server_id=$aCoverPhoto.server_id path='photo.url_photo' file=$aCoverPhoto.destination suffix='_1024' title=$aCoverPhoto.title return_url=true}{/if})">
        </div>
    {else}
        <div class="ynmarketplace-seller__cover" style="background-image:url({$coreUrlModule}advancedmarketplace/static/image/default/default_pagecover.png)">
        </div>
    {/if}


    <div class="ynmarketplace-seller__user">
        <div class="ynmarketplace-seller__avatar text-center">
			{img user=$aListing suffix='_50_square' max_width='50' max_height='50'}
		</div>
		<p class="ynmarketplace-seller__name mb-0 fz-16 text-center mt-1">{$aListing|user}</p>
    </div>

    {if $aListing.user_id != Phpfox::getUserId()}
	<div class="ynmarketplace-seller__follow pl-2 pr-2 mt-2">
        <div class="ynmarketplace-seller__follow__inner mt-1">
            <div class="ynmarketplace-seller__follow__button" id="js_follow_{$iFollower}">
                {if phpfox::getUserId() != $aListing.user_id && phpfox::getParam('advancedmarketplace.can_follow_listings')}
                    {if $bFollow != 'follow'}
                        <button onclick="$(this).addClass('disabled').attr('disabled','disabled'); follow('follow',{$aListing.user_id},{$iFollower}); return false;" type="button" class="btn btn-primary btn-block">{phrase var='advancedmarketplace.follow'}</button>
                    {else}
                        <button onclick="$(this).addClass('disabled').attr('disabled','disabled');follow('unfollow',{$aListing.user_id},{$iFollower}); return false;" type="button" class="btn btn-default btn-block" id="js_follow_{$iFollower}">{phrase var='advancedmarketplace.unfollow'}</button>
                    {/if}
                {/if}
            </div>
	        {if $aListing.user_id != Phpfox::getUserId()}
                <div class="ynmarketplace-seller__follow__button">
    	            <a href="javascript:void()" class="btn btn-default btn-block" onclick="$Core.composeMessage({l}user_id: {$aListing.user_id}{r}); return false;">{phrase var='advancedmarketplace.contact'}</a>
                </div>
	        {/if}
	    </div>
	</div>
    {/if}
</div>

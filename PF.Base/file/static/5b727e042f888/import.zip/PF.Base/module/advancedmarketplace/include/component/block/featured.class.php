<?php


defined('PHPFOX') or exit('NO DICE!');


class AdvancedMarketplace_Component_Block_Featured extends Phpfox_Component
{
    /**
     * Class process method wnich is used to execute this component.
     */
    public function process()
    {
        $iLimit = $this->getParam('limit', 4);

        if (!$iLimit) {
            return false;
        }

        $aFeatured = Phpfox::getService('advancedmarketplace')->getFeatured($iLimit);

        if (!count($aFeatured)) {
            return false;
        }

        $this->template()->assign(array(
                'corepath' => Phpfox::getParam('core.path'),
                'sHeader' => _p('advancedmarketplace.featured_listings'),
                'aFeatured' => $aFeatured,
                'sCustomClassName' => 'ync-block',
            )
        );

        return 'block';
    }

    /**
     * Block settings
     *
     * @return array
     */
    public function getSettings()
    {
        return [
            [
                'info' => _p('advancedmarketplace_block_featured_limit_info'),
                'description' => _p('advancedmarketplace_block_featured_limit_description'),
                'value' => 4,
                'var_name' => 'limit',
                'type' => 'integer'
            ]
        ];
    }

    /**
     * Validation
     *
     * @return array
     */
    public function getValidation()
    {
        return [
            'limit' => [
                'def' => 'int:required',
                'min' => 0,
                'title' => _p('advancedmarketplace_limit_must_greater_or_equal_0',
                    ['var_name' => _p('advancedmarketplace_block_featured_limit_info')])
            ]
        ];
    }

    /**
     * Garbage collector. Is executed after this class has completed
     * its job and the template has also been displayed.
     */
    public function clean()
    {
        (($sPlugin = Phpfox_Plugin::get('advancedmarketplace.component_block_featured_clean')) ? eval($sPlugin) : false);
    }
}

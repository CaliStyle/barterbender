<?php

defined('PHPFOX') or exit('NO DICE!');

class AdvancedMarketplace_Component_Block_FrontEnd_View_selectradio extends Phpfox_Component
{
    public function process()
    {
        $aField = $this->getParam("aField");
        $this->template()->assign(array(
            "sPhraseVarName" => $aField["phrase_var_name"],
            "aField" => $aField,
            'sCustomClassName' => 'ync-block',
        ));
    }
}

<?php

$aPluginFiles = array_merge($aPluginFiles, [
    'PF.Base/module/advancedmarketplace/include/plugin/feed.template_block_entry_2.php'
]);

<?php
defined('PHPFOX') or exit('NO DICE!');
?>
{if !isset($iPage)}
{if $bIsEdit}
{literal}
<script type="text/javascript">
    $Behavior.countryLoad = function() {
        $("#country_iso option[value={/literal}{$aForms.country_iso}{literal}]").prop("selected", true);
    }
</script>
{/literal}
{/if}
{if $bIsEdit && $aForms.view_id == '2'}
<div class="error_message">
	{phrase var='advancedmarketplace.notice_this_listing_is_marked_as_sold'}
</div>
<div class="main_break"></div>
{/if}

{$sCreateJs}
<form method="post" action="{url link='current'}" enctype="multipart/form-data" onsubmit="return startProcess({$sGetJsForm}, false);" id="js_advancedmarketplace_form">
	{if $bIsEdit}
		<div><input type="hidden" name="id" id="ilistingid" value="{$aForms.listing_id}" /></div>
        <input type="hidden" name="type" value="advancedmarketplace">
    {/if}

	<div id="js_custom_privacy_input_holder">
	{if $bIsEdit && empty($sModule) && Phpfox::isModule('privacy')}
		{module name='privacy.build' privacy_item_id=$aForms.listing_id privacy_module_id='advancedmarketplace'}
	{/if}
	</div>

	<div><input type="hidden" name="page_section_menu" value="" id="page_section_menu_form" /></div>

	<div id="js_mp_block_detail" class="js_mp_block page_section_menu_holder">

		{if empty($sModule) && !empty($aPages) && !$bIsEdit}
			<div class="table form-group">
				<div class="table_left">Pages</div>
				<div class="table_right">
					<select class="form-control" name="val[page_id]">
						<option value="0">None</option>
						{foreach from=$aPages name=pages item=aPage}
							<option value="{$aPage.page_id}">{$aPage.title}</option>
						{/foreach}
					</select>
				</div>
			</div>
		{/if}

		<div class="form-group">
			{required}<label for="title">{phrase var='advancedmarketplace.what_are_you_selling'}</label>
			<input type="text" class="form-control" name="val[title]" value="{value type='input' id='title'}" id="title" size="40" maxlength="100" />
		</div>

		<div class="form-group">
			{required}<label for="category">{phrase var='advancedmarketplace.category'}:</label>
			{$sCategories}
		</div>

		<div id="advmarketplace_js_customfield_form" class="ync-customfield">
			{if count($aCustomFields) > 0}
				{module name="advancedmarketplace.frontend.customfield" aCustomFields=$aCustomFields cfInfors=$cfInfors}
			{/if}
		</div>

		<div class="form-group">
			<label for="description">{phrase var='advancedmarketplace.short_description'}:</label>
			<textarea class="form-control" rows="6" name="val[short_description]" >{value type='textarea' id='short_description'}</textarea>
		</div>
		<div class="form-group">
			<label for="description">{phrase var='advancedmarketplace.description'}:</label>
			{editor id='description' rows='12'}
		</div>

		<div class="form-group">
			<div class="row ml--1 mr--1">
				<div class="col-xs-6 w-auto pl-1 pr-1">
					{required}<label for="price">{phrase var='advancedmarketplace.price'}:</label>
					<select class="form-control w-auto" name="val[currency_id]">
						{foreach from=$aCurrencies key=sCurrency item=aCurrency}
							<option value="{$sCurrency}"{if $bIsEdit} {value type='select' id='currency_id' default=$sCurrency}{else}{if $aCurrency.is_default} selected="selected"{/if}{/if}>{phrase var=$aCurrency.name}</option>
						{/foreach}
					</select>
				</div>
				<div class="col-xs-6 w-auto pl-1 pr-1">
					<label class="text-tran">price</label>
					<input type="text" class="form-control w-auto" name="val[price]" value="{value type='input' id='price'}" id="price" size="10" maxlength="100" onfocus="this.select();" />
			</div>
			</div>
		</div>

		{if Phpfox::getUserParam('advancedmarketplace.can_sell_items_on_advancedmarketplace')}
			<div class="form-group adv-market-toggle-add">
				<div class="privacy-block-content">
					<div class="item_is_active_holder">
						<span class="js_item_active item_is_active"><input type="radio" name="val[is_sell]" value="1" {value type='radio' id='is_sell' default='1'}/> {phrase var='core.yes'}</span>
						<span class="js_item_active item_is_not_active"><input type="radio" name="val[is_sell]" value="0" {value type='radio' id='is_sell' default='0' selected='true'}/> {phrase var='core.no'}</span>
					</div>
					<div class="inner">
						<label for="postal_code">{phrase var='advancedmarketplace.enable_instant_payment'}:</label>
						<div class="extra_info">
						{phrase var='advancedmarketplace.if_you_enable_this_option_buyers_can_make_a_payment_to_one_of_the_payment_gateways_you_have_on_file_with_us_to_manage_your_payment_gateways_go_a_href_link_here_a' link=$sUserSettingLink}
					</div>
					</div>
				</div>
			</div>
			<div class="form-group adv-market-toggle-add auto-sold">
				<div class="privacy-block-content">
					<div class="item_is_active_holder">
						<span class="js_item_active item_is_active"><input type="radio" name="val[auto_sell]" value="1" {value type='radio' id='auto_sell' default='1' selected='true'}/> {phrase var='core.yes'}</span>
						<span class="js_item_active item_is_not_active"><input type="radio" name="val[auto_sell]" value="0" {value type='radio' id='auto_sell' default='0'}/> {phrase var='core.no'}</span>
					</div>
					<div class="inner">
						<label for="postal_code">{phrase var='advancedmarketplace.auto_sold'}:</label>
						<div class="extra_info">
						{phrase var='advancedmarketplace.if_this_is_enabled_and_once_a_successful_purchase_of_this_item_is_made'}
					</div>
					</div>
				</div>
			</div>
		{/if}

		<div class="form-group ynmarketplace-add-country">
			{required}<label>{phrase var='advancedmarketplace.country'}:</label>
			{select_location}
			{module name='core.country-child'}
			{if !$bIsEdit}
				<div class="extra_info">
					<a href="#" onclick="$(this).parent().hide(); $('#js_mp_add_city').show(); return false;">{phrase var='advancedmarketplace.add_city_zip'}</a>
				</div>
			{/if}
		</div>

		<div id="js_mp_add_city" class="mb-2" {if !$bIsEdit} style="display:none;"{/if}>
			<div class="form-inline row ml--1 mr--1">
				<div class="form-group pl-1 pr-1 col-sm-3">
				    <label for="location">{phrase var='advancedmarketplace.location_venue'}:</label>
				    <div class="d-block">
						<input type="text" class="form-control w-full" name="val[location]" value="{value type='input' id='location'}" id="location" size="40" maxlength="200" />
					</div>
				</div>
				<div class="form-group pl-1 pr-1 col-sm-3">
					<label for="street_address">{phrase var='advancedmarketplace.address'}</label>
					<div class="d-block">
						<input type="text" class="form-control w-full" name="val[address]" value="{value type='input' id='address'}" id="address" size="30" maxlength="200" />
					</div>
				</div>

				<div class="form-group pl-1 pr-1 col-sm-3">
					<label for="city">{phrase var='advancedmarketplace.city'}:</label>
					<div class="d-block">
						<input type="text" class="form-control w-full" name="val[city]" value="{value type='input' id='city'}" id="city" size="20" maxlength="200" />
					</div>
				</div>
				<div class="form-group pl-1 pr-1 col-sm-3">
					<label for="postal_code">{phrase var='advancedmarketplace.zip_postal_code'}:</label>
					<div class="d-block">
						<input type="text" class="form-control w-full" name="val[postal_code]" value="{value type='input' id='postal_code'}" id="postal_code" size="10" maxlength="20" />
					</div>
				</div>
			</div>
		</div>

		<div class="form-group">
            <button id="refresh_map" type="button" class="btn-primary btn-sm mb-1" onclick="adv_inputToMap();">{phrase var='advancedmarketplace.refresh_map'}</button>
            <input type="hidden" name="val[gmap][latitude]" value="{value type='input' id='input_gmap_latitude'}" id="input_gmap_latitude" />
            <input type="hidden" name="val[gmap][longitude]" value="{value type='input' id='input_gmap_longitude'}" id="input_gmap_longitude" />
            <div class="d-block">
	            <div id="mapHolder" class="w-full"></div>
            </div>
        </div>
		{if $bIsEdit && ($aForms.view_id == '0' || $aForms.view_id == '2')}

		<div class="form-group form-group-follow adv-market-toggle-add">
			<div class="privacy-block-content">
				<div class="item_is_active_holder">
					<span class="js_item_active item_is_active"><input type="radio" name="val[view_id]" value="2" {value type='radio' id='view_id' default='2'}/> {phrase var='core.yes'}</span>
					<span class="js_item_active item_is_not_active"><input type="radio" name="val[view_id]" value="0" {value type='radio' id='view_id' default='0' selected='true'}/> {phrase var='core.no'}</span>
				</div>
				<div class="inner">
					<label for="postal_code">{phrase var='advancedmarketplace.closed_item_sold'}:</label>
					<div class="extra_info">
						{phrase var='advancedmarketplace.enable_this_option_if_this_item_is_sold_and_this_listing_should_be_closed'}
					</div>
				</div>
			</div>
		</div>
		{/if}
		{if Phpfox::isModule('tag')}{module name='tag.add' sType=advancedmarketplace}{/if}
		{if empty($sModule) && Phpfox::isModule('privacy')}
			<div class="form-group">
				<label for="">{phrase var='advancedmarketplace.listing_privacy'}:</label>
				{module name='privacy.form' privacy_name='privacy' privacy_info='advancedmarketplace.control_who_can_see_this_listing' default_privacy='advancedmarketplace.display_on_profile'}
			</div>
		{/if}
		{if $bIsEdit && isset($aForms.post_status)}
			<input type="hidden" name="val[post_status]" value="{$aForms.post_status}" />
		{/if}
		<div class="form-group">
			<input type="submit" value="{if $bIsEdit}{phrase var='advancedmarketplace.update'}{else}{phrase var='advancedmarketplace.submit'}{/if}" class="btn btn-primary pull-left mr-1" />
			{if !$bIsEdit}<input type="submit" name="val[draft]" value="{phrase var='advancedmarketplace.save_as_draft'}" class="btn btn-default" />{/if}
			{if $bIsEdit && $aForms.post_status == 2}
				<input type="submit" name="val[draft_publish]" value="{phrase var='advancedmarketplace.publish'}" class="btn btn-success" />
			{/if}
		</div>
	</div>

	<div id="js_mp_block_customize" class="js_mp_block page_section_menu_holder" style="display:none;">
    {module name='advancedmarketplace.photo'}

	</div>

	<div id="js_mp_block_invite" class="js_mp_block page_section_menu_holder" style="display:none;">




            <div class="block">
                <div class="form-group">
                    <label for="js_find_friend">{_p var='invite_friends'}</label>
                    {if isset($aForms.listing_id)}
                    <div id="js_selected_friends" class="hide_it"></div>
                    {module name='friend.search' input='invite' hide=true friend_item_id=$aForms.listing_id friend_module_id='advancedmarketplace' }
                    {/if}
                </div>
                <div class="form-group invite-friend-by-email">
                    <label for="emails">{_p var='invite_people_via_email'}</label>
                    <input name="val[emails]" id="emails" class="form-control" data-component="tokenfield" data-type="email" >
                    <p class="help-block">{_p var='separate_multiple_emails_with_a_comma'}</p>
                </div>
                <div class="form-group">
                    <label for="personal_message">{_p var='add_a_personal_message'}</label>
                    <textarea rows="1" name="val[personal_message]" id="personal_message" class="form-control textarea-auto-scale" placeholder="{_p var='write_message'}"></textarea>
                </div>
                <div class="form-group">
                    <input type="submit" value="{_p var='send_invitations'}" class="btn btn-primary" name="invite_submit"/>
                </div>
            </div>



	</div>
    {if isset($aForms.listing_id) && $bIsEdit}
    <div id="js_mp_block_manage" class="js_mp_block page_section_menu_holder" style="display:none;">
        {module name='advancedmarketplace.list'}
    </div>
    {/if}

</form>
{literal}
<script>
    var sType = {/literal}"{$sType1}"{literal};
	$Behavior.setupInviteLayout = function()
	{
        switch (sType) {
            case 'customize':
                $Core.pageSectionMenuShow('#js_mp_block_customize');
                break;
            case 'invite':
                $Core.pageSectionMenuShow('#js_mp_block_invite');
                break;
            case 'manage':
                $Core.pageSectionMenuShow('#js_mp_block_manage');
                break;
            case 'detail':
                $Core.pageSectionMenuShow('#js_mp_block_detail');
        }
	}
</script>

{/literal}
{/if}

<script type="text/javascript">
    var loadMap = false;
    {literal}
    $Behavior.ynadvInitializeGoogleMapLocation = function() {
        if (loadMap === false) {
            loadMap = true;
            $('#js_country_child_id_value').change(function(){
                debug("Cleaning  city, postal_code and address");
                $('#city').val('');
                $('#postal_code').val('');
                $('#address').val('');
            });
            $('#country_iso, #js_country_child_id_value').change(adv_inputToMap);
            $('#location, #address, #postal_code, #city').blur(adv_inputToMap);
            adv_loadScript('{/literal}{param var='core.google_api_key'}{literal}');
        }
    };
    {/literal}
</script>
<?php
/**
 * User: huydnt
 * Date: 20/01/2017
 * Time: 15:00
 */
defined('PHPFOX') or exit('NO DICE!');
function db_install_401p3()
{
    $oDb = Phpfox::getLib('database');
    if (!$oDb->isField(Phpfox::getT('advancedmarketplace'), 'module_id')) {
        $oDb->query("ALTER TABLE `" . Phpfox::getT('advancedmarketplace') . "` ADD COLUMN `module_id` VARCHAR(75) NOT NULL DEFAULT 'advancedmarketplace';");
    }
    if (!$oDb->isField(Phpfox::getT('advancedmarketplace'), 'item_id')) {
        $oDb->query("ALTER TABLE `" . Phpfox::getT('advancedmarketplace') . "` ADD COLUMN `item_id` INT(11) NOT NULL DEFAULT 0;");
    }
}

db_install_401p3();

<?php 
 
defined('PHPFOX') or exit('NO DICE!'); 

?>
<div class="panel panel-default">
    <div class="panel-heading">
        <div class="panel-title">
            {phrase var='advancedmarketplace.listing_statistics'}
        </div>
    </div>
    <div class="panel-body">
        <div class="form-group">
            {phrase var='advancedmarketplace.total_listings'}:
            <br>
            {$aListingStatistics.total_listings}
        </div>
        <div class="form-group">
            {phrase var='advancedmarketplace.total_available_listings'}:
            <br>
            {$aListingStatistics.available_listings}
        </div>
        <div class="form-group">
            {phrase var='advancedmarketplace.total_closed_listings'}:
            <br>
            {$aListingStatistics.closed_listings}
        </div>
        <div class="form-group">
            {phrase var='advancedmarketplace.total_draft_listings'}:
            <br>
            {$aListingStatistics.draft_listings}
        </div>
        <div class="form-group">
            {phrase var='advancedmarketplace.total_approved_listings'}:
            <br>
            {$aListingStatistics.approved_listings}
        </div>
        <div class="form-group">
            {phrase var='advancedmarketplace.total_featured_listings'}:
            <br>
            {$aListingStatistics.featured_listings}
        </div>
        <div class="form-group">
            {phrase var='advancedmarketplace.total_sponsored_listings'}:
            <br>
            {$aListingStatistics.sponsored_listings}
        </div>
        <div class="form-group">
            {phrase var='advancedmarketplace.total_reviews'}:
            <br>
            {$aListingStatistics.total_reviews}
        </div>
        <div class="form-group">
            {phrase var='advancedmarketplace.total_reviewed_listings'}:
            <br>
            {$aListingStatistics.total_reviewed_listings}
        </div>
    </div>
</div>

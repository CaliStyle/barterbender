<?php
function ynam_install402()
{
    $aHiddenSettings = ['total_listing_more_from', 'how_many_sponsored_listings'];
    foreach ($aHiddenSettings as $sHiddenSetting) {
        Phpfox::getLib('phpfox.database')->query("UPDATE `" . Phpfox::getT('setting') . "` SET `is_hidden` = 1 WHERE `module_id` = 'advancedmarketplace' AND `var_name` = '$sHiddenSetting';");
    }
}

ynam_install402();

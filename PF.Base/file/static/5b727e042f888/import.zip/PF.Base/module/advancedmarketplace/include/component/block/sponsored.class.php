<?php

defined('PHPFOX') or exit('NO DICE!');


class AdvancedMarketplace_Component_Block_Sponsored extends Phpfox_Component
{
    /**
     * Class process method wnich is used to execute this component.
     */
    public function process()
    {
        $iLimit = $this->getParam('limit', 4);

        if (!Phpfox::isModule('ad') || !$iLimit) {
            return false;
        }

        $aItems = Phpfox::getService('advancedmarketplace')->getSponsorListings($iLimit);
        if (empty($aItems)) {
            return false;
        }

        foreach ($aItems as $aItem) {
            Phpfox::getService('ad.process')->addSponsorViewsCount($aItem['sponsor_id'], 'advancedmarketplace');
        }

        $this->template()->assign(array(
                'corepath' => Phpfox::getParam('core.path'),
                'sHeader' => _p('advancedmarketplace.sponsored_listing'),
                'aFooter' => array(
                    _p('advancedmarketplace.encourage_sponsor_listing') => $this->url()->makeUrl('advancedmarketplace',
                        array('view' => 'my', 'sponsor' => 'help'))
                ),
                'aSponsorListings' => $aItems,
                'sCustomClassName' => 'ync-block'
            )
        );

        return 'block';
    }

    /**
     * Block settings
     *
     * @return array
     */
    public function getSettings()
    {
        return [
            [
                'info' => _p('advancedmarketplace_block_sponsored_limit_info'),
                'description' => _p('advancedmarketplace_block_sponsored_limit_description'),
                'value' => Phpfox::getParam('advancedmarketplace.how_many_sponsored_listings'),
                'var_name' => 'limit',
                'type' => 'integer'
            ]
        ];
    }

    /**
     * Validation
     *
     * @return array
     */
    public function getValidation()
    {
        return [
            'limit' => [
                'def' => 'int:required',
                'min' => 0,
                'title' => _p('advancedmarketplace_limit_must_greater_or_equal_0',
                    ['var_name' => _p('advancedmarketplace_block_sponsored_limit_info')])
            ]
        ];
    }

    /**
     * Garbage collector. Is executed after this class has completed
     * its job and the template has also been displayed.
     */
    public function clean()
    {
        (($sPlugin = Phpfox_Plugin::get('advancedmarketplace.component_block_sponsored_clean')) ? eval($sPlugin) : false);
    }
}

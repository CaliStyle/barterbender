<?php 
defined('PHPFOX') or exit('NO DICE!');
?>
 <div class="sticky-label-icon sticky-sponsored-icon">
    <span class="flag-style-arrow"></span>
    <i class="ico ico-sponsor"></i>
</div>
<ul class="ynmarketplace-sponsore-block ync-listing-container-mini ync-grid-layout">
    {foreach from=$aSponsorListings name=listings item=aListing}
        <li class="ync-item">
            <div class="item-outer">
                {if $aListing.image_path != NULL}
                    <a href="{url link='ad.sponsor' view=$aListing.sponsor_id}" title="{$aListing.title|parse|clean}" class="item-media-src"><span style="background-image: url({img title=$aListing.title path='advancedmarketplace.url_pic' file=$aListing.image_path suffix='' server_id=$aListing.server_id return_url=true});"></span></a>
                {/if}
                <div class="item-inner">
                    <div class="item-title">
                        <a href="{url link='ad.sponsor' view=$aListing.sponsor_id}" title="{$aListing.title|parse|clean}">{$aListing.title|shorten:50:'...'|split:25}</a>
                    </div>
                    <p class="item-description mb-0">{$aListing.short_description|parse|clean}</p>
                    <p class="mb-0 mt-h1 {if $aListing.price == '0.00'}text-free{else}text-warning {/if}">
                        {if $aListing.price == '0.00'}
                            {phrase var='advancedmarketplace.free'}
                        {else}
                            {$aListing.currency_id|currency_symbol}{$aListing.price|number_format:2}
                        {/if}
                    </p>
                    <div class="mb-0 mt-h1 item-rating">
                        <span class="fz-12 text-gray-dark mr-1">{$aListing.total_view} {if (int)$aListing.total_view > 1}{phrase var='advancedmarketplace.views'}{else}{phrase var='advancedmarketplace.one_view'}{/if}</span>
                    </div>
                </div>
            </div>
        </li>
    {/foreach}
</ul>

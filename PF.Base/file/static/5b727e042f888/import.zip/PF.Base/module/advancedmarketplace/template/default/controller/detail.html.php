<?php

defined('PHPFOX') or exit('NO DICE!');

?>
<div class="ynmarketplace-detail-page ync-detail">
    <div class="ync-detail-info">
        <div class="item-info-image">{img user=$aListing suffix='_50_square'}</div>
        <div class="item-info-main">
            <span class="item-author">{_p var='by_user' full_name=$aListing|user:'':'':50:'':'author'}</span>
            <span class="item-time">{_p var='on'} {$aListing.time_stamp|date:'advancedmarketplace.advancedmarketplace_view_time_stamp'}</span>
        </div>
        {if ($aListing.user_id == Phpfox::getUserId() && Phpfox::getUserParam('advancedmarketplace.can_edit_own_listing')) || Phpfox::getUserParam('advancedmarketplace.can_edit_other_listing')
        || ($aListing.user_id == Phpfox::getUserId() && Phpfox::getUserParam('advancedmarketplace.can_delete_own_listing')) || Phpfox::getUserParam('advancedmarketplace.can_delete_other_listings')
        || (Phpfox::getUserParam('advancedmarketplace.can_feature_listings'))
        }
        <div class="ync-detail-bar">
            {if Phpfox::getParam('advancedmarketplace.can_print_a_listing')}
                <a class="aitem print remove_otheraction ync-option-button" target="_blank" href="{url link="advancedmarketplace.print"}{$aListing.listing_id}">
                    <i class="ico ico-printer-o"></i>
                </a>
            {/if}
            <div class="item_bar_action_holder">
                <span data-toggle="dropdown" class="ync-option-button item_bar_action dropdown-toggle" aria-haspopup="true" aria-expanded="true"><i class="ico ico-gear-o"></i></span>
                <ul class="dropdown-menu dropdown-menu-right" id="js_blog_entry_options_{$aListing.listing_id}">
                    {template file='advancedmarketplace.block.menu'}
                </ul>
            </div>
        </div>
        {/if}
    </div>

    {if $aListing.view_id != 1}
    <div class="ync-total-viewlike">
        <div class="item-feed-action">
            {module name='feed.mini-feed-action'}
        </div>
        <span class="item-total-viewlike">
            <span class="item-view">
                {if $aListing.total_view > 1}
                    <span class="item-number">{$aListing.total_view}</span> {_p var = 'advancedmarketplace.views'}
                {else}
                    <span class="item-number">{$aListing.total_view}</span> {_p var = 'advancedmarketplace.one_view'}
                {/if}
            </span>
        </span>
    </div>
    {/if}

    <div class="ynmarketplace-detail-page-wapper sticky-root-js mb-2 mt-2">
        <div class="ynmarketplace-detail-page__price">
            {if $aListing.price > 0}
                <span class="fz-28 fz-xs-20 text-warning mr-1 fw-bold number">{$sListingPrice}</span>
                {if $aListing.user_id != Phpfox::getUserId()}
                    {if $aListing.is_sell && $aListing.view_id != '2' && $aListing.price != '0.00'}
                        <form method="post" action="{url link='advancedmarketplace.purchase'}">
                            <input type="hidden" name="id" value="{$aListing.listing_id}" />
                            {if Phpfox::isUser()}
                            <button type="submit" class="btn btn-primary"><i class="ico ico-cart-o mr-1"></i>{phrase var='advancedmarketplace.buy_now'}</button>
                            {else}
                            <button type="button" class="btn btn-primary" onclick="window.location.href='{url link='user.login'}'">{phrase var='advancedmarketplace.login_to_buy'}</button>
                            {/if}
                        </form>
                    {/if}
                {/if}
            {elseif $aListing.price == '0.00'}
                <span class="fz-28 fz-xs-20 text-warning mr-1 fw-bold number">{_p var='advancedmarketplace.free'}</span>
            {/if}
        </div>
        <div class="ync-outer-rating ync-rating-md ync-outer-rating-row full">
            <div class="ync-outer-rating-row">
                <div class="ync-rating-star">
                    {for $i = 0; $i < 5; $i++}
                        {if $i < (int)$rating}
                            <i class="ico ico-star" aria-hidden="true"></i>
                        {elseif ((round($rating) - $rating) > 0) && ($rating - $i) > 0}
                            <i class="ico ico-star half-star" aria-hidden="true"></i>
                        {else}
                            <i class="ico ico-star disable" aria-hidden="true"></i>
                        {/if}
                    {/for}
                </div>
            </div>
            <div class="ync-rating-count-review-wrapper">
                <span class="ync-rating-count-rating hidden"><i class="ico ico-star" aria-hidden="true"></i>{$rating}</span>
                <span class="ync-rating-count-review">
                    <span class="item-number">{$iRatingCount}</span>
                    {if $iRatingCount > 1 }
                        <span class="item-text">{_p var = 'advancedmarketplace.reviews'}</span>
                    {else}
                        <span class="item-text">{_p var = 'advancedmarketplace.review'}</span>
                    {/if}
                </span>
            </div>
        </div>
    </div>
    <div class="ynmarketplace-detail-page-wapper mobile hidden sticky-js">
        <div class="ynmarketplace-detail-page__price">
            {if $aListing.price > 0}
                <span class="fz-28 fz-xs-20 text-warning fw-bold number">{$sListingPrice}</span>
                {if $aListing.user_id != Phpfox::getUserId()}
                    {if $aListing.is_sell && $aListing.view_id != '2' && $aListing.price != '0.00'}
                        <form method="post" action="{url link='advancedmarketplace.purchase'}">
                            <input type="hidden" name="id" value="{$aListing.listing_id}" />
                            {if Phpfox::isUser()}
                            <button type="submit" class="btn btn-primary btn-sm"><i class="ico ico-cart-o mr-1"></i>{phrase var='advancedmarketplace.buy_now'}</button>
                            {else}
                            <button type="button" class="btn btn-primary btn-sm" onclick="window.location.href='{url link='user.login'}'">{phrase var='advancedmarketplace.login_to_buy'}</button>
                            {/if}
                        </form>
                    {/if}
                {/if}
            {elseif $aListing.price == '0.00'}
                <span class="fz-28 fz-xs-20 text-warning mr-1 fw-bold number">{_p var='advancedmarketplace.free'}</span>
            {/if}
        </div>
    </div>

    {if $aListing.image_path != NULL}
        <div class="ms-vertical-template ynmarketplace_slider-detail ms-tabs-vertical-template dont-unbind" id="ynmarketplace_slider-detail">
            {foreach from=$aImages name=images item=aImage}
                <div class="ms-slide ms-skin-default dont-unbind">
                    <img src="{$core_path}module/advancedmarketplace/static/masterslider/blank.gif" data-src="{img return_url=true server_id=$aListing.server_id path='advancedmarketplace.url_pic' file=$aImage.image_path suffix=''}"/>
                    <img class="ms-thumb" src="{img return_url=true server_id=$aListing.server_id path='advancedmarketplace.url_pic' file=$aImage.image_path suffix='_400'}" alt="thumb" />
                </div>
            {/foreach}
        </div>
    {/if}
    <div class="ync-detail-content">
        <div id="js_advancedmarketplace_listingdetail_tab" class="">
            <div class="page_section_menu ynmarketplace-detail-tab-js" id="yn_tab">
                <ul class="nav nav-tabs nav-justified">
                    <li class="active">
                        <a id="yn_show_yn_listingcontent" href="#">{phrase var='advancedmarketplace.listing_detail'}</a>
                    </li>

                    <li class="">
                        <a id="yn_show_yn_listingrating" href="#">
                            {phrase var='advancedmarketplace.review'} (<span class="review-count">{if isset($iRatingCount)}{$iRatingCount}{else}0{/if}</span>)
                        </a>
                    </li>
                </ul>
            </div>
            
            <div class="">
                <div id="yn_listingcontent">
                    {module name="advancedmarketplace.listingdetail"}
                </div>

                <div id="yn_listingrating" style="display: none;">
                    {module name="advancedmarketplace.review" aRating=$aRating iCount=$iCount iPage=$iPage iSize=$iSize}
                </div>
            </div>
        </div>
    </div>

    {if isset($aListing.categories) && null != $aListing.categories && count($aListing.categories) > 0}
        <div class="ync-item-info-group">
            <div class="ync-item-info">
                <div class="ync-category">
                    <span class="ync-item-label">{_p var='advancedmarketplace.category'}:</span>
                    <div class="ync-item-content">{$aListing.categories|category_display}</div>
                </div>
            </div>
        </div>
    {/if}

    <div class="ync-addthis">
        {addthis url=$aListing.bookmark_url title=$aListing.title}
    </div>

    <div class="item-detail-feedcomment ync-detail-comment">
        {plugin call='advancedmarketplace.template_default_controller_detail_extra_info'}

    	<div {if $aListing.view_id != 0}style="display:none;" class="js_moderation_on"{/if}>
            <div class="item-detail-feedcomment">{module name='feed.comment'}</div>
    	</div>
    </div>
</div>

<div class="native-float-div">
	<a style="display: none;" class="aitem" onclick="$Core.composeMessage({ldelim}'user_id': <?php echo PHPFOX::getUserId(); ?>{rdelim}); return false;" href="">
		<img src="{$corepath}module/advancedmarketplace/static/image/default/item_mail.png" />
	</a>
	<a style="display: none;" class="aitem yn_reviewrating" href="" alt="{phrase var="advancedmarketplace.rate_this_listing"}" title="{phrase var="advancedmarketplace.rate_this_listing"}">
		<img src="{$corepath}module/advancedmarketplace/static/image/default/item_comment.png" />
	</a>
</div>

{literal}
<script language="javascript" type="text/javascript">
	var iCheck = 0;
	function updateReviewCount(iCount) {
		
	}
	$Behavior.advancedmarketplaceRating = function(){
		$(".yn_reviewrating").children("button").click(function(evt){
			evt.preventDefault();
			var page = ($("#xf_page").size() > 0)?$("#xf_page").val():0;
			tb_show("{/literal}{phrase var="advancedmarketplace.rate_this_product" phpfox_squote=true}{literal}", $.ajaxBox('advancedmarketplace.ratePopup', 'height=300&page=' + page + '&width=550&id={/literal}{$aListing.listing_id}{literal}'));
			return false;
		});
	};
	$Behavior.advancedmarketplaceViewDetail = function(){
		var fadeTTime = 100;
		$("#yn_show_yn_listingcontent").click(function(evt){
			evt.preventDefault();
			$("#yn_listingcontent").stop(false, false).fadeIn(fadeTTime, function(){
				$("#yn_listingrating").fadeOut(fadeTTime);
			});
			$("#yn_tab").find(".active").removeClass("active");
			$(this).parent().addClass("active");
			return false;
		});
		$("#yn_show_yn_listingrating").click(function(evt){
			evt.preventDefault();
			$("#yn_listingrating").stop(false, false).fadeIn(fadeTTime, function(){
				$("#yn_listingcontent").fadeOut(fadeTTime);
			});
			$("#yn_tab").find(".active").removeClass("active");
			$(this).parent().addClass("active");
			return false;
		});
		
		if(iCheck == 0)
		{
			$("#yn_listingrating").hide();
			iCheck++;
		}
		$(".remove_otheraction").unbind();
	};

    $Behavior.initDetailSlide = function() {
        var ele = $('#ynmarketplace_slider-detail');
        if (ele.prop('built') || !ele.length) return false;
        ele.prop('built', true).addClass('dont-unbind-children');
        var slider = new MasterSlider();

        slider.setup('ynmarketplace_slider-detail' , {
            width: ele.width(),
            height: 504,
            space: 16,
            view:'basic',
            dir:'v',
            autoplay: true
        });

        slider.control('arrows');   
        slider.control('scrollbar' , {dir:'v'});    
        slider.control('thumblist' , {autohide:false ,dir:'v'});

        ele.val(0);

        slider.api.addEventListener(MSSliderEvent.CHANGE_START , function(){
            if ($('.ms-thumbs-cont .ms-thumb-frame').length < 2){
                $('.ms-thumbs-cont').parents('.ms-vertical-template.ynmarketplace_slider-detail').addClass('one-slide');
            }
            if (slider.api.count() < 6){
                $('#ynmarketplace_slider-detail').addClass('less-4-slide');
            }
        });

        $Behavior.initDetailSlide = function() {}
    };

    $Behavior.checkScroll = function() {
        if ($('.ynmarketplace-detail-page').length){
            var tab_detail = $('.ynmarketplace-detail-tab-js').position();
            var tab_detail_position = tab_detail.top;

            $(window).off('scroll').on('scroll', function () {
                var scroll = $(window).scrollTop();

                if(scroll >= tab_detail_position){
                    $(".sticky-js").insertBefore("#left");

                    setTimeout(function(){
                        $('.sticky-js').addClass('set-position');
                    }, 400);
                } else {
                    $(".sticky-js").insertBefore(".sticky-root-js");

                    setTimeout(function(){
                        $('.sticky-js').removeClass('set-position');
                    }, 400);
                }
            });

            $Behavior.checkScroll = function() {}
        }
    };
</script>
{/literal}
$Ready(function(){
    $("#ynmarketplace-slider").owlCarousel({
        nav: true,
        loop: false,
        items: 1,
        dots: false,
        autoplayTimeout: 3000,
    	autoplay: true,
        lazyContent: true,
        loop: true,
        navText: ['<i class="ico ico-angle-left"></i>','<i class="ico ico-angle-right"></i>'],
	    responsive:{
	        0:{
	        	smartSpeed: 250,
	        	nav: false,
	        	autoplayTimeout: 2500
	        },
	        767:{
	        	smartSpeed: 800,
	        	nav: true,
	        	autoplayTimeout: 3000
	        }
	    }
    });
})
<?php
/**
 * [PHPFOX_HEADER]
 *
 * @copyright		[PHPFOX_COPYRIGHT]
 * @author  		Raymond Benc
 * @package 		Phpfox
 * @version 		$Id: photo.html.php 1298 2009-12-05 16:19:23Z Raymond_Benc $
 */

defined('PHPFOX') or exit('NO DICE!');
?>
<div class="advancedmarketplace-module manage-photo uploader-photo-fix-height">
    <div class="block">
        <div id="js_advancedmarketplace_form_holder" style="display: none">
            {if $iTotalImage < $iTotalImageLimit}
            {module name='core.upload-form' type='advancedmarketplace' params=$aParamsUpload}
            <div class="advancedmarketplace-module cancel-upload">
                <!--                <a href="javascript:void(0)" onclick="$('#js_advancedmarketplace_form_holder').hide();$('.manage-photo-title').show();$('.item-container').show();"><i class="ico ico-arrow-left"></i>&nbsp;{_p var='cancel_upload'}</a>-->
                <a href="{permalink module='advancedmarketplace/detail' id=$iListingId title=$aForms.title}" style="float:right;" id="js_listing_done_upload" class="text-uppercase"><i class="ico ico-check"></i>&nbsp;{_p var='finish_upload'}</a>
            </div>
            {else}
            <p>{_p var='you_cannot_add_more_image_to_your_listing'}</p>
            {/if}
        </div>

        <div class="manage-photo-title">
            <span class="fw-bold" id="js_listing_total_photo">{$iTotalImage} {if $iTotalImage == 1}{_p var='photo'}{else}{_p var='photos'}{/if}</span>
            <a href="javascript:void(0)" id="js_listing_upload_photo" data-toggle="collapse" data-target="#js_advancedmarketplace_form" onclick="$('#js_advancedmarketplace_form_holder').show();$('.manage-photo-title').hide();$('.item-container').hide();" class="fw-bold" {if $iTotalImage >= $iTotalImageLimit}style="display:none"{/if} style="float:right;">
                <i class="ico ico-upload-cloud"></i>&nbsp;{_p var='upload_new_photos'}
            </a>
        </div>
        {if count($aImages)}
        <div class="content item-container">
            {foreach from=$aImages name=images item=aImage}
            <article title="{_p var='click_to_set_as_default_image'}" onclick="$('.is-default').hide(); $(this).find('.is-default').show(); $.ajaxCall('advancedmarketplace.setDefault', 'id={$aImage.image_id}'); return false;" id="js_photo_holder_{$aImage.image_id}" class="px-1 mb-2 js_mp_photo" style="display: inline-block">
                <div class="item-outer">
                    <div class="item-media">
                        <a href="javascript:void(0)" style="background-image: url('{img server_id=$aImage.server_id  path='advancedmarketplace.url_pic' file=$aImage.image_path suffix='_400_square' max_width='120' max_height='120' class='js_mp_fix_width' return_url=true}');">
                            <span class="item-photo-delete" title="{_p var='delete_this_image_for_the_listing'}" onclick="$Core.jsConfirm({l}message:'{_p var='are_you_sure' phpfox_squote=true}'{r}, function(){l} $('#js_photo_holder_{$aImage.image_id}').remove(); $.ajaxCall('advancedmarketplace.deleteImage', 'id={$aImage.image_id}&listing_id={$aForms.listing_id}'); $('#js_mp_image_{$aImage.image_id}').remove(); {r}, function(){l}{r}); return false;"><i class="ico ico-close"></i></span>
                            <div class="is-default" {if $aForms.image_path != $aImage.image_path}style="display:none"{/if}><div class="item-default"><i class="ico ico-photo-star-o"></i>{_p var='default_photo'}</div></div>
                        </a>
                    </div>
                </div>
            </article>
            {/foreach}
        </div>
        {else}
        <div class="extra_info">{_p var='no_photos_found'}</div>
        {/if}
    </div>
</div>

<?php
function ynam_install402p1()
{
    db()->delete(':block', ['component' => 'detailview', 'product_id' => 'younet_advmarketplace4']);
    db()->delete(':block', ['component' => 'price', 'product_id' => 'younet_advmarketplace4']);
    db()->update(':setting', ['var_name' => 'advancedmarketplace_paging_mode', 'phrase_var_name' => 'setting_advancedmarketplace_paging_mode'], ['module_id' => 'advancedmarketplace', 'product_id' => 'younet_advmarketplace4', 'var_name' => 'paging_mode', 'phrase_var_name' => 'setting_paging_mode']);
}

ynam_install402p1();

<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
{if (Phpfox::getParam('advancedmarketplace.days_to_expire_listing') > 0) && ( $aListing.time_stamp < (PHPFOX_TIME - (Phpfox::getParam('advancedmarketplace.days_to_expire_listing') * 86400)) )}
<div class="error_message">
	{phrase var='advancedmarketplace.listing_expired_and_not_available_main_section'}
</div>
{/if}

{if $aListing.view_id == 1}
    {template file='core.block.pending-item-action'}
{/if}


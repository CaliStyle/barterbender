
$Behavior.advancedmarketplaceAdd = function()
{
	$('.js_mp_category_list').change(function()
	{
		var $this = $(this);
		var iParentId = parseInt(this.id.replace('js_mp_id_', ''));
		// var iCatId = document.getElementById('js_mp_id_0').value;
		iCatId = $this.val();
		if(!iCatId) {
			iCatId = parseInt($this.parent().attr("id").replace('js_mp_holder_', ""));
		}

		$.ajaxCall('advancedmarketplace.frontend_loadCustomFields', 'catid='+iCatId+'&lid='+$("#ilistingid").val());
		$('.js_mp_category_list').each(function()
		{
			if (parseInt(this.id.replace('js_mp_id_', '')) > iParentId)
			{
				$('#js_mp_holder_' + this.id.replace('js_mp_id_', '')).hide();				
				
				this.value = '';
			}
		});
		
		$('#js_mp_holder_' + $(this).val()).show();
	});	
}

$Core.advancedmarketplace =
    {
        sUrl: '',

        url: function (sUrl) {
            this.sUrl = sUrl;
        },

        action: function (oObj, sAction) {
            aParams = $.getParams(oObj.href);

            $('.dropContent').hide();

            switch (sAction) {
                case 'edit':
                    window.location.href = this.sUrl + 'add/id_' + aParams['id'] + '/';
                    break;
                case 'delete':
                    var url = this.sUrl;
                    $Core.jsConfirm({}, function () {
                        window.location.href = url + 'delete_' + aParams['id'] + '/';
                    }, function () {
                    });
                    break;
                default:

                    break;
            }

            return false;
        },

        dropzoneOnSending: function (data, xhr, formData) {
            $('#js_advancedmarketplace_form').find('input[type="hidden"]').each(function () {
                formData.append($(this).prop('name'), $(this).val());
            });
        },

        dropzoneOnSuccess: function (ele, file, response) {
            $Core.advancedmarketplace.processResponse(ele, file, response);
        },

        dropzoneOnError: function (ele, file) {

        },
        dropzoneQueueComplete: function () {
            $('#js_listing_done_upload').show();
        },
        processResponse: function (t, file, response) {
            // response = JSON.parse(response);
            if (typeof response.id !== 'undefined') {
                file.item_id = response.id;
                if (typeof t.data('submit-button') !== 'undefined') {
                    var ids = '';
                    if (typeof $(t.data('submit-button')).data('ids') !== 'undefined') {
                        ids = $(t.data('submit-button')).data('ids');
                    }
                    $(t.data('submit-button')).data('ids', ids + ',' + response.id);
                }
            }
            // show error message
            if (typeof response.errors != 'undefined') {
                for (var i in response.errors) {
                    if (response.errors[i]) {
                        $Core.dropzone.setFileError('advancedmarketplace', file, response.errors[i]);
                        return;
                    }
                }
            }
            return file.previewElement.classList.add('dz-success');
        }
    };
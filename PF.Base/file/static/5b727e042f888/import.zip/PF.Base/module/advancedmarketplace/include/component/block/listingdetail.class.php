<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class AdvancedMarketplace_Component_Block_ListingDetail extends Phpfox_Component
{
    public function process()
    {
        $aListing = ($this->getParam("aListing"));

        $sFullDescription = $aListing['description'];
        $iLengthDescription = strlen($sFullDescription);

        // custom field
        $iCatId = $aListing["category"]["category_id"];
        $iListingId = $aListing["listing_id"];
        // var_dump($iCatId);exit;
        $aCustomFields = PHPFOX::getService("advancedmarketplace.customfield.advancedmarketplace")->frontend_loadCustomFields($iCatId,
            $iListingId);
        $cfInfors = PHPFOX::getService("advancedmarketplace")->backend_getcustomfieldinfos();
        ///custom field
        $this->template()->assign(array(
            'corepath' => phpfox::getParam('core.path'),
            'aListing' => $aListing,
            'aCustomFields' => $aCustomFields,
            'cfInfors' => $cfInfors,
            'iLengthDescription' => $iLengthDescription,
            'sHeader' => '',
            'apiKey' => Phpfox::getParam('core.google_api_key'),
            'sCustomClassName' => 'ync-block',
        ))
            ->setPhrase(array(
                'advancedmarketplace.get_directions'
            ));

        return 'block';
    }
}

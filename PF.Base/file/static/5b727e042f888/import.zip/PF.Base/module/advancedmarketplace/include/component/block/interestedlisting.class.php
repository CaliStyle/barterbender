<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class AdvancedMarketplace_Component_Block_InterestedListing extends Phpfox_Component
{
    public function process()
    {
        $iLimit = $this->getParam('limit', 4);

        if (!$iLimit) {
            return false;
        }

        $bIsViewMore = false;
        $aListing = $this->getParam('aListing');
        list($iCnt, $aInterestedListings) = PHPFOX::getService("advancedmarketplace")->frontend_getInterestedListings($aListing['listing_id'], $iLimit);

        if (empty($aInterestedListings)) {
            return false;
        }

        if ($iCnt > phpfox::getParam('advancedmarketplace.total_listing_more_from')) {
            $bIsViewMore = true;
        }

        $this->template()->assign(array(
            'sHeader' => _p('advancedmarketplace.listing_you_may_interested'),
            'corepath' => phpfox::getParam('core.path'),
            'aInterestedListings' => $aInterestedListings,
            'bIsViewMore' => $bIsViewMore,
            'sCustomClassName' => 'ync-block',
        ));

        return 'block';
    }

    /**
     * Block settings
     *
     * @return array
     */
    public function getSettings()
    {
        return [
            [
                'info' => _p('advancedmarketplace_block_interested_limit_info'),
                'description' => _p('advancedmarketplace_block_interested_limit_description'),
                'value' => 4,
                'var_name' => 'limit',
                'type' => 'integer'
            ]
        ];
    }

    /**
     * Validation
     *
     * @return array
     */
    public function getValidation()
    {
        return [
            'limit' => [
                'def' => 'int:required',
                'min' => 0,
                'title' => _p('advancedmarketplace_limit_must_greater_or_equal_0',
                    ['var_name' => _p('advancedmarketplace_block_interested_limit_info')])
            ]
        ];
    }

    /**
     * Garbage collector. Is executed after this class has completed
     * its job and the template has also been displayed.
     */
    public function clean()
    {
        (($sPlugin = Phpfox_Plugin::get('advancedmarketplace.component_block_interestedlisting_clean')) ? eval($sPlugin) : false);
    }
}

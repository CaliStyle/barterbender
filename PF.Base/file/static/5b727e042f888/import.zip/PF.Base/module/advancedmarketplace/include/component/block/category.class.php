<?php


defined('PHPFOX') or exit('NO DICE!');


class AdvancedMarketplace_Component_Block_Category extends Phpfox_Component
{
    /**
     * Class process method wnich is used to execute this component.
     */
    public function process()
    {

        if (defined('PHPFOX_IS_USER_PROFILE')) {
            return false;
        }

        $sCategory = $this->getParam('sCategory');
        $aCategories = Phpfox::getService('advancedmarketplace.category')->getForBrowseFrontEnd($sCategory);

        if (empty($aCategories))
        {
            return false;
        }

        if (!is_array($aCategories))
        {
            return false;
        }

        $this->template()->assign(array(
                'aCategories' => $aCategories,
                'sCategory' => $sCategory,
                'sHeader' => ($sCategory === null ? _p('categories') : _p('advancedmarketplace.sub_categories')),
                'sCustomClassName' => 'ync-block'
            )
        );


        return 'block';
    }



    /**
     * Garbage collector. Is executed after this class has completed
     * its job and the template has also been displayed.
     */
    public function clean()
    {
        (($sPlugin = Phpfox_Plugin::get('advancedmarketplace.component_block_category_clean')) ? eval($sPlugin) : false);
    }
}

<?php
defined('PHPFOX') or exit('NO DICE!');
?>
<script type="text/javascript">
  oCore['core.disable_hash_bang_support'] = 1;
</script>

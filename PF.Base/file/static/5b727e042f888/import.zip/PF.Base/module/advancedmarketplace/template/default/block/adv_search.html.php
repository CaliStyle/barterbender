<?php
defined('PHPFOX') or exit('NO DICE!');
?>

<div id="js_ync_search_wrapper" class="" >
    <div id="js_ync_search_result" class="hide item_is_active_holder item_selection_active ync-advance-search-button">
        <a id="js_ync_enable_adv_search_btn" href="javascript:void(0)" onclick="ync_core.yncEnableAdvSearch();return false;">
            <i class="ico ico-dottedmore-o"></i>
        </a>
    </div>
</div>
<div id="js_ync_adv_search_wrapper" class="ync-advance-search-form" style="display: none">
    <form id="js_advancedmarketplace_adv_search_wrapper" method="get" onsubmit="return checkOnSearchSubmit()">
        <div class="hidden">
            <input type="hidden" name="s" value="1">
            <input type="hidden" value="{$sListingView}" name="view">
            <input type="hidden" name="search[search]" id="advancedmarketplace_input_core_search"  value="{if isset($sSearch)}{$sSearch}{/if}">
            <input type="hidden" value="{if $bAdvSearch}1{else}0{/if}" id="js_adv_search_value"/>
        </div>

        <div class="form-group">
            <label>{_p var='advancedmarketplace.location'}:</label>
            <div>
                {select_location}
                {module name='core.country-child'}
            </div>
        </div>

        <div class="form-inline mb-2">
            <div class="form-group">
                <label for="">{phrase var='advancedmarketplace.city'}</label>
                <div class="d-block">
                    <input id="search_city" type="text" value="{if isset($sCity)}{$sCity}{/if}" name="city" class="search_keyword form-control" placeholder="{_p var = 'city_name'}">
                </div>
            </div><div class="form-group ml-2 ml-xs-0">
                <label for="">{phrase var='advancedmarketplace.zip_postal_code'}</label>
                <div class="d-block">
                    <input id="search_zipcode" type="text" value="{if isset($sZipCode)}{$sZipCode}{/if}" name="zipcode" class="search_keyword form-control" placeholder="{_p var='xxxxxx'}">
                </div>
            </div>
        </div>

        <div class="form-group clearfix advance_search_form_button">
            <div class="pull-left">
                <span class="advance_search_dismiss" onclick="ync_core.yncEnableAdvSearch(); return false;">
                    <i class="ico ico-close"></i>
                </span>
            </div>
            <div class="pull-right">
                <a class="btn btn-default btn-sm" href="javascript:void(0);" id="js_ync_search_reset">{_p var='reset'}</a>
                <button name="submit" class="btn btn-primary ml-1 btn-sm" ><i class="ico ico-search-o mr-1"></i>{_p var='submit'}</button>
            </div>
        </div>
    </form>
</div>

{literal}
<script type="text/javascript">
    $Ready(function(){
        if($("#js_adv_search_value").val() == 1) {
            $("input[name='search[search]']").val('{/literal}{$sSearch}{literal}');
        }
        $('#js_ync_search_reset').click(function(){
            $("input[name='search[search]']").val('');
            $("#country_iso").val('');
            $("#search_city").val('');
            $("#search_zipcode").val('');
        });
    });

    function checkOnSearchSubmit()
    {
        var search_input = $("#form_main_search input[name='search[search]']");
        if (parseInt(search_input.length) > 0){
            var val = search_input.val();
            $('#js_advancedmarketplace_adv_search_wrapper #advancedmarketplace_input_core_search').val(val);
        }
        return true;
    }
</script>
{/literal}

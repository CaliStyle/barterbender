<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<div id="yn_advmarket_wrapper" class="ynmarketplace_detail-listing">
	<div class="ynmarketplace_detail-listing-item">
		{$aListing.short_description|parse}
	</div>

    {if isset($aListing.map_location) && $aListing.map_location != ""}
        <div class="ynmarketplace_detail-listing-item">
            <p class="ynmarketplace_detail-title mb-0 text-gray-dark">{phrase var='advancedmarketplace.locations'}</p>
            <div class="short_description_content">
                <table>
                    <tr>
                        <td>
                            {$aListing.map_location|clean}
                        </td>
                    </tr>
                </table>
            </div>
            <div class="mt-h1" style="position:relative;">
                <div style="margin-left:-8px; margin-top:-8px; position:absolute; background:#fff; border:8px #F0AD4E solid; width:12px; height:12px; left:50%; top:50%; z-index:200; overflow:hidden; text-indent:-1000px; border-radius:12px;">Marker</div>
                <a href="http://maps.google.com/?q={$aListing.map_location}" target="_blank" title="{phrase var='advancedmarketplace.view_this_on_google_maps'}"><img style="width: 100%;" src="http://maps.googleapis.com/maps/api/staticmap?center={$aListing.map_location}&amp;zoom=16&amp;size=500x200&amp;sensor=false&amp;maptype=roadmap" alt="" /></a>
            </div>
            <div class="p_top_4">
                <a href="http://maps.google.com/?q={$aListing.map_location}" target="_blank">{phrase var='advancedmarketplace.view_this_on_google_maps'}</a>
            </div>
        </div>
    {/if}
	{if count($aCustomFields) > 0}
		{module name="advancedmarketplace.frontend.viewcustomfield" aCustomFields=$aCustomFields cfInfors=$cfInfors}
	{/if}
	<div class="ynmarketplace_detail-listing-item">
        {if $aListing.description|striptag|parse != ''}
            <p class="ynmarketplace_detail-title mb-0 text-gray-dark">{phrase var='advancedmarketplace.descriptions'}</p>
            <div class="short_description_content item_view_content">
                {if $iLengthDescription > 1073}
                    <div id="ynadvmDescription">
                        <span class="js_view_more_parent">
                            <span id="ynadvmDescriptionLess" class="js_view_more_part">
                                {$aListing.description|parse|shorten:'350':'...'|split:350}
                                <div class="item_view_more">
                                    <a onclick="$('#ynadvmDescriptionLess').hide(); $('#ynadvmDescriptionMore').show(); return false;" href="#">{_p var='comment.view_more'}</a>
                                </div>
                            </span>
                        </span>
                    </div>
                {else}
                    <div id="ynadvmDescription">
                        <span class="js_view_more_parent">
                            <span id="ynadvmDescriptionLess" class="js_view_more_part">
                                {$aListing.description|parse}
                            </span>
                        </span>
                    </div>
                {/if}

                <div id="ynadvmDescriptionMore" style="display:none;" class="js_view_more_full">
                    {$aListing.description|parse}
                    <div class="item_view_more">
                        <a onclick="$('#ynadvmDescriptionMore').hide(); $('#ynadvmDescriptionLess').show(); return false;" href="#">{_p var='core.view_less'}</a>
                    </div>
                </div>
            </div>
		{/if}
	</div>
</div>

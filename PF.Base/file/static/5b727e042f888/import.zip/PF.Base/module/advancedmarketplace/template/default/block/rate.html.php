<?php
?>

<script type="text/javascript" src="{$core_url}static/jscript/jquery/plugin/star/jquery.rating.js"></script>
<link rel="stylesheet" type="text/css" href="{$core_url}static/jscript/jquery/plugin/star/jquery.rating.css" />

<div id="js_rating_holder_{$aRatingCallback.type}">
	<form id="form-rating" onsubmit="$(this).ajaxCall('advancedmarketplace.advMarketRating');tb_remove(); return false;" method="post" action="#">
		{*hidden area*}
			<input type="hidden" name="rating[type]" value="{$aRatingCallback.type}" />
			<input type="hidden" name="rating[item_id]" value="{$aRatingCallback.item_id}" />
			<input type="hidden" name="rating[listing_id]" value="{$item_id}" />
		{*end hidden area*}
		{*if isset($aRatingCallback.total_rating)}
		<div class="extra_info" style="padding:4px 0px 0px 4px;">
			<span class="js_rating_total">{$aRatingCallback.total_rating}</span>			
		</div>		
		{/if*}
		<div>
			<textarea placeholder="{$sText}" class="form-control" cols="61" name="rating[comment]"></textarea>
			<input type="hidden" name="page" value="{$page}" />
		</div>
		<div class="advmarket-rating-popup-footer">
			<div class="advmarket-rating-star-action" style="height:18px; position: relative; float: left;">
				<div style="position:absolute; width: 200px; margin-top: 2px;">		
					{foreach from=$aRatingCallback.stars key=sKey item=sPhrase}		
						<input type="radio" class="js_rating_star" id="js_rating_star_{$sKey}" name="rating_star" value="{$sKey}" title="{$sKey}{if $sPhrase != $sKey} ({$sPhrase}){/if}"{if $aRatingCallback.default_rating >= $sKey} checked="checked"{/if} />
					{/foreach}
					<div class="clear"></div>
				</div>
			</div>
			<div>
				<input type="hidden" name="rating[star]" id="js_rating_star_submit" value=""/>
	            <input type="reset" onclick="return js_box_remove(this);" value="{phrase var="advancedmarketplace.cancel"}" class="button btn-default btn-sm " />
				<input type="submit" id="rating" onclick="return addStarValue();" value="{phrase var="advancedmarketplace.submit"}" class="button btn-primary btn-sm ml-1" />
			</div>
		</div>
		
	</form>
</div>

<script language="javascript" type="text/javascript">
	 {literal}
	 function addStarValue()
	 {
		 var totalstar = 0;
		 $('div').find('.star-rating-on').each(function(){
		 	totalstar = totalstar +1;
	     });
		 totalstar = totalstar *2;
		 $('#js_rating_star_submit').val(totalstar);
	 }
	     $('.js_rating_star').rating();

	 {/literal}
</script>
 
 
 
<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class AdvancedMarketplace_Component_Block_DetailSlideShow extends Phpfox_Component
{
    public function process()
    {
        $aListing = $this->getParam('aListing');
        $aImages = phpfox::getService('advancedmarketplace')->getImagesOfListing($aListing['listing_id']);
        $this->template()->assign(array(
            'core_path' => phpfox::getParam('core.path'),
            'aListing' => $aListing,
            'aImages' => $aImages
        ));
    }
}

<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class AdvancedMarketplace_Component_Block_MostReviewedListing extends Phpfox_Component
{
    public function process()
    {
        $iLimit = $this->getParam('limit', 3);

        if (!$iLimit) {
            return false;
        }

        list($iCnt, $aReviewedListings) = phpfox::getService('advancedmarketplace')->getMostReviewedListing($iLimit);

        if (empty($aReviewedListings)) {
            return false;
        }

        foreach ($aReviewedListings as $iKey => $aReviewedListing) {
            $aReviewedListings[$iKey]['rating'] = (int)$aReviewedListings[$iKey]['rating']/2;
        }

        $this->template()->assign(array(
            'sHeader' => _p('advancedmarketplace.most_reviewed_listing'),
            'corepath' => phpfox::getParam('core.path'),
            'aReviewedListings' => $aReviewedListings,
            'sCustomClassName' => 'ync-block'
        ));

        if ($iCnt > $iLimit) {
            $this->template()->assign(array(
                'aFooter' => array(
                    _p('advancedmarketplace.view_more') => $this->url()->makeUrl('advancedmarketplace.search.sort_most-reviewed')
                )
            ));
        }

        return 'block';
    }

    /**
     * Block settings
     *
     * @return array
     */
    public function getSettings()
    {
        return [
            [
                'info' => _p('advancedmarketplace_block_mostreviewedlisting_limit_info'),
                'description' => _p('advancedmarketplace_block_mostreviewedlisting_limit_description'),
                'value' => Phpfox::getParam('advancedmarketplace.total_listing_more_from'),
                'var_name' => 'limit',
                'type' => 'integer'
            ]
        ];
    }

    /**
     * Validation
     *
     * @return array
     */
    public function getValidation()
    {
        return [
            'limit' => [
                'def' => 'int:required',
                'min' => 0,
                'title' => _p('advancedmarketplace_limit_must_greater_or_equal_0',
                    ['var_name' => _p('advancedmarketplace_block_mostreviewedlisting_limit_info')])
            ]
        ];
    }

    /**
     * Garbage collector. Is executed after this class has completed
     * its job and the template has also been displayed.
     */
    public function clean()
    {
        (($sPlugin = Phpfox_Plugin::get('advancedmarketplace.component_block_mostreviewedlisting_clean')) ? eval($sPlugin) : false);
    }
}

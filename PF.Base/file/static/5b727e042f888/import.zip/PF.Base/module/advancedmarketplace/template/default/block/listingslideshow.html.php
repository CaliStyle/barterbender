<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>

{if $aSlideShowListing !== NULL}
	<div class="ynmarketplace-slider item-container owl-carousel owl-theme dont-unbind-children" id="ynmarketplace-slider">
		{foreach from=$aSlideShowListing key=iKey item=aListing}
			<article class="item">
				<div class="item-outer">
					<div class="ynmarketplace-slider__media">
						<span class="ynmarketplace-slider__thumb" style="background-image: url({if $aListing.image_path != NULL}
		                    {img return_url=true ref=$aListing.url title=$aListing.title server_id=$aListing.server_id path='advancedmarketplace.url_pic' file=$aListing.image_path suffix=''}
		                {else}
		                    {$corepath}module/advancedmarketplace/static/image/default/noimgbig_2.png
		                {/if});"></span>
					</div>
					<div class="ynmarketplace-slider__body pl-2 pr-2">
						<a class="ynmarketplace-slider__title text-gray-darker fw-bold" href="{$aListing.url}">{$aListing.title}</a>
						<p class="ynmarketplace-slider__owner fz-12 text-gray-dark mb-0 mt-1">{phrase var="advancedmarketplace.by"} {$aListing|user}</p>
						<p class="ynmarketplace-slider__description mb-0 mt-h1 text-gray-dark">{$aListing.short_description|parse|strip_tags|clean}</p>
						<div class="ynmarketplace-slider__location text-gray-dark space-left error-icon mt-2"><i class="ico ico-checkin"></i><span class="fz-12">{$aListing.country_name|location}</span></div>
						<div class="ynmarketplace-slider__price fz-20 mt-h1 {if $aListing.price == '0.00'}text-free{else}text-warning{/if}">
							{if $aListing.price == '0.00'}
								{phrase var='advancedmarketplace.free'}
							{else}
								{$aListing.currency_id|currency_symbol}{$aListing.price}
							{/if}
							{*$aListing.time_stamp|convert_time*}
						</div>
					</div>
				</div>
			</article>
		{/foreach}
	</div>
{/if}
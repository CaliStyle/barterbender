<?php

defined('PHPFOX') or exit('NO DICE!');

?>

<div id="js_marketplace_form_holder">
    {if $iTotalImage < $iTotalImageLimit}
    {module name='core.upload-form' type='advancedmarketplace' params=$aForms.params}
    <div class="market-app cancel-upload">
        <a href="javascript:void(0)" onclick="$.ajaxCall('advancedmarketplace.toggleUploadSection', 'id={$aForms.listing_id}&show_upload=1');"><i class="ico ico-arrow-left"></i>&nbsp;{_p var='cancel_upload'}</a>
        <a href="{permalink module='advancedmarketplace/detail' id=$iListingId title=$aForms.title}" id="js_listing_done_upload" style="display: none;" class="text-uppercase"><i class="ico ico-check"></i>&nbsp;{_p var='finish_upload'}</a>
    </div>
    {else}
    <p>{_p var='you_cannot_add_more_image_to_your_listing'}</p>
    {/if}
</div>

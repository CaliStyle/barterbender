<?php
$aValidation['how_many_sponsored_listings'] = [
    'def' => 'int',
    'min' => '0',
    'title' => _p('"How Many Sponsored Listings To Show" must be greater than or equal to 0.'),
];
$aValidation['total_listing_more_from'] = [
    'def' => 'int',
    'min' => '0',
    'title' => _p('"Total More From Listings to Display" must be greater than or equal to 0.'),
];
$aValidation['days_to_expire_listing'] = [
    'def' => 'int',
    'min' => '0',
    'title' => _p('"Days to Expire" must be greater than or equal to 0.'),
];
$aValidation['days_to_notify_expire'] = [
    'def' => 'int',
    'min' => '0',
    'title' => _p('"Days to Notify Expiring Listing" must be greater than or equal to 0.'),
];

<?php


defined('PHPFOX') or exit('NO DICE!');


class AdvancedMarketplace_Component_Block_Image extends Phpfox_Component
{
    /**
     * Class process method wnich is used to execute this component.
     */
    public function process()
    {
        if (!($aListing = $this->getParam('aListing'))) {
            return false;
        }

        $this->template()->assign(array(
                'corepath' => phpfox::getParam('core.path'),
                'aImages' => Phpfox::getService('advancedmarketplace')->getImages($aListing['listing_id']),
            )
        );
    }

    /**
     * Garbage collector. Is executed after this class has completed
     * its job and the template has also been displayed.
     */
    public function clean()
    {
        (($sPlugin = Phpfox_Plugin::get('advancedmarketplace.component_block_image_clean')) ? eval($sPlugin) : false);
    }
}

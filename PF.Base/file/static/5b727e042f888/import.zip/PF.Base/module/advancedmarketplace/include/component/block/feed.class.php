<?php
defined('PHPFOX') or exit('NO DICE!');

class AdvancedMarketplace_Component_Block_Feed extends Phpfox_Component
{
    /**
     * Class process method wnich is used to execute this component.
     */
    public function process()
    {
        $iFeedId = $this->getParam('this_feed_id');
        if ($iFeedId) {
            $aFeed = Phpfox::getService('feed')->getFeed($iFeedId);
            if (!$aFeed || ($aFeed['type_id'] != 'advancedmarketplace')) {
                return false;
            }

            $aListing= Phpfox::getService('advancedmarketplace')->getListing($aFeed['item_id']);
            if (empty($aListing)) {
                return false;
            }

            $this->template()->assign(compact('aListing'));
            $this->template()->assign(array('sCustomClassName' => 'ync-block',));
        }
        // else case: we set aListing to template in \AdvancedMarketplace_Service_Callback::getActivityFeed

        return 'block';
    }

    /**
     * Garbage collector. Is executed after this class has completed
     * its job and the template has also been displayed.
     */
    public function clean()
    {
        (($sPlugin = Phpfox_Plugin::get('advancedmarketplace.component_block_feed_clean')) ? eval($sPlugin) : false);
    }
}

<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class AdvancedMarketplace_Component_Block_Owner extends Phpfox_Component
{
    public function process()
    {
        $aListing = $this->getParam('aListing');

        if (Phpfox::isModule('tag')) {
            $aTags = Phpfox::getService('tag')->getTagsById('advancedmarketplace', $aListing['listing_id']);
            if (isset($aTags[$aListing['listing_id']])) {
                $aListing['tag_list'] = $aTags[$aListing['listing_id']];
            }
        }
        $aFollower = phpfox::getLib('database')->select('*')
            ->from(phpfox::getT('advancedmarketplace_follow'))
            ->where('user_id = ' . $aListing['user_id'] . ' and  user_follow_id = ' . phpfox::getUserId())
            ->execute('getSlaveRow');
        $bFollow = 'unfollow';
        if (!empty($aFollower) && phpfox::getUserId() > 0) {
            $bFollow = 'follow';
        }
        if (!isset($aListing['tag_list'])) {
            $aListing['tag_list'] = '';
        }

        $aUser = Phpfox::getService('user')->get($aListing['user_id']);
        $aCoverPhoto = '';
        if (!empty($aUser['cover_photo'])) {
            $aCoverPhoto = Phpfox::getService('photo')->getCoverPhoto($aUser['cover_photo']);
        }

        $this->template()->assign(array(
            'corepath' => phpfox::getParam('core.path'),
            'bFollow' => $bFollow,
            'aListing' => $aListing,
            'sTagType' => 'advancedmarketplace',
            'sCoverDefaultUrl' => flavor()->active->default_photo('user_cover_default', true),
            'aCoverPhoto' => $aCoverPhoto,
            'coreUrlModule' => Phpfox::getParam('core.path_file').'module/',
            'sCustomClassName' => 'ync-block',
            'sHeader' => _p('advancedmarketplace.seller')
        ));

        return 'block';
    }
}

<?php

/**
 * Created by PhpStorm.
 * User: thanhnc
 * Date: 10/7/16
 * Time: 3:54 PM
 */
defined('PHPFOX') or exit('NO DICE!');
class Ynsocialstore_Component_Block_Store_Profilemenu extends Phpfox_Component
{
    public function process()
    {
        $iStoreId = $this->request()->getInt('req3');
        $aStore = $this->getParam('aStore');

        if (empty($aStore) || $aStore['theme_id'] == 2) {
            return false;
        }
        $sStoreName = Phpfox::getLib('parse.input')->cleanTitle($aStore['name']);
        $sDetailPage = $this->request()->get('req5');

        $prefixDetail = "ynsocialstore.store.$iStoreId.$sStoreName";
        $aProfileMenu = array(
            array(
                'sMenu' => 'home',
                'sPhrase' => "<i class='ynicon yn-home'></i>"._p('home'),
                'sLink' => "$prefixDetail",
                'sClass' => '',
            ),
            array(
                'sMenu' => 'products',
                'sPhrase' => "<i class='ynicon yn-puzzle'></i>"._p('products').(($aStore['total_products']) ? "<span id='total_products_store_$iStoreId'>".$aStore['total_products']."</span>": ""),
                'sLink' => "$prefixDetail.products",
                'sClass' => '',
            ),
            array(
                'sMenu' => 'activities',
                'sPhrase' => "<i class='ynicon yn-flag-caro'></i>"._p('activities'),
                'sLink' => "$prefixDetail.activities",
                'sClass' => '',
            ),
            array(
                'sMenu' => 'photos',
                'sPhrase' => "<i class='ynicon yn-photos'></i>"._p('photos'),
                'sLink' => "$prefixDetail.photos",
                'sClass' => '',
            ),
            array(
                'sMenu' => 'reviews',
                'sPhrase' => "<i class='ynicon yn-check-circle'></i>"._p('reviews').(($aStore['total_review']) ? "<span id='total_review_store_$iStoreId'>".$aStore['total_review']."</span>" : ""),
                'sLink' => "$prefixDetail.reviews",
                'sClass' => '',
            ),
            array(
                'sMenu' => 'aboutus',
                'sPhrase' => "<i class='ynicon yn-user'></i>"._p('about_us'),
                'sLink' => "$prefixDetail.aboutus",
                'sClass' => '',
            ),
            array(
                'sMenu' => 'shipandpayment',
                'sPhrase' => "<i class='ynicon yn-truck'></i>"._p('shipping_and_payment'),
                'sLink' => "$prefixDetail.shipandpayment",
                'sClass' => '',
            ),
            array(
                'sMenu' => 'policy',
                'sPhrase' => "<i class='ynicon yn-article-o'></i>"._p('return_policy'),
                'sLink' => "$prefixDetail.policy",
                'sClass' => '',
            ),
            array(
                'sMenu' => 'buyerprotection',
                'sPhrase' => "<i class='ynicon yn-shield'></i>"._p('buyer_protection'),
                'sLink' => "$prefixDetail.buyerprotection",
                'sClass' => '',
            ),
            array(
                'sMenu' => 'faqs',
                'sPhrase' => "<i class='ynicon yn-question-circle'></i>"._p('faqs'),
                'sLink' => "$prefixDetail.faqs",
                'sClass' => '',
            )
        );

        $this->template()->assign(array(
            'aProfileMenu' => $aProfileMenu,
            'sDetailPage' => !empty($sDetailPage) ? $sDetailPage : 'home',
            'sHeader' => _p('profile_menu'),
        ));

        return 'block';
    }
}
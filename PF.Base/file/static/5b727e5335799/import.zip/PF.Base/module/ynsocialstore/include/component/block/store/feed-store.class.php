<?php

/**
 * Created by PhpStorm.
 * User: thanhnc
 * Date: 10/12/16
 * Time: 10:34 AM
 */
defined('PHPFOX') or exit('NO DICE!');
class Ynsocialstore_Component_Block_Store_Feed_Store extends Phpfox_Component
{
    public function process()
    {

    }
}
<?php

/**
 * Created by PhpStorm.
 * User: thanhnc
 * Date: 10/12/16
 * Time: 10:34 AM
 */
defined('PHPFOX') or exit('NO DICE!');
class Ynsocialstore_Component_Block_Product_Feed_Product extends Phpfox_Component
{
    public function process()
    {

    }
}
<?php

/**
 * Created by PhpStorm.
 * User: thanhnc
 * Date: 10/18/16
 * Time: 10:42 AM
 */
defined('PHPFOX') or exit('NO DICE!');
class Ynsocialstore_Component_Block_Store_DetailActivities
{
    public function process()
    {
//        Phpfox::getBlock('feed.display', array('module_id' => 'ynsocialstore'));
    }
}
<?php
/**
 * Created by PhpStorm.
 * User: thanhnc
 * Date: 10/6/16
 * Time: 4:52 PM
 */
?>
<div class="ynstore-store-about-txt">
    <div class="ynstore-title">{_p var='ynsocialstore.return_policy'}</div>
</div>
<div class="ynsocialstore-detail-overview-item">
    {$sPolicy|parse}
</div>

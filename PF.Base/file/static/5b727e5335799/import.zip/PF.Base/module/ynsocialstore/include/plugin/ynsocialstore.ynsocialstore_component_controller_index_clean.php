<?php
/**
 * Created by PhpStorm.
 * User: thanhnc
 * Date: 10/28/16
 * Time: 11:36 AM
 */
?>

<?php
// ADD ADV SEARCH
$sFullControllerName = Phpfox::getLib('template')->getVar('sFullControllerName');

if ($sFullControllerName == 'ynsocialstore_index') {
    $title_search = _p('advanced_search');
    $classAdvSearch = 'filter-options';
    ?>

    <script type="text/javascript">
        $Behavior.ynstLoadContentIndex = function () {
            if ($('#stAdvSearchProduct').length == 0) {
                var content = '<span id="stAdvSearchProduct" class="<?php echo $classAdvSearch; ?>"><a class="dropdown-toggle" onclick="ynsocialstore.advSearchProductDisplay(); return false;" href="javascript:void(0)"><?php echo $title_search; ?><span class="ico ico-caret-down"></span></a></span>';
                $('#page_ynsocialstore_index .header-filter-holder').append(content);
            }
        }
    </script>
    <?php
}
?>
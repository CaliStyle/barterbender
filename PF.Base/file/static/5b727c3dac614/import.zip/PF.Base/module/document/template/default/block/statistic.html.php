<?php
  
?>
<ul>
	<li class="border_statitics"><div class="stat-title">{phrase var='views'}</div><span class="stat-number">{$aRow.total_views}</span></li>
	<li class="border_statitics"><div class="stat-title">{phrase var='likes'}</div><span class="stat-number">{$aRow.total_likes}</span></li>
	<li class="border_statitics"><div class="stat-title">{phrase var='documents'}</div><span class="stat-number"> {$aRow.total_documents}</span></li>
</ul>
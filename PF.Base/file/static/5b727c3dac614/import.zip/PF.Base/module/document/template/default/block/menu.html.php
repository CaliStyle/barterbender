<div id="menu">
<ul>
    <li><a href={$add_document} >{phrase var='add_document_link_title'}</a></li>
    {if $show_edit_link}<li><a href={$edit_document}>{phrase var='edit_document_link_title'}</a></li>{/if}
    <li><a href={$my_documents} >{phrase var='my_documents_link_title'}</a></li>
    <li><a href={$all_documents} >{phrase var='all_documents_link_title'}</a></li>
  </ul>                        
</div>

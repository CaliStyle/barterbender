<?php

defined('PHPFOX') or exit('NO DICE!');

function ynd_install303p1()
{
    // Nothing to do
}

ynd_install303p1();

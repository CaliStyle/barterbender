<?php

//      start
defined('PHPFOX') or exit('NO DICE!');
Phpfox_Error::skip(true);



//      end 
Phpfox_Error::skip(false);

<?php

$aBundleScripts[] = [
    'jquery.magnific-popup.js'  => 'module_ynsocialstore',
    'jquery.validate.js'    => 'module_ynsocialstore',
    'ynsocialstore.js' => 'module_ynsocialstore',
    'ynsocialstorehelper.js' => 'module_ynsocialstore',
    'jquery.wookmark.js' => 'module_ynsocialstore',
    'gmaps.js' => 'module_ynsocialstore',
    'clipboard.min.js' => 'module_ynsocialstore',
    'magnific-popup.css' => 'module_ynsocialstore',
    'colorpicker/js/colpick.js' => 'static_script',
];
<?php
/**
 * Created by PhpStorm.
 * User: thanhnc
 * Date: 10/6/16
 * Time: 5:13 PM
 */
?>
<div class="ynstore-store-about-txt">
    <div class="ynstore-title">{_p var='ynsocialstore.buyer_protection'}</div>
</div>
<div class="ynsocialstore-detail-overview-item">
    {$sBuyerProtection|parse}
</div>

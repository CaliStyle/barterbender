<?php
/**
 * Created by PhpStorm.
 * User: thanhnc
 * Date: 10/7/16
 * Time: 12:12 PM
 */
?>
<div class="ynstore-store-about-txt">
    <div class="ynstore-title">{_p var='ynsocialstore.shipping_and_payments'}</div>
</div>
<div class="ynsocialstore-detail-overview-item">
    {$sShipAndPayment|parse}
</div>


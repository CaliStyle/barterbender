<?php

defined('PHPFOX') or exit('NO DICE!');

class Coupon_Component_Controller_Statistic extends Phpfox_Component {

    /**
     * Class process method wnich is used to execute this component.
     */
    public function process() {

    }

    /**
     * Garbage collector. Is executed after this class has completed
     * its job and the template has also been displayed.
     */
    public function clean()
    {

    }

}

?>
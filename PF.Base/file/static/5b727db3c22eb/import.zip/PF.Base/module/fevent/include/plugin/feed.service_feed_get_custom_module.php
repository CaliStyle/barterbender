<?php

if (!empty($this->_aCallback['module']) && $this->_aCallback['module'] == 'fevent') {
    $aCustomModule[] = 'fevent';
}

<?php
if (Phpfox::getLib('module')->getFullControllerName() == 'fevent.index')
{
	Phpfox::getBlock('fevent.rsvp-entry');
}
?>
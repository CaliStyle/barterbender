<?php
$aPhotos['fevent_default_photo'] = [
    'title' => _p('fevent_default_photo'),
    'value' => $flavor->default_photo('fevent_default_photo', true),
];
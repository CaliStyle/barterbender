<?php 
;

// if(Phpfox::isModule('directory')){
// 	if($aImages)
// 	{
// 		$aYnDirectoryLastImage = end($aImages);
// 		if($aYnDirectoryLastImage['photo_id'] == $aPhoto['photo_id'])
// 		{
// 			$aYnDirectoryPhoto = Phpfox::getService('directory')->getPhotoInBusiness($aPhoto['photo_id']); 
// 			if(isset($aYnDirectoryPhoto['photo_id'])){
// 				Phpfox::getService('directory')->handlerAfterAddingEntry($sType = 'photos', $iPhotoItemId = $aPhoto['photo_id'] );
// 			}
// 		}
// 	}
// }

;
?>
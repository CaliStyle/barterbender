<?php

$aValidation['max_upload_size_photos'] = [
    'def' => 'int:required',
    'min' => '0',
    'title' => '"Maximum size for Photos" must be greater than or equal to 0',
];

<div id="yndirectory_business_compareitem" class="yndirectory_business_compareitem">	
</div>

{literal}
<script type="text/javascript">
    ;$Behavior.yndirectory_compareitem_init = function() {
    	if($('#yndirectory_business_compareitem').length > 0){
    		yndirectory.initCompareItemBlock();
    	} 
    };        
</script>
{/literal}


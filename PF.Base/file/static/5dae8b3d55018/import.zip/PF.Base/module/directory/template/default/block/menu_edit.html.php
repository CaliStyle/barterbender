<div id="menu_edit_directory" class="page_section_menu page_section_menu_header">
    <ul class="action">
        <li class="yndirectory-insight">
        	<a href="{url link='directory.insight.id_'.$iBusinessid}">{phrase var='insight'}</a>
        </li>
        
        <li class="yndirectory-edit-info">
        	<a href="{url link='directory.edit.id_'.$iBusinessid}">{phrase var='edit_info'}</a>
        </li>
        
        <li class="yndirectory-cover-photos">
        	<a href="{url link='directory.cover-photos.id_'.$iBusinessid}">{phrase var='cover_photos'}</a>
        </li>
        
        <li class="yndirectory-manage-pages">
        	<a href="{url link='directory.manage-pages.id_'.{$iBusinessid}">{phrase var='manage_pages'}</a>
        </li>
        <li class="yndirectory-manage-member-roles">
            <a href="{url link='directory.manage-member-roles.id_'.{$iBusinessid}">{phrase var='manage_member_roles'}</a>
        </li>
        <li class="yndirectory-member-role-settings">
            <a href="{url link='directory.member-role-settings.id_'.{$iBusinessid}">{phrase var='member_role_settings'}</a>
        </li>
        <li class="yndirectory-manage-announcements">
            <a href="{url link='directory.manage-announcements.id_'.{$iBusinessid}">{phrase var='manage_announcements'}</a>
        </li>
        <li class="yndirectory-manage-modules">
            <a href="{url link='directory.manage-modules.id_'.{$iBusinessid}">{phrase var='manage_modules'}</a>
        </li>
        <li class="yndirectory-manage-business-theme">
            <a href="{url link='directory.manage-business-theme.id_'.{$iBusinessid}">{phrase var='manage_business_theme'}</a>
        </li>
        <li class="yndirectory-manage-packages">
            <a href="{url link='directory.manage-packages.id_'.{$iBusinessid}">{phrase var='manage_packages'}</a>
        </li>
    </ul> 
</div>


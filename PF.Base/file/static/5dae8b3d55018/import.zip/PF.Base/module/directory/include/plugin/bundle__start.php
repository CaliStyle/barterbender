<?php

$aBundleScripts[] = [
    'yndirectory.js' => 'module_directory',
];
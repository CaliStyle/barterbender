<?php
defined('PHPFOX') or exit('NO DICE!');

Phpfox::getBlock('socialpublishers.settings');
?>
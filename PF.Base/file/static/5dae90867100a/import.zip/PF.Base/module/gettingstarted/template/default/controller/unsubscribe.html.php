<?php
?>
<div class="message">{$sNotice}</div>
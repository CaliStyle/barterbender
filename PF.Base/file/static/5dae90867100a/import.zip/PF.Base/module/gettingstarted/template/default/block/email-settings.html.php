<?php
	
?>
Select which type of letters you want to be received from system.
<div class="table form-group">
	<div class="table_left">
		Register
	</div>
	<div class="table_right">
		<input type="checkbox" />
	</div>
	<div class="table_left">
		Logout
	</div>
	<div class="table_right">
		<input type="checkbox" />
	</div>
	<div class="table_left">
		Blog
	</div>
	<div class="table_right">
		<input type="checkbox" />
	</div>
</div>
 
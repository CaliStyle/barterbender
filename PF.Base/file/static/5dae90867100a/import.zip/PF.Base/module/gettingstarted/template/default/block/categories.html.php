<?php
/**
 * [PHPFOX_HEADER]
 */

defined('PHPFOX') or exit('NO DICE!');
/**
 *
 *
 * @copyright   [YOUNET_COPYRIGHT]
 * @author      YouNet Company
 * @package     YouNet_Event
 * @version     3.02p5
 */
?>
{template file='core.block.category'}


 



{literal}
<style type="text/css">
    .favor, .unfavor {
        font-weight: bold;
        line-height: 22px;
        margin-left: 5px;
        padding: 8px 20px;
        text-decoration: none;
        position:relative;
    }
    .favor {
        background: none;
        color: #333333;
    }
    .unfavor {
        background: url(<?php echo $unfavor_img; ?>) no-repeat;
    }
</style>
{/literal}
{if phpfox::isUser()}
    {$sHtml}
{if PHPFOX_IS_AJAX_PAGE}
    {literal}
    <script type="text/javascript" language="javascript">
        $Behavior.onCreateFavoriteButtonBlock7 = function() {
            if($('#section_menu').size() == 0 && $('#yn_section_menu').html() != null)
            {
                $bt_favor = '<div id="ynfavorite"   class="yn_sectionmenu">' + $('#yn_section_menu').first().html() + '</div>';
                $('.profile_viewer_actions').append($bt_favor); //cosmic theme
                $('#section_menu').show();
            }
            else
            {
                $bt_favor = $('.yn_page_favorite').first();
                $bt_unfavor = $('.unfavor');
                if (gan_nut_unfavorite) {
                    $('#ynfavorite').prepend($bt_unfavor);
                }
            }
            $Behavior.inlinePopup();
            $('#yn_section_menu').html('');
        };
    </script>
    {/literal}
{/if}
{/if}
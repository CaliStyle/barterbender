<div class="table_header">{phrase var='foxfavorite.page_migration'}
</div>
<div style="background: #FFF;padding: 10px;margin-bottom:15px;">
	{phrase var='foxfavorite.migration_data_from_pagesfavorite_to_foxfavorite'}
</div>
<div class="table_clear">
	<input class="button" type="submit" value="{phrase var='foxfavorite.confirm'}" onclick="window.location.href='{$sUrl}'"/>
</div>
<?php

Phpfox::getService('foxfavorite.process')->UnFavorite('foxfeedspro', $iNewsId);

?>
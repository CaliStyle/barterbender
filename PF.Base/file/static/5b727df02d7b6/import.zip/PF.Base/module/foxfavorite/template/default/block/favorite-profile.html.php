{if phpfox::isUser()}
	<ul class="yn_ul_profile_favorite" style="display:none;">
		<li class="yn_profile_favorite">
			<a href="#" onclick="$('#js_favorite_link_unlike_{$iItemId}').show(); $('#js_favorite_link_like_{$iItemId}').hide(); $.ajaxCall('foxfavorite.addFavorite', 'type={$sModule}&amp;id={$iItemId}', 'GET'); return false;" class="favor inlinePopup" id="js_favorite_link_like_{$iItemId}" title="{phrase var='foxfavorite.add_to_your_favorites'}" {if $bIsAlreadyFavorite} style="display:none;"{/if}>
					<i class="fa fa-star"></i>
					<span>{phrase var='foxfavorite.favorite'}</span>
			</a>
		</li>
		<li class="yn_profile_unfavorite">
			<a class="unfavor" title="{phrase var='foxfavorite.remove_from_your_favorite'}" href="#" onclick="$('#js_favorite_link_like_{$iItemId}').show(); $('#js_favorite_link_unlike_{$iItemId}').hide(); $.ajaxCall('foxfavorite.deleteFavorite', 'type={$sModule}&amp;id={$iItemId}', 'GET'); return false;" id="js_favorite_link_unlike_{$iItemId}" {if !$bIsAlreadyFavorite} style="display:none;"{/if}>
			<i class="fa fa-star-o"></i>
					<span>{phrase var='foxfavorite.favorite'}</span>
			</a>
		</li>
	</ul>
	{literal}
	<script type="text/javascript" language="javascript">
	var addthem = true;
		$Behavior.onCreateFavoriteButton = function() {
			//alert("hello");
			if ($('#page_profile_index').length)
			{
				if (addthem)
				{
					$bt_favor = $('.yn_profile_favorite').first();
					$bt_unfavor = $('.yn_profile_unfavorite').first();
					$str =  "<li>" +  $bt_unfavor.html() + "</li><li>" + $bt_favor.html() + "</li>" ;
					$('.profiles_action ul').prepend($str);					
	                $Behavior.inlinePopup();	
	                addthem = false;
				}
				$('.yn_ul_profile_favorite').remove();
			}
		};
	</script>
	{/literal}
{/if}
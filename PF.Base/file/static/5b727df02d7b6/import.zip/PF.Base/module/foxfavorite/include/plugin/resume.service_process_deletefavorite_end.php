<?php

Phpfox::getService('foxfavorite.process')->UnFavorite('resume', $aFavorite['resume_id']);

?>
<?php

Phpfox::getService('foxfavorite.process')->UnFavorite('contest', $iContestId);

?>
<?php

Phpfox::getService('foxfavorite.process')->UnFavorite('videochannel', $iVideoId);

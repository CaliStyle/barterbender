<div class="table_header">{phrase var='foxfavorite.settings'}</div>
<form>
	<table>
		<tr>

			<th>{phrase var='foxfavorite.module'}</th>
			<th>{phrase var='foxfavorite.active'}</th>
		</tr>
		{foreach from=$aSettings key=iKey name=setting item=aItem}
		<tr class="checkRow{if is_int($iKey/2)} tr{else}{/if}">
			<td>{$aItem.title|translate:'module_id'}</td>
			<td>
            {if !in_array($aItem.module_id, $aFunctionedModule)}
				<div class="js_item_is_active"{if !$aItem.is_active} style="display:none;"{/if}>
				<a href="#?call=foxfavorite.updateModuleActivity&amp;id={$aItem.module_id}&amp;active=0" class="js_item_active_link" title="{phrase var='admincp.deactivate'}">{img theme='misc/bullet_green.png' alt=''}</a>
				</div>
				<div class="js_item_is_not_active"{if $aItem.is_active} style="display:none;"{/if}>
					<a href="#?call=foxfavorite.updateModuleActivity&amp;id={$aItem.module_id}&amp;active=1" class="js_item_active_link" title="{phrase var='admincp.activate'}">{img theme='misc/bullet_red.png' alt=''}</a>
				</div>
            {else}
                <div class="js_item_is_active" style="width: 100%">
					{phrase var='foxfavorite.this_module_is_always_active'}
				</div>
            {/if}
			</td>
		</tr>
		{/foreach}
	</table>
</form>
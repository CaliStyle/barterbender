<?php

Phpfox::getService('foxfavorite.process')->UnFavorite('coupon', $iItem);

<?php

/**
 * [PHPFOX_HEADER]
 */

defined('PHPFOX') or exit('NO DICE!');

/**
 * 
 * 
 * @copyright		YouNetCo Company
 * @author  		MinhNTK
 * @package 		FoxFavorite_Module
 */
class Foxfavorite_Service_Callback extends Phpfox_Service
{
    /**
     * Class constructor
     */
    public function __construct()
    {
        $this->_sTable = Phpfox::getT('foxfavorite');
    }

    public function getProfileLink()
    {
        return 'profile.foxfavorite';
    }

    /**
     * Action to take when user cancelled their account
     *	Deletes: friends, friends lists and friends requests
     * @param int $iUser
     */
    public function onDeleteUser($iUser)
    {
        $aFavorites = $this->database()->select('favorite_id')->from($this->_sTable)->where('user_id = ' . (int)$iUser)->execute('getSlaveRows');

        foreach ($aFavorites as $aFavorite)
        {
            Phpfox::getService('foxfavorite.process')->delete($aFavorite['favorite_id']);
        }
    }

    public function tabHasItems($iUser)
    {
        $iCount = $this->database()->select('COUNT(user_id)')->from($this->_sTable)->where('user_id = ' . (int)$iUser)->execute('getSlaveField');
        return $iCount > 0;
    }

    public function getProfileMenu($aUser)
    {
        if (!Phpfox::getParam('profile.show_empty_tabs'))
        {
            if (!isset($aUser['total_foxfavorite']))
            {
                return false;
            }

            if (isset($aUser['total_foxfavorite']) && (int)$aUser['total_foxfavorite'] === 0)
            {
                return false;
            }
        }

        $aSubMenu = array();
        $iTotal = 0;

        $aSettings = phpfox::getService('foxfavorite')->getSettings();
        $sUserName = $this->request()->get('req1');
        foreach ($aSettings as $iKey => $aSetting)
        {
            if ($aSetting['is_active'] != 1)
            {
                continue;
            }
            $iCnt = Phpfox::getService('foxfavorite')->getCount($aSetting['module_id'], $aUser['user_id'], '');
            if ($this->request()->get('req2') == 'foxfavorite') {
                $aSettings[$iKey]['url'] = phpfox::getLib('url')->makeUrl($sUserName . '.foxfavorite.view_' . $aSetting['title']);
                switch ($aSetting['module_id']) {
                    case 'advancedmarketplace':
                        break;
                    case 'advancedphoto':
                        $aSetting['title'] = 'photos';
                        break;
                    case 'contest':
                        break;
                    case 'directory':
                        $aSetting['title'] = 'business_directory';
                        break;
                    case 'auction':
                        $aSetting['title'] = 'auction';
                        break;
                    case 'fevent':
                        $aSetting['title'] = 'events';
                        break;
                    case 'foxfeedspro':
                        $aSetting['title'] = 'news';
                        break;
                    case 'jobposting':
                        $aSetting['title'] = 'jobs';
                        break;
                    case 'karaoke':
                        break;
                    case 'music':
                        break;
                    case 'musicsharing':
                        $aSetting['title'] = 'music_sharing';
                        break;
                    case 'marketplace':
                        break;
                    case 'pages':
                        break;
                    case 'profile':
                        break;
                    case 'quiz':
                        $aSetting['title'] = 'quizzes';
                        break;
                    case 'videochannel':
                        break;
                    default: //..., coupon, resume
                        $aSetting['title'] .= 's';
                        break;

                }
                $aSubMenu[] = array(
                    'phrase' => phpfox::getPhrase($aSetting['module_id'] . "." . $aSetting['title']),
                    'url' => $aSettings[$iKey]['url'],
                    'module_name' => $aSetting['module_id'],
                    'total' => $iCnt);
            }
            $iTotal += $iCnt;
        }

        $aMenus[] = array(
            'phrase' => Phpfox::getPhrase('foxfavorite.favorites'),
            'url' => 'profile.foxfavorite',
            'total' => ($iTotal != 0) ? $iTotal : (int)(isset($aUser['total_foxfavorite']) ? $aUser['total_foxfavorite'] : 0),
            'sub_menu' => $aSubMenu,
            'icon' => 'module/favorite.png');

        if ($iTotal != $aUser['total_foxfavorite'] && $iTotal != 0)
        {
            phpfox::getLib('database')->update(phpfox::getT('user_field'), array('total_foxfavorite' => $iTotal), 'user_id = ' . $aUser['user_id']);
        }
        return $aMenus;
    }

    public function getNotificationUpdateStatus($aNotification)
    {
        $aRow = $this->database()->select('us.status_id, u.user_id, u.gender, u.user_name, u.full_name, us.content')->from(Phpfox::getT('feed'), 'f')->join(phpfox::getT('user_status'), 'us', 'us.status_id = f.item_id')->join(Phpfox::getT('user'), 'u', 'u.user_id = us.user_id')->where('f.feed_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');
        if (empty($aRow))
        {
            return false;
        }
        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sContent = Phpfox::getLib('parse.output')->shorten($aRow['content'], Phpfox::getParam('notification.total_notification_title_length'), '...');

        $sPhrase = '';

        $sPhrase = Phpfox::getPhrase('foxfavorite.user_has_already_updated_status_content', array('users' => $sUsers, 'content' => $sContent));


        return array(
            'link' => Phpfox::getLib('url')->makeUrl($aRow['user_name'], array('status-id' => $aRow['status_id'])),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'misc/application_add.png', 'return_url' => true)));
    }

    public function getNotificationAddLink($aNotification)
    {
        $aRow = $this->database()->select('l.link_id, l.title, l.link, ' . phpfox::getUserField())->from(Phpfox::getT('link'), 'l')->join(Phpfox::getT('user'), 'u', 'u.user_id = l.user_id')->where('l.link_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');

        if (empty($aRow))
        {
            return false;
        }
        
        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');

        $sPhrase = '';

        $sPhrase = Phpfox::getPhrase('foxfavorite.user_has_already_shared_a_link_title', array('users' => $sUsers, 'link' => $aRow['link'], 'title' => $sTitle));

        return array(
            'link' => Phpfox::getLib('url')->makeUrl($aRow['user_name'], array('link-id' => $aRow['link_id'])),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'feed/link.png', 'return_url' => true)));
    }

    public function getNotificationAddPhoto($aNotification)
    {
        if (!phpfox::isModule('photo'))
        {
            return false;
        }
        $aRow = $this->database()->select('p.photo_id, p.title,' . phpfox::getUserField())->from(Phpfox::getT('photo'), 'p')->join(Phpfox::getT('user'), 'u', 'u.user_id = p.user_id')->where('p.photo_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');

        if (empty($aRow))
        {
            return false;
        }
        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');

        $sPhrase = '';

        $sPhrase = Phpfox::getPhrase('foxfavorite.user_has_already_posted_a_photo_title', array('users' => $sUsers, 'title' => $aRow['title']));

        return array(
            'link' => Phpfox::getLib('url')->permalink('photo', $aRow['photo_id'], $aRow['title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/photo.png', 'return_url' => true)));
    }

    public function getNotificationAddBlog($aNotification)
    {
        if (!phpfox::isModule('blog'))
        {
            return false;
        }
        $aRow = $this->database()->select('b.blog_id, b.title,' . phpfox::getUserField())->from(Phpfox::getT('blog'), 'b')->join(Phpfox::getT('user'), 'u', 'u.user_id = b.user_id')->where('b.blog_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');

        if (empty($aRow))
        {
            return false;
        }
        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');

        $sPhrase = '';

        $sPhrase = Phpfox::getPhrase('foxfavorite.user_has_already_posted_a_blog', array('users' => $sUsers, 'title' => $sTitle));

        return array(
            'link' => Phpfox::getLib('url')->permalink('blog', $aRow['blog_id'], $aRow['title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('template')->getStyle('image', 'activity.png', 'blog'));
    }

    public function getNotificationAddPoll($aNotification)
    {
        if (!phpfox::isModule('poll'))
        {
            return false;
        }
        $aRow = $this->database()->select('b.poll_id, b.question as title,' . phpfox::getUserField())->from(Phpfox::getT('poll'), 'b')->join(Phpfox::getT('user'), 'u', 'u.user_id = b.user_id')->where('b.poll_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');

        if (empty($aRow))
        {
            return false;
        }
        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');

        $sPhrase = '';

        $sPhrase = Phpfox::getPhrase('foxfavorite.user_has_already_posted_a_poll', array('users' => $sUsers, 'title' => $sTitle));

        return array(
            'link' => Phpfox::getLib('url')->permalink('poll', $aRow['poll_id'], $aRow['title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('template')->getStyle('image', 'activity.png', 'blog'));
    }

    public function getNotificationAddMusic($aNotification)
    {
        if (!phpfox::isModule('music'))
        {
            return false;
        }
        $aRow = $this->database()->select('b.song_id, b.title,' . phpfox::getUserField())->from(Phpfox::getT('music_song'), 'b')->join(Phpfox::getT('user'), 'u', 'u.user_id = b.user_id')->where('b.song_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');

        if (empty($aRow))
        {
            return false;
        }
        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');

        $sPhrase = '';

        $sPhrase = Phpfox::getPhrase('foxfavorite.user_has_already_posted_a_song', array('users' => $sUsers, 'title' => $sTitle));

        return array(
            'link' => Phpfox::getLib('url')->permalink('music', $aRow['song_id'], $aRow['title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('template')->getStyle('image', 'activity.png', 'blog'));
    }

    public function getNotificationAddListing($aNotification)
    {
        if (!phpfox::isModule('marketplace'))
        {
            return false;
        }
        $aRow = $this->database()->select('m.listing_id, m.title,' . phpfox::getUserField())->from(Phpfox::getT('marketplace'), 'm')->join(Phpfox::getT('user'), 'u', 'u.user_id = m.user_id')->where('m.listing_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');

        if (empty($aRow))
        {
            return false;
        }
        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');

        $sPhrase = '';

        $sPhrase = Phpfox::getPhrase('foxfavorite.user_has_already_posted_a_listing', array('users' => $sUsers, 'title' => $sTitle));

        return array(
            'link' => Phpfox::getLib('url')->permalink('marketplace', $aRow['listing_id'], $aRow['title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/marketplace.png', 'return_url' => true)));
    }

    public function getNotificationAddVideo($aNotification)
    {
        if (!phpfox::isModule('video'))
        {
            return false;
        }
        $aRow = $this->database()->select('v.video_id, v.title,' . phpfox::getUserField())->from(Phpfox::getT('video'), 'v')->join(Phpfox::getT('user'), 'u', 'u.user_id = v.user_id')->where('v.video_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');

        if (empty($aRow))
        {
            return false;
        }
        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');

        $sPhrase = '';

        $sPhrase = Phpfox::getPhrase('foxfavorite.user_has_already_posted_a_video', array('users' => $sUsers, 'title' => $sTitle));

        return array(
            'link' => Phpfox::getLib('url')->permalink('video', $aRow['video_id'], $aRow['title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/video.png', 'return_url' => true)));
    }

    public function getNotificationAddQuiz($aNotification)
    {
        if (!phpfox::isModule('quiz'))
        {
            return false;
        }
        $aRow = $this->database()->select('q.quiz_id, q.title,' . phpfox::getUserField())->from(Phpfox::getT('quiz'), 'q')->join(Phpfox::getT('user'), 'u', 'u.user_id = q.user_id')->where('q.quiz_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');

        if (empty($aRow))
        {
            return false;
        }
        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');

        $sPhrase = '';

        $sPhrase = Phpfox::getPhrase('foxfavorite.user_has_already_posted_a_quiz', array('users' => $sUsers, 'title' => $sTitle));

        return array(
            'link' => Phpfox::getLib('url')->permalink('quiz', $aRow['quiz_id'], $aRow['title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/quiz.png', 'return_url' => true)));
    }

    public function getNotificationAddEvent($aNotification)
    {
        if (!phpfox::isModule('event'))
        {
            return false;
        }
        $aRow = $this->database()->select('e.event_id, e.title,' . phpfox::getUserField())->from(Phpfox::getT('event'), 'e')->join(Phpfox::getT('user'), 'u', 'u.user_id = e.user_id')->where('e.event_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');

        if (empty($aRow))
        {
            return false;
        }
        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');

        $sPhrase = '';

        $sPhrase = Phpfox::getPhrase('foxfavorite.user_has_already_posted_an_event', array('users' => $sUsers, 'title' => $sTitle));

        return array(
            'link' => Phpfox::getLib('url')->permalink('event', $aRow['event_id'], $aRow['title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/event.png', 'return_url' => true)));
    }

    public function getNotificationAddFListing($aNotification)
    {
        if (!phpfox::isModule('advancedmarketplace'))
        {
            return false;
        }
        $aRow = $this->database()->select('m.listing_id, m.title,' . phpfox::getUserField())->from(Phpfox::getT('advancedmarketplace'), 'm')->join(Phpfox::getT('user'), 'u', 'u.user_id = m.user_id')->where('m.listing_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');

        if (empty($aRow))
        {
            return false;
        }
        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');

        $sPhrase = '';

        $sPhrase = Phpfox::getPhrase('foxfavorite.user_has_already_posted_a_listing', array('users' => $sUsers, 'title' => $sTitle));

        return array(
            'link' => Phpfox::getLib('url')->permalink('advancedmarketplace.detail', $aRow['listing_id'], $aRow['title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/marketplace.png', 'return_url' => true)));
    }

    public function getNotificationAddFEvent($aNotification)
    {
        if (!phpfox::isModule('fevent'))
        {
            return false;
        }
        $aRow = $this->database()->select('e.event_id, e.title,' . phpfox::getUserField())->from(Phpfox::getT('fevent'), 'e')->join(Phpfox::getT('user'), 'u', 'u.user_id = e.user_id')->where('e.event_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');

        if (empty($aRow))
        {
            return false;
        }
        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');

        $sPhrase = '';

        $sPhrase = Phpfox::getPhrase('foxfavorite.user_has_already_posted_an_event', array('users' => $sUsers, 'title' => $sTitle));

        return array(
            'link' => Phpfox::getLib('url')->permalink('fevent', $aRow['event_id'], $aRow['title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/event.png', 'return_url' => true)));
    }

    public function getNotificationAddDocument($aNotification)
    {
        if (!phpfox::isModule('document'))
        {
            return false;
        }
        $aRow = $this->database()->select('d.document_id, d.title,' . phpfox::getUserField())->from(Phpfox::getT('document'), 'd')->join(Phpfox::getT('user'), 'u', 'u.user_id = d.user_id')->where('d.document_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');

        if (empty($aRow))
        {
            return false;
        }
        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');

        $sPhrase = '';

        $sPhrase = Phpfox::getPhrase('foxfavorite.user_has_already_posted_a_document', array('users' => $sUsers, 'title' => $sTitle));

        return array(
            'link' => Phpfox::getLib('url')->permalink('document', $aRow['document_id'], $aRow['title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'feed/document.jpg', 'return_url' => true)));
    }

    public function getNotificationAddKaraokeSong($aNotification)
    {
        if (!phpfox::isModule('karaoke'))
        {
            return false;
        }
        $aRow = $this->database()->select('b.song_id, b.title,' . phpfox::getUserField())->from(Phpfox::getT('karaoke_song'), 'b')->join(Phpfox::getT('user'), 'u', 'u.user_id = b.user_id')->where('b.song_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');

        if (empty($aRow))
        {
            return false;
        }
        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');

        $sPhrase = '';

        $sPhrase = Phpfox::getPhrase('foxfavorite.user_has_already_posted_a_karaoke_song', array('users' => $sUsers, 'title' => $sTitle));

        return array(
            'link' => Phpfox::getLib('url')->permalink('karaoke.songdetail', $aRow['song_id'], $aRow['title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/music.png', 'return_url' => true)));
    }

    public function getNotificationAddKaraokeRecording($aNotification)
    {
        if (!phpfox::isModule('karaoke'))
        {
            return false;
        }
        $aRow = $this->database()->select('b.recording_id, b.title,' . phpfox::getUserField())->from(Phpfox::getT('karaoke_recording'), 'b')->join(Phpfox::getT('user'), 'u', 'u.user_id = b.user_id')->where('b.recording_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');

        if (empty($aRow))
        {
            return false;
        }
        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');

        $sPhrase = '';

        $sPhrase = Phpfox::getPhrase('foxfavorite.user_has_already_added_a_karaoke_recording', array('users' => $sUsers, 'title' => $sTitle));

        return array(
            'link' => Phpfox::getLib('url')->permalink('karaoke.recordingdetail', $aRow['recording_id'], $aRow['title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/music.png', 'return_url' => true)));
    }

    public function getNotificationAddChannelVideo($aNotification)
    {
        if (!phpfox::isModule('videochannel'))
        {
            return false;
        }
        $aRow = $this->database()->select('v.video_id, v.title,' . phpfox::getUserField())->from(Phpfox::getT('channel_video'), 'v')->join(Phpfox::getT('user'), 'u', 'u.user_id = v.user_id')->where('v.video_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');

        if (empty($aRow))
        {
            return false;
        }
        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');

        $sPhrase = '';

        $sPhrase = Phpfox::getPhrase('foxfavorite.user_has_already_posted_a_video', array('users' => $sUsers, 'title' => $sTitle));

        return array(
            'link' => Phpfox::getLib('url')->permalink('videochannel', $aRow['video_id'], $aRow['title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/video.png', 'return_url' => true)));
    }

    public function getNotificationAddAdvancedPhoto($aNotification)
    {
        if (!phpfox::isModule('advancedphoto'))
        {
            return false;
        }
        $aRow = $this->database()->select('p.photo_id, p.title,' . phpfox::getUserField())->from(Phpfox::getT('photo'), 'p')->join(Phpfox::getT('user'), 'u', 'u.user_id = p.user_id')->where('p.photo_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');

        if (empty($aRow))
        {
            return false;
        }
        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');

        $sPhrase = '';

        $sPhrase = Phpfox::getPhrase('foxfavorite.user_has_already_posted_a_photo_title', array('users' => $sUsers, 'title' => $sTitle));


        return array(
            'link' => Phpfox::getLib('url')->permalink('advancedphoto', $aRow['photo_id'], $aRow['title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/photo.png', 'return_url' => true)));
    }

    public function getNotificationAddBusiness($aNotification)
    {
        if (!phpfox::isModule('directory'))
        {
            return false;
        }
        
        $aRow = $this->database()->select('c.business_id, c.name as title,' . phpfox::getUserField())
            ->from(Phpfox::getT('directory_business'), 'c')
            ->join(Phpfox::getT('user'), 'u', 'u.user_id = c.user_id')
            ->where('c.business_id = ' . (int)$aNotification['item_id'])
            ->execute('getSlaveRow');
        if (empty($aRow))
        {
            return false;
        }
        
        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');
        $sPhrase = Phpfox::getPhrase('foxfavorite.users_has_already_added_a_business_title', array('users' => $sUsers, 'title' => $sTitle));

        return array(
            'link' => Phpfox::getLib('url')->permalink('directory.detail', $aRow['business_id'], $aRow['title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('template')->getStyle('image', 'activity.png', 'blog'));
    }

    public function getNotificationAddAuction($aNotification)
    {
        if (!phpfox::isModule('auction'))
        {
            return false;
        }
        
        $sWhere = '';
        $sWhere .= ' and e.product_status IN ( \'running\',\'approved\',\'bidden\',\'completed\') ';
        $aRow = $this->database()->select('e.product_id,e.name as title,'.Phpfox::getUserField())
            ->from(Phpfox::getT('ecommerce_product'), 'e')
            ->join(PHpfox::getT('user'),'u','u.user_id = e.user_id')
            ->where('e.product_id = ' . (int) $aNotification['item_id'] . $sWhere)
            ->execute('getSlaveRow');
    
        if (!isset($aRow['product_id']))
        {
            return false;
        }


        if (empty($aRow))
        {
            return false;
        }
        
        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');
        $sPhrase = Phpfox::getPhrase('foxfavorite.users_has_already_added_a_product_title', array('users' => $sUsers, 'title' => $sTitle));

        return array(
            'link' => Phpfox::getLib('url')->permalink('auction.detail', $aRow['product_id'], $aRow['title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('template')->getStyle('image', 'activity.png', 'blog'));
    }

    public function getNotificationAddCoupon($aNotification)
    {
        if (!phpfox::isModule('coupon'))
        {
            return false;
        }
        
        $aRow = $this->database()->select('c.coupon_id, c.title,' . phpfox::getUserField())->from(Phpfox::getT('coupon'), 'c')->join(Phpfox::getT('user'), 'u', 'u.user_id = c.user_id')->where('c.coupon_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');
        if (empty($aRow))
        {
            return false;
        }
        
        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');
        $sPhrase = Phpfox::getPhrase('foxfavorite.user_has_already_added_a_coupon_title', array('users' => $sUsers, 'title' => $sTitle));

        return array(
            'link' => Phpfox::getLib('url')->permalink('coupon.detail', $aRow['coupon_id'], $aRow['title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('template')->getStyle('image', 'activity.png', 'blog'));
    }

    public function getNotificationAddContest($aNotification)
    {
        if (!Phpfox::isModule('contest'))
        {
            return false;
        }
        
        $aRow = $this->database()->select('c.contest_id, c.contest_name, ' . Phpfox::getUserField())
        ->from(Phpfox::getT('contest'), 'c')
        ->join(Phpfox::getT('user'), 'u', 'u.user_id = c.user_id')
        ->where('c.contest_id = ' . (int)$aNotification['item_id'])
        ->execute('getSlaveRow');
        
        if (empty($aRow))
        {
            return false;
        }
        
        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['contest_name'], Phpfox::getParam('notification.total_notification_title_length'), '...');
        $sMessage = Phpfox::getPhrase('foxfavorite.users_has_already_posted_a_contest_title', array('users' => $sUsers, 'title' => $sTitle));

        return array(
            'link' => Phpfox::permalink('contest', $aRow['contest_id'], $aRow['contest_name']),
            'message' => $sMessage,
            'icon' => Phpfox::getLib('template')->getStyle('image', 'activity.png', 'blog'));
    }

    public function getNotificationAddResume($aNotification)
    {
        if (!Phpfox::isModule('resume'))
        {
            return false;
        }
        
        $aRow = $this->database()->select('rbi.resume_id, rbi.headline, ' . Phpfox::getUserField())
        ->from(Phpfox::getT('resume_basicinfo'), 'rbi')
        ->join(Phpfox::getT('user'), 'u', 'u.user_id = rbi.user_id')
        ->where('rbi.resume_id = ' . (int)$aNotification['item_id'])
        ->execute('getSlaveRow');
        
        if (empty($aRow))
        {
            return false;
        }
        
        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sHeadline = Phpfox::getLib('parse.output')->shorten($aRow['headline'], Phpfox::getParam('notification.total_notification_title_length'), '...');
        $sMessage = Phpfox::getPhrase('foxfavorite.users_has_already_added_a_resume_headline', array('users' => $sUsers, 'headline' => $sHeadline));

        return array(
            'link' => Phpfox::getLib('url')->permalink('resume.view', $aRow['resume_id'], $aRow['headline']),
            'message' => $sMessage,
            'icon' => Phpfox::getLib('template')->getStyle('image', 'activity.png', 'blog'));
    }

    public function getNotificationAddJob($aNotification)
    {
        if (!Phpfox::isModule('jobposting'))
        {
            return false;
        }
        
        $aRow = $this->database()->select('j.job_id, j.title, ' . Phpfox::getUserField())
        ->from(Phpfox::getT('jobposting_job'), 'j')
        ->join(Phpfox::getT('user'), 'u', 'u.user_id = j.user_id')
        ->where('j.job_id = ' . (int)$aNotification['item_id'])
        ->execute('getSlaveRow');
        
        if (empty($aRow))
        {
            return false;
        }
        
        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');
        $sMessage = Phpfox::getPhrase('foxfavorite.users_has_already_posted_a_job_title', array('users' => $sUsers, 'title' => $sTitle));

        return array(
            'link' => Phpfox::getLib('url')->permalink('jobposting', $aRow['job_id'], $aRow['title']),
            'message' => $sMessage,
            'icon' => Phpfox::getLib('template')->getStyle('image', 'activity.png', 'blog'));
    }

    public function getNotificationAddPetition($aNotification)
    {
        if (!Phpfox::isModule('petition'))
        {
            return false;
        }
        
        $aRow = $this->database()->select('p.petition_id, p.title, ' . Phpfox::getUserField())
        ->from(Phpfox::getT('petition'), 'p')
        ->join(Phpfox::getT('user'), 'u', 'u.user_id = p.user_id')
        ->where('p.petition_id = ' . (int)$aNotification['item_id'])
        ->execute('getSlaveRow');
        
        if (empty($aRow))
        {
            return false;
        }
        
        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');
        $sMessage = Phpfox::getPhrase('foxfavorite.users_has_already_posted_a_petition_title', array('users' => $sUsers, 'title' => $sTitle));

        return array(
            'link' => Phpfox::permalink('petition', $aRow['petition_id'], $aRow['title']),
            'message' => $sMessage,
            'icon' => Phpfox::getLib('template')->getStyle('image', 'activity.png', 'blog'));
    }

    public function getNotificationAddMusicsharing($aNotification)
    {
        if (!Phpfox::isModule('musicsharing'))
        {
            return false;
        }

        $aRow = $this->database()->select('s.song_id, s.title, ' . Phpfox::getUserField())
        ->from(Phpfox::getT('m2bmusic_album_song'), 's')
        ->join(Phpfox::getT('m2bmusic_album'), 'a', 'a.album_id = s.album_id')
        ->join(Phpfox::getT('user'), 'u', 'u.user_id = a.user_id')
        ->where('s.song_id = ' . (int)$aNotification['item_id'])
        ->execute('getSlaveRow');
        
        if (empty($aRow))
        {
            return false;
        }
        
        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');
        $sMessage = Phpfox::getPhrase('foxfavorite.users_has_already_posted_a_song_title', array('users' => $sUsers, 'title' => $sTitle));

        return array(
            'link' => Phpfox::permalink('musicsharing.listen', 'music_'.$aRow['song_id']),
            'message' => $sMessage,
            'icon' => Phpfox::getLib('template')->getStyle('image', 'activity.png', 'blog'));
    }

    public function getNotificationFavorblog($aNotification)
    {
        if (!phpfox::isModule('blog'))
        {
            return false;
        }
        $this->getItemIdByFavoriteItemId($aNotification);
        $aRow = $this->database()->select('b.blog_id, b.title, b.user_id, u.gender, u.full_name')->from(Phpfox::getT('blog'), 'b')->join(Phpfox::getT('user'), 'u', 'u.user_id = b.user_id')->where('b.blog_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');

        if (!isset($aRow['blog_id']))
        {
            return false;
        }

        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');

        $sPhrase = '';
        $sPhrase = Phpfox::getPhrase('foxfavorite.user_favorited_your_blog_title', array('users' => $sUsers, 'title' => $sTitle));
        
        return array(
            'link' => Phpfox::getLib('url')->permalink('blog', $aRow['blog_id'], $aRow['title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)));
    }

    public function getNotificationFavorprofile($aNotification)
    {
        $this->getItemIdByFavoriteItemId($aNotification);
        $aRow = $this->database()->select('u.user_id, u.gender, u.full_name, u.user_name')->from(Phpfox::getT('user'), 'u')->where('u.user_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');

        if (!isset($aRow['user_id']))
        {
            return false;
        }

        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        //$sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');

        $sPhrase = '';
        $sPhrase = Phpfox::getPhrase('foxfavorite.user_favorited_your_profile', array('users' => $sUsers, ));
        
        return array(
            'link' => Phpfox::getLib('url')->permalink($aRow['user_name'], ''),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)));
    }

    public function getNotificationFavormarketplace($aNotification)
    {
        if (!phpfox::isModule('marketplace'))
        {
            return false;
        }
        $this->getItemIdByFavoriteItemId($aNotification);
        $aRow = $this->database()->select('l.listing_id, l.title, l.user_id, u.gender, u.full_name')->from(Phpfox::getT('marketplace'), 'l')->join(Phpfox::getT('user'), 'u', 'u.user_id = l.user_id')->where('l.listing_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');

        if (!isset($aRow['listing_id']))
        {
            return false;
        }

        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');

        $sPhrase = '';
        $sPhrase = Phpfox::getPhrase('foxfavorite.user_favorited_your_listing_title', array('users' => $sUsers, 'title' => $sTitle));
        
        return array(
            'link' => Phpfox::getLib('url')->permalink('marketplace', $aRow['listing_id'], $aRow['title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)));
    }

    public function getNotificationFavorvideo($aNotification)
    {
        if (!phpfox::isModule('video'))
        {
            return false;
        }
        $this->getItemIdByFavoriteItemId($aNotification);
        $aRow = $this->database()->select('v.video_id, v.title, v.user_id, u.gender, u.full_name')->from(Phpfox::getT('video'), 'v')->join(Phpfox::getT('user'), 'u', 'u.user_id = v.user_id')->where('v.video_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');

        if (!isset($aRow['video_id']))
        {
            return false;
        }

        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');

        $sPhrase = '';
        $sPhrase = Phpfox::getPhrase('foxfavorite.user_favorited_your_video_title', array('users' => $sUsers, 'title' => $sTitle));
        
        return array(
            'link' => Phpfox::getLib('url')->permalink('video', $aRow['video_id'], $aRow['title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)));
    }

    public function getNotificationFavormusic($aNotification)
    {
        if (!phpfox::isModule('music'))
        {
            return false;
        }
        $this->getItemIdByFavoriteItemId($aNotification);
        $aRow = $this->database()->select('m.song_id, m.title, m.user_id, u.gender, u.full_name')->from(Phpfox::getT('music_song'), 'm')->join(Phpfox::getT('user'), 'u', 'u.user_id = m.user_id')->where('m.song_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');

        if (!isset($aRow['song_id']))
        {
            return false;
        }

        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');

        $sPhrase = '';
        $sPhrase = Phpfox::getPhrase('foxfavorite.user_favorited_your_song_title', array('users' => $sUsers, 'title' => $sTitle));
        
        return array(
            'link' => Phpfox::getLib('url')->permalink('music', $aRow['song_id'], $aRow['title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)));
    }

    public function getNotificationFavorpages($aNotification)
    {
        if (!phpfox::isModule('pages'))
        {
            return false;
        }
        $this->getItemIdByFavoriteItemId($aNotification);
        $aRow = $this->database()->select('p.page_id, p.title, p.user_id, u.gender, u.full_name')->from(Phpfox::getT('pages'), 'p')->join(Phpfox::getT('user'), 'u', 'u.user_id = p.user_id')->where('p.page_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');

        if (!isset($aRow['page_id']))
        {
            return false;
        }

        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');

        $sPhrase = '';
        $sPhrase = Phpfox::getPhrase('foxfavorite.user_favorited_your_pages_title', array('users' => $sUsers, 'title' => $sTitle));
        
        return array(
            'link' => Phpfox::getLib('url')->permalink('pages', $aRow['page_id'], $aRow['title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)));
    }

    public function getNotificationFavorphoto($aNotification)
    {
        if (!phpfox::isModule('photo'))
        {
            return false;
        }
        $this->getItemIdByFavoriteItemId($aNotification);
        $aRow = $this->database()->select('p.photo_id, p.title, p.user_id, u.gender, u.full_name')->from(Phpfox::getT('photo'), 'p')->join(Phpfox::getT('user'), 'u', 'u.user_id = p.user_id')->where('p.photo_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');

        if (!isset($aRow['photo_id']))
        {
            return false;
        }

        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');

        $sPhrase = '';
        $sPhrase = Phpfox::getPhrase('foxfavorite.user_favorited_your_photo_title', array('users' => $sUsers, 'title' => $sTitle));
        
        return array(
            'link' => Phpfox::getLib('url')->permalink('photo', $aRow['photo_id'], $aRow['title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)));
    }

    public function getNotificationFavorevent($aNotification)
    {
        if (!phpfox::isModule('event'))
        {
            return false;
        }
        $this->getItemIdByFavoriteItemId($aNotification);
        $aRow = $this->database()->select('e.event_id, e.title, e.user_id, u.gender, u.full_name')->from(Phpfox::getT('event'), 'e')->join(Phpfox::getT('user'), 'u', 'u.user_id = e.user_id')->where('e.event_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');

        if (!isset($aRow['event_id']))
        {
            return false;
        }

        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');

        $sPhrase = '';
        $sPhrase = Phpfox::getPhrase('foxfavorite.user_favorited_your_event_title', array('users' => $sUsers, 'title' => $sTitle));
        
        return array(
            'link' => Phpfox::getLib('url')->permalink('event', $aRow['event_id'], $aRow['title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)));
    }

    public function getNotificationFavorpoll($aNotification)
    {
        if (!phpfox::isModule('poll'))
        {
            return false;
        }
        $this->getItemIdByFavoriteItemId($aNotification);
        $aRow = $this->database()->select('p.poll_id, p.question as title, p.user_id, u.gender, u.full_name')->from(Phpfox::getT('poll'), 'p')->join(Phpfox::getT('user'), 'u', 'u.user_id = p.user_id')->where('p.poll_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');

        if (!isset($aRow['poll_id']))
        {
            return false;
        }

        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');

        $sPhrase = '';
        $sPhrase = Phpfox::getPhrase('foxfavorite.user_favorited_your_poll_title', array('users' => $sUsers, 'title' => $sTitle));
        
        return array(
            'link' => Phpfox::getLib('url')->permalink('poll', $aRow['poll_id'], $aRow['title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)));
    }

    public function getNotificationFavorquiz($aNotification)
    {
        if (!phpfox::isModule('quiz'))
        {
            return false;
        }
        $this->getItemIdByFavoriteItemId($aNotification);
        $aRow = $this->database()->select('p.quiz_id, p.title, p.user_id, u.gender, u.full_name')->from(Phpfox::getT('quiz'), 'p')->join(Phpfox::getT('user'), 'u', 'u.user_id = p.user_id')->where('p.quiz_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');

        if (!isset($aRow['quiz_id']))
        {
            return false;
        }

        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');

        $sPhrase = '';
        $sPhrase = Phpfox::getPhrase('foxfavorite.user_favorited_your_quiz_title', array('users' => $sUsers, 'title' => $sTitle));
        
        return array(
            'link' => Phpfox::getLib('url')->permalink('quiz', $aRow['quiz_id'], $aRow['title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)));
    }

    public function getNotificationFavorkaraoke($aNotification)
    {
        if (!phpfox::isModule('karaoke'))
        {
            return false;
        }
        
        $this->getItemIdByFavoriteItemId($aNotification);
        
        $aFavor = $this->database()->select('kf.*')->from(Phpfox::getT('karaoke_favorite'), 'kf')->where('kf.favorite_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');
        
        if(!count($aFavor))
        {
            return false;
        }
        
        if($aFavor['item_type']=='song')
        {
            $aRow = $this->database()->select('ks.song_id, ks.title, ks.user_id, u.gender, u.full_name, kf.*')->from(Phpfox::getT('karaoke_song'), 'ks')->join(Phpfox::getT('karaoke_favorite'), 'kf', 'kf.item_id = ks.song_id')->join(Phpfox::getT('user'), 'u', 'u.user_id = ks.user_id')->where('kf.favorite_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');
    
            if (!isset($aRow['song_id']))
            {
                return false;
            }
    
            $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
            $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');
    
            $sPhrase = '';
            $sPhrase = Phpfox::getPhrase('foxfavorite.user_favorited_your_karaoke_song_title', array('users' => $sUsers, 'title' => $sTitle));
            
            return array(
                'link' => Phpfox::getLib('url')->permalink('karaoke.songdetail', $aRow['song_id'], $aRow['title']),
                'message' => $sPhrase,
                'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)));
        }
        elseif($aFavor['item_type']=='recording')
        {
            $aRow = $this->database()->select('kr.recording_id, kr.title, kr.user_id, u.gender, u.full_name, kf.*')->from(Phpfox::getT('karaoke_recording'), 'kr')->join(Phpfox::getT('karaoke_favorite'), 'kf', 'kf.item_id = kr.recording_id')->join(Phpfox::getT('user'), 'u', 'u.user_id = kr.user_id')->where('kf.favorite_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');
    
            if (!isset($aRow['recording_id']))
            {
                return false;
            }
    
            $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
            $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');
    
            $sPhrase = '';
            $sPhrase = Phpfox::getPhrase('foxfavorite.user_favorited_your_karaoke_recording_title', array('users' => $sUsers, 'title' => $sTitle));
            
            return array(
                'link' => Phpfox::getLib('url')->permalink('karaoke.recordingdetail', $aRow['recording_id'], $aRow['title']),
                'message' => $sPhrase,
                'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)));
        }
        else
        {
            return false;
        }
    }

    public function getNotificationFavorchannelvideo($aNotification)
    {
        if (!phpfox::isModule('videochannel'))
        {
            return false;
        }
        $this->getItemIdByFavoriteItemId($aNotification);
        $aRow = $this->database()->select('v.video_id, v.title, v.user_id, u.gender, u.full_name')->from(Phpfox::getT('channel_video'), 'v')->join(Phpfox::getT('user'), 'u', 'u.user_id = v.user_id')->where('v.video_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');

        if (!isset($aRow['video_id']))
        {
            return false;
        }

        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');

        $sPhrase = '';
        $sPhrase = Phpfox::getPhrase('foxfavorite.user_favorited_your_video_title', array('users' => $sUsers, 'title' => $sTitle));
        
        return array(
            'link' => Phpfox::getLib('url')->permalink('videochannel', $aRow['video_id'], $aRow['title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)));
    }

    public function getNotificationFavordocument($aNotification)
    {
        if (!phpfox::isModule('document'))
        {
            return false;
        }
        $this->getItemIdByFavoriteItemId($aNotification);
        $aRow = $this->database()->select('d.document_id, d.title, d.user_id, u.gender, u.full_name')->from(Phpfox::getT('document'), 'd')->join(Phpfox::getT('user'), 'u', 'u.user_id = d.user_id')->where('d.document_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');

        if (!isset($aRow['document_id']))
        {
            return false;
        }

        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');

        $sPhrase = '';
        $sPhrase = Phpfox::getPhrase('foxfavorite.user_favorited_your_document_title', array('users' => $sUsers, 'title' => $sTitle));
        
        return array(
            'link' => Phpfox::getLib('url')->permalink('document', $aRow['document_id'], $aRow['title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)));
    }

    public function getNotificationFavorfevent($aNotification)
    {
        if (!phpfox::isModule('fevent'))
        {
            return false;
        }
        $this->getItemIdByFavoriteItemId($aNotification);
        $aRow = $this->database()->select('e.event_id, e.title, e.user_id, u.gender, u.full_name')->from(Phpfox::getT('fevent'), 'e')->join(Phpfox::getT('user'), 'u', 'u.user_id = e.user_id')->where('e.event_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');

        if (!isset($aRow['event_id']))
        {
            return false;
        }

        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');

        $sPhrase = '';
        $sPhrase = Phpfox::getPhrase('foxfavorite.user_favorited_your_event_title', array('users' => $sUsers, 'title' => $sTitle));
        
        return array(
            'link' => Phpfox::getLib('url')->permalink('fevent', $aRow['event_id'], $aRow['title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)));
    }

    public function getNotificationFavoradvancedmarketplace($aNotification)
    {
        if (!phpfox::isModule('advancedmarketplace'))
        {
            return false;
        }
        $this->getItemIdByFavoriteItemId($aNotification);
        $aRow = $this->database()->select('l.listing_id, l.title, l.user_id, u.gender, u.full_name')->from(Phpfox::getT('advancedmarketplace'), 'l')->join(Phpfox::getT('user'), 'u', 'u.user_id = l.user_id')->where('l.listing_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');

        if (!isset($aRow['listing_id']))
        {
            return false;
        }

        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');

        $sPhrase = '';
        $sPhrase = Phpfox::getPhrase('foxfavorite.user_favorited_your_listing_title', array('users' => $sUsers, 'title' => $sTitle));
        
        return array(
            'link' => Phpfox::getLib('url')->permalink('advancedmarketplace', $aRow['listing_id'], $aRow['title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)));
    }

    public function getNotificationFavoradvancedphoto($aNotification)
    {
        if (!phpfox::isModule('photo'))
        {
            return false;
        }
        $this->getItemIdByFavoriteItemId($aNotification);
        $aRow = $this->database()->select('p.photo_id, p.title, p.user_id, u.gender, u.full_name')->from(Phpfox::getT('photo'), 'p')->join(Phpfox::getT('user'), 'u', 'u.user_id = p.user_id')->where('p.photo_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');

        if (!isset($aRow['photo_id']))
        {
            return false;
        }

        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');

        $sPhrase = '';
        $sPhrase = Phpfox::getPhrase('foxfavorite.user_favorited_your_photo_title', array('users' => $sUsers, 'title' => $sTitle));
        
        return array(
            'link' => Phpfox::getLib('url')->permalink('advancedphoto', $aRow['photo_id'], $aRow['title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)));
    }

    public function getNotificationFavordirectory($aNotification)
    {
        if (!phpfox::isModule('directory'))
        {
            return false;
        }
        
        $this->getItemIdByFavoriteItemId($aNotification);
        $aRow = $this->database()
            ->select('c.business_id, c.name as title, c.user_id, u.gender, u.full_name')
            ->from(Phpfox::getT('directory_business'), 'c')
            ->join(Phpfox::getT('user'), 'u', 'u.user_id = c.user_id')
            ->where('c.business_id = ' . (int)$aNotification['item_id'])
            ->execute('getSlaveRow');
        if (!isset($aRow['business_id']))
        {
            return false;
        }

        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');
        $sPhrase = Phpfox::getPhrase('foxfavorite.users_favorited_your_business_title', array('users' => $sUsers, 'title' => $sTitle));
        
        return array(
            'link' => Phpfox::getLib('url')->permalink('directory.detail', $aRow['business_id'], $aRow['title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)));
    }

    public function getNotificationFavorauction($aNotification)
    {
        if (!phpfox::isModule('auction'))
        {
            return false;
        }

        $this->getItemIdByFavoriteItemId($aNotification);
       
        $sWhere = '';
        $aRow = $this->database()->select('e.product_id,e.name as title,'.Phpfox::getUserField())
            ->from(Phpfox::getT('ecommerce_product'), 'e')
            ->join(PHpfox::getT('user'),'u','u.user_id = e.user_id')
            ->where('e.product_id = ' . (int) $aNotification['item_id'] . $sWhere)
            ->execute('getSlaveRow');
        
        if (!isset($aRow['product_id']))
        {
            return false;
        }

        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');
        $sPhrase = Phpfox::getPhrase('foxfavorite.users_favorited_your_product_title', array('users' => $sUsers, 'title' => $sTitle));
        
        return array(
            'link' => Phpfox::getLib('url')->permalink('auction.detail', $aRow['product_id'], $aRow['title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)));
    }

    public function getNotificationFavorcoupon($aNotification)
    {
        if (!phpfox::isModule('coupon'))
        {
            return false;
        }
        
        $this->getItemIdByFavoriteItemId($aNotification);
        $aRow = $this->database()->select('c.coupon_id, c.title, c.user_id, u.gender, u.full_name')->from(Phpfox::getT('coupon'), 'c')->join(Phpfox::getT('user'), 'u', 'u.user_id = c.user_id')->where('c.coupon_id = ' . (int)$aNotification['item_id'])->execute('getSlaveRow');
        if (!isset($aRow['coupon_id']))
        {
            return false;
        }

        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');
        $sPhrase = Phpfox::getPhrase('foxfavorite.user_favorited_your_coupon_title', array('users' => $sUsers, 'title' => $sTitle));
        
        return array(
            'link' => Phpfox::getLib('url')->permalink('coupon.detail', $aRow['coupon_id'], $aRow['title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)));
    }

    public function getNotificationFavorfoxfeedspro($aNotification)
    {
        if (!Phpfox::isModule('foxfeedspro'))
        {
            return false;
        }
        
        $this->getItemIdByFavoriteItemId($aNotification);
        
        $aRow = $this->database()->select('ni.item_id, ni.item_title, ni.user_id, u.gender, u.full_name')
        ->from(Phpfox::getT('ynnews_items'), 'ni')
        ->join(Phpfox::getT('user'), 'u', 'u.user_id = ni.user_id')
        ->where('ni.item_id = ' . (int)$aNotification['item_id'])
        ->execute('getSlaveRow');
        
        if (!isset($aRow['item_id']))
        {
            return false;
        }

        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['item_title'], Phpfox::getParam('notification.total_notification_title_length'), '...');
        $sPhrase = Phpfox::getPhrase('foxfavorite.users_favorited_your_news_title', array('users' => $sUsers, 'title' => $sTitle));
        
        return array(
            'link' => Phpfox::permalink('news.newsdetails', 'item_'.$aRow['item_id'], $aRow['item_title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)));
    }

    public function getNotificationFavorpetition($aNotification)
    {
        if (!Phpfox::isModule('petition'))
        {
            return false;
        }
        
        $this->getItemIdByFavoriteItemId($aNotification);
        
        $aRow = $this->database()->select('p.petition_id, p.title, p.user_id, u.gender, u.full_name')
        ->from(Phpfox::getT('petition'), 'p')
        ->join(Phpfox::getT('user'), 'u', 'u.user_id = p.user_id')
        ->where('p.petition_id = ' . (int)$aNotification['item_id'])
        ->execute('getSlaveRow');
        
        if (!isset($aRow['petition_id']))
        {
            return false;
        }

        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');
        $sPhrase = Phpfox::getPhrase('foxfavorite.users_favorited_your_petition_title', array('users' => $sUsers, 'title' => $sTitle));
        
        return array(
            'link' => Phpfox::permalink('petition', $aRow['petition_id'], $aRow['title']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)));
    }

    public function getNotificationFavormusicsharing($aNotification)
    {
        if (!Phpfox::isModule('musicsharing'))
        {
            return false;
        }
        
        $this->getItemIdByFavoriteItemId($aNotification);
        
        $aRow = $this->database()->select('s.song_id, s.title, a.user_id, u.gender, u.full_name')
        ->from(Phpfox::getT('m2bmusic_album_song'), 's')
        ->join(Phpfox::getT('m2bmusic_album'), 'a', 'a.album_id = s.album_id')
        ->join(Phpfox::getT('user'), 'u', 'u.user_id = a.user_id')
        ->where('s.song_id = ' . (int)$aNotification['item_id'])
        ->execute('getSlaveRow');
        
        if (!isset($aRow['song_id']))
        {
            return false;
        }

        $sUsers = Phpfox::getService('notification')->getUsers($aNotification);
        $sTitle = Phpfox::getLib('parse.output')->shorten($aRow['title'], Phpfox::getParam('notification.total_notification_title_length'), '...');
        $sPhrase = Phpfox::getPhrase('foxfavorite.users_favorited_your_song_title', array('users' => $sUsers, 'title' => $sTitle));
        
        return array(
            'link' => Phpfox::permalink('musicsharing.listen', 'music_'.$aRow['song_id']),
            'message' => $sPhrase,
            'icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)));
    }

    public function getActivityFeedBlog($aRow)
    {
        if (!phpfox::isModule('blog'))
        {
            return false;
        }
        
        $this->getItemIdByFavoriteItemId($aRow);
        
        if (Phpfox::isUser())
        {
            $this->database()->select('l.like_id AS is_liked, ')->leftJoin(Phpfox::getT('like'), 'l', 'l.type_id = \'blog\' AND l.item_id = b.blog_id AND l.user_id = ' . Phpfox::getUserId());
        }

        $aRow = $this->database()->select('b.blog_id, b.title, f.time_stamp, b.total_comment, b.total_like, bt.text_parsed AS text')->from(Phpfox::getT('blog'), 'b')->join(Phpfox::getT('blog_text'), 'bt', 'bt.blog_id = b.blog_id')->join(phpfox::getT('foxfavorite'), 'f', 'f.item_id = b.blog_id')->where('b.blog_id = ' . (int)$aRow['item_id'] . ' and f.type_id = "blog"')->execute('getSlaveRow');
        
        if (empty($aRow))
        {
            return false;
        }
        
        return array(
            'feed_title' => $aRow['title'],
            'feed_info' => Phpfox::getPhrase('foxfavorite.favorited_a_blog'),
            'feed_link' => Phpfox::permalink('blog', $aRow['blog_id'], $aRow['title']),
            'feed_content' => $aRow['text'],
            'feed_icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)),
            'time_stamp' => $aRow['time_stamp'],
            );
    }

    public function getActivityFeedEvent($aItem)
    {
        if (!phpfox::isModule('event'))
        {
            return false;
        }
        $this->getItemIdByFavoriteItemId($aItem);
        
        $aRow = $this->database()->select('e.event_id, e.module_id, e.item_id, e.title, f.time_stamp, e.image_path, e.server_id, e.total_like, e.total_comment, et.description_parsed, l.like_id AS is_liked')->from(Phpfox::getT('event'), 'e')->leftJoin(Phpfox::getT('event_text'), 'et', 'et.event_id = e.event_id')->join(phpfox::getT('foxfavorite'), 'f', 'f.item_id = e.event_id')->leftJoin(Phpfox::getT('like'), 'l', 'l.type_id = \'event\' AND l.item_id = e.event_id AND l.user_id = ' . Phpfox::getUserId())->where('e.event_id = ' . (int)$aItem['item_id'] . ' and f.type_id = "event"')->execute('getSlaveRow');

        if (!isset($aRow['event_id']))
        {
            return false;
        }

        if ((defined('PHPFOX_IS_PAGES_VIEW') && !Phpfox::getService('pages')->hasPerm(null, 'event.view_browse_events')) || (!defined('PHPFOX_IS_PAGES_VIEW') && $aRow['module_id'] == 'pages' && !Phpfox::getService('pages')->hasPerm($aRow['item_id'], 'event.view_browse_events')))
        {
            return false;
        }

        $aReturn = array(
            'feed_title' => $aRow['title'],
            'feed_info' => Phpfox::getPhrase('foxfavorite.favorited_an_event'),
            'feed_link' => Phpfox::permalink('event', $aRow['event_id'], $aRow['title']),
            'feed_content' => $aRow['description_parsed'],
            'feed_icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)),
            'time_stamp' => $aRow['time_stamp'],
            );

        if (!empty($aRow['image_path']) && file_exists(Phpfox::getParam('core.dir_pic').'event/'.sprintf($aRow['image_path'],'_120')))
        {
            $sImage = Phpfox::getLib('image.helper')->display(array(
                'server_id' => $aRow['server_id'],
                'path' => 'event.url_image',
                'file' => $aRow['image_path'],
                'suffix' => ''));

            $aReturn['feed_image_banner'] = $sImage;
        }

        return $aReturn;
    }

    public function getActivityFeedMarketplace($aItem)
    {
        if (!phpfox::isModule('marketplace'))
        {
            return false;
        }
        
        $this->getItemIdByFavoriteItemId($aItem);
        
        $aRow = $this->database()->select('e.listing_id, e.title, f.time_stamp, e.image_path, e.server_id, e.total_like, e.total_comment, et.description_parsed, l.like_id AS is_liked')->from(Phpfox::getT('marketplace'), 'e')->leftJoin(Phpfox::getT('marketplace_text'), 'et', 'et.listing_id = e.listing_id')->join(phpfox::getT('foxfavorite'), 'f', 'f.item_id = e.listing_id')->leftJoin(Phpfox::getT('like'), 'l', 'l.type_id = \'marketplace\' AND l.item_id = e.listing_id AND l.user_id = ' . Phpfox::getUserId())->where('e.listing_id = ' . (int)$aItem['item_id'] . ' and f.type_id = "marketplace"')->execute('getSlaveRow');

        if (!isset($aRow['listing_id']))
        {
            return false;
        }

        $aReturn = array(
            'feed_title' => $aRow['title'],
            'feed_info' => Phpfox::getPhrase('foxfavorite.favorited_a_listing'),
            'feed_link' => Phpfox::permalink('marketplace', $aRow['listing_id'], $aRow['title']),
            'feed_content' => $aRow['description_parsed'],
            'feed_icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)),
            'time_stamp' => $aRow['time_stamp'],
            );

        if (!empty($aRow['image_path']))
        {
            $sImage = Phpfox::getLib('image.helper')->display(array(
                'server_id' => $aRow['server_id'],
                'path' => 'marketplace.url_image',
                'file' => $aRow['image_path'],
                'suffix' => ''));

            $aReturn['feed_image_banner'] = $sImage;
        }

        return $aReturn;
    }

    public function getActivityFeedPoll($aItem)
    {
        if (!phpfox::isModule('poll'))
        {
            return false;
        }
        
        $this->getItemIdByFavoriteItemId($aItem);
        
        $aRow = Phpfox::getService('poll')->getPollByUrl($aItem['item_id']);
        
        if (empty($aRow))
        {
            return false;
        }
        
        $aRow['time_stamp'] = $this->database()->select('time_stamp')
			->from(Phpfox::getT('foxfavorite'))
			->where('type_id = "poll" AND item_id = '.$aItem['item_id'])
			->execute('getSlaveField');
        
        $aRow['poll_is_in_feed'] = true;
		$oTpl = Phpfox::getLib('template');
		$oTpl->assign(array('aPoll' => $aRow, 'iKey' => rand(2,900)));

        $aReturn = array(
            'feed_title' => $aRow['question'],
            'feed_info' => Phpfox::getPhrase('foxfavorite.favorited_a_poll'),
            'feed_link' => Phpfox::permalink('poll', $aRow['poll_id'], $aRow['question']),
            'feed_icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)),
            'time_stamp' => $aRow['time_stamp'],
            );

        if (!empty($aRow['image_path']))
        {
            $sImage = Phpfox::getLib('image.helper')->display(array(
                'server_id' => $aRow['server_id'],
                'path' => 'poll.url_image',
                'file' => $aRow['image_path'],
                'suffix' => ''
                ));

            $aReturn['feed_image_banner'] = $sImage;
            $aReturn['feed_custom_width'] = '100px';
        }

        return $aReturn;
    }

    public function getActivityFeedVideo($aItem, $aCallback = null)
    {
        if (!phpfox::isModule('video'))
        {
            return false;
        }
        
        $this->getItemIdByFavoriteItemId($aItem);
        
        if ($aCallback === null)
        {
            $this->database()->select(Phpfox::getUserField('u', 'parent_') . ', ')->leftJoin(Phpfox::getT('user'), 'u', 'u.user_id = v.parent_user_id');
        }

        $aRow = $this->database()->select('v.video_id, v.module_id, v.item_id, v.title, f.time_stamp, v.total_comment, v.total_like, v.image_path, v.image_server_id, l.like_id AS is_liked, vt.text_parsed')->from(Phpfox::getT('video'), 'v')->leftJoin(Phpfox::getT('like'), 'l', 'l.type_id = \'video\' AND l.item_id = v.video_id AND l.user_id = ' . Phpfox::getUserId())->leftJoin(Phpfox::getT('video_text'), 'vt', 'vt.video_id = v.video_id')->leftjoin(phpfox::getT('foxfavorite'), 'f', 'f.item_id = v.video_id')->where('f.type_id = "video" AND v.video_id = ' . (int)$aItem['item_id'])->execute('getSlaveRow');

        if (!isset($aRow['video_id']))
        {
            return false;
        }

        if ((defined('PHPFOX_IS_PAGES_VIEW') && !Phpfox::getService('pages')->hasPerm(null, 'video.view_browse_videos')) || (!defined('PHPFOX_IS_PAGES_VIEW') && $aRow['module_id'] == 'pages' && !Phpfox::getService('pages')->hasPerm($aRow['item_id'], 'video.view_browse_videos')))
        {
            return false;
        }

        $aReturn = array(
            'feed_title' => $aRow['title'],
            'feed_info' => Phpfox::getPhrase('foxfavorite.favorited_a_video'),
            'feed_link' => Phpfox::permalink('video', $aRow['video_id'], $aRow['title']),
            'feed_content' => $aRow['text_parsed'],
            'feed_icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)),
            'time_stamp' => $aRow['time_stamp'],
            );

        if ($aRow['module_id'] == 'pages')
        {
            $aRow['parent_user_id'] = '';
            $aRow['parent_user_name'] = '';
        }

        if (empty($aRow['parent_user_id']))
        {
            $aReturn['feed_info'] = Phpfox::getPhrase('foxfavorite.favorited_a_video');
        }

        if ($aCallback === null)
        {
            if (!empty($aRow['parent_user_name']) && !defined('PHPFOX_IS_USER_PROFILE') && empty($_POST))
            {
                $aReturn['parent_user'] = Phpfox::getService('user')->getUserFields(true, $aRow, 'parent_');
            }

            if (!PHPFOX_IS_AJAX && defined('PHPFOX_IS_USER_PROFILE') && !empty($aRow['parent_user_name']) && $aRow['parent_user_id'] != Phpfox::getService('profile')->getProfileUserId())
            {
                $aReturn['feed_mini'] = true;
                $aReturn['feed_mini_content'] = Phpfox::getPhrase('feed.full_name_posted_a_href_link_a_video_a_on_a_href_profile_parent_full_name_a_s_a_href_profile_link_wall_a', array(
                    'full_name' => Phpfox::getService('user')->getFirstName($aItem['full_name']),
                    'link' => Phpfox::permalink('video', $aRow['video_id'], $aRow['title']),
                    'profile' => Phpfox::getLib('url')->makeUrl($aRow['parent_user_name']),
                    'parent_full_name' => $aRow['parent_full_name'],
                    'profile_link' => Phpfox::getLib('url')->makeUrl($aRow['parent_user_name'])));
                $aReturn['feed_title'] = '';
                unset($aReturn['feed_status'], $aReturn['feed_image'], $aReturn['feed_content']);
            }
        }

        if (!PHPFOX_IS_AJAX && defined('PHPFOX_IS_USER_PROFILE') && !empty($aRow['parent_user_name']) && $aRow['parent_user_id'] != Phpfox::getService('profile')->getProfileUserId())
        {

        }
        else
        {
            if (!empty($aRow['image_path']))
            {
                $sImage = Phpfox::getLib('image.helper')->display(array(
                    'server_id' => $aRow['image_server_id'],
                    'path' => 'core.url_pic',
                    'file' => $aRow['image_path'],
                    'suffix' => ''));

                $aReturn['feed_image_banner'] = $sImage;
            }

            $aReturn['feed_image_onclick'] = '$Core.box(\'video.play\', 700, \'id=' . $aRow['video_id'] . '&amp;feed_id=' . $aItem['feed_id'] . '&amp;popup=true\', \'GET\'); return false;';
        }

        return $aReturn;
    }

    public function getActivityFeedQuiz($aRow)
    {
        if (!phpfox::isModule('quiz'))
        {
            return false;
        }
        
        $this->getItemIdByFavoriteItemId($aRow);
        
        $aRow = $this->database()->select('q.*, l.like_id AS is_liked, f.time_stamp,' . Phpfox::getUserField())->from(Phpfox::getT('quiz'), 'q')->join(Phpfox::getT('user'), 'u', 'u.user_id = q.user_id')->leftjoin(phpfox::getT('foxfavorite'), 'f', 'f.item_id = q.quiz_id')->leftJoin(Phpfox::getT('like'), 'l', 'l.type_id = \'quiz\' AND l.item_id = q.quiz_id AND l.user_id = ' . Phpfox::getUserId())->where('f.type_id = "quiz" AND q.quiz_id = ' . (int)$aRow['item_id'])->execute('getSlaveRow');

        if (!isset($aRow['quiz_id']))
        {
            return false;
        }

        $aReturn = array(
            'feed_title' => $aRow['title'],
            'feed_info' => Phpfox::getPhrase('foxfavorite.favorited_a_quiz'),
            'feed_link' => Phpfox::permalink('quiz', $aRow['quiz_id'], $aRow['title']),
            'feed_content' => $aRow['description'],
            'feed_is_liked' => $aRow['is_liked'],
            'feed_icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)),
            'time_stamp' => $aRow['time_stamp'],
            );

        if (!empty($aRow['image_path']))
        {
            $sImage = Phpfox::getLib('image.helper')->display(array(
                'server_id' => $aRow['server_id'],
                'path' => 'quiz.url_image',
                'file' => $aRow['image_path'],
                'suffix' => '_' . Phpfox::getParam('quiz.quiz_max_image_pic_size')
            ));

            $aReturn['feed_image_banner'] = $sImage;
            $aReturn['feed_custom_width'] = '78px';
        }

        return $aReturn;
    }


    public function getActivityFeedSong($aItem, $bIsAlbum = false)
    {
        if (!phpfox::isModule('music'))
        {
            return false;
        }
        
        $this->getItemIdByFavoriteItemId($aItem);
        
        if ($bIsAlbum)
        {
            $this->database()->select('ma.name AS album_name, ma.album_id, u.gender, ')->leftJoin(Phpfox::getT('music_album'), 'ma', 'ma.album_id = ms.album_id')->leftJoin(Phpfox::getT('user'), 'u', 'u.user_id = ma.user_id');
        }

        $this->database()->select('mp.play_id AS is_on_profile, ')->leftJoin(Phpfox::getT('music_profile'), 'mp', 'mp.song_id = ms.song_id AND mp.user_id = ' . Phpfox::getUserId());

        $aRow = $this->database()->select('ms.song_id, ms.title, ms.module_id, ms.item_id, ms.description, ms.total_play, ms.privacy, f.time_stamp, ms.total_comment, ms.total_like, ms.user_id, l.like_id AS is_liked')->from(Phpfox::getT('music_song'), 'ms')->leftjoin(phpfox::getT('foxfavorite'), 'f', 'f.item_id = ms.song_id')->leftJoin(Phpfox::getT('like'), 'l', 'l.type_id = \'music_song\' AND l.item_id = ms.song_id AND l.user_id = ' . Phpfox::getUserId())->where('f.type_id = "music" AND ms.song_id = ' . (int)$aItem['item_id'])->execute('getSlaveRow');

        if (!isset($aRow['song_id']))
        {
            return false;
        }

        if ((defined('PHPFOX_IS_PAGES_VIEW') && !Phpfox::getService('pages')->hasPerm(null, 'music.view_browse_music')) || (!defined('PHPFOX_IS_PAGES_VIEW') && $aRow['module_id'] == 'pages' && !Phpfox::getService('pages')->hasPerm($aRow['item_id'], 'music.view_browse_music')))
        {
            return false;
        }

        if ($bIsAlbum && empty($aRow['album_name']))
        {
            $bIsAlbum = false;
        }

        $iTitleLength = (Phpfox::isModule('notification') ? (Phpfox::isModule('notification') ? Phpfox::getParam('notification.total_notification_title_length') : $this->_iFallbackLength) : 50);
        
        $aReturn = array(
            'feed_title' => Phpfox::getLib('parse.output')->shorten($aRow['title'], $iTitleLength, '...'),
            'feed_status' => $aRow['description'],
            'feed_info' => Phpfox::getPhrase('foxfavorite.favorited_a_song'), //($bIsAlbum ? Phpfox::getPhrase('feed.shared_a_song_from_gender_album_a_href_album_link_album_name_a', array('gender' => Phpfox::getService('user')->gender($aRow['gender'], 1), 'album_link' => Phpfox::getLib('url')->permalink('music.album', $aRow['album_id'], $aRow['album_name']), 'album_name' => Phpfox::getLib('parse.output')->shorten($aRow['album_name'], (Phpfox::isModule('notification') ? Phpfox::getParam('notification.total_notification_title_length') : $this->_iFallbackLength ), '...'))) : Phpfox::getPhrase('feed.shared_a_song')),
            'feed_link' => Phpfox::permalink('music', $aRow['song_id'], $aRow['title']),
            'feed_content' => ($aRow['total_play'] > 1 ? $aRow['total_play'] . ' ' . Phpfox::getPhrase('music.plays_lowercase') : Phpfox::getPhrase('music.1_play')),
            'feed_icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)),
            'time_stamp' => $aRow['time_stamp'],
            );

        $aReturn['feed_image'] = Phpfox::getLib('image.helper')->display(array('theme' => 'misc/play_button.png', 'return_url' => false));

        return $aReturn;
    }

    public function getActivityFeedPhoto($aItem, $aCallback = null)
    {
        if (!phpfox::isModule('photo'))
        {
            return false;
        }
        
        $this->getItemIdByFavoriteItemId($aItem);
        
        $aRow = $this->database()->select('photo.*, f.time_stamp, l.like_id AS is_liked, pi.description, pfeed.photo_id AS extra_photo_id, pa.album_id, pa.name')->from(phpfox::getT('photo'), 'photo')->join(Phpfox::getT('photo_info'), 'pi', 'pi.photo_id = photo.photo_id')->leftjoin(phpfox::getT('foxfavorite'), 'f', 'f.item_id = photo.photo_id')->leftJoin(Phpfox::getT('like'), 'l', 'l.type_id = \'photo\' AND l.item_id = photo.photo_id AND l.user_id = ' . Phpfox::getUserId())->leftJoin(Phpfox::getT('photo_feed'), 'pfeed', 'pfeed.feed_id = ' . (int)$aItem['feed_id'])->leftJoin(Phpfox::getT('photo_album'), 'pa', 'pa.album_id = photo.album_id')->where('f.type_id = "photo" AND photo.photo_id = ' . (int)$aItem['item_id'])->execute('getSlaveRow');

        if (!isset($aRow['photo_id']))
        {
            return false;
        }

        if ((defined('PHPFOX_IS_PAGES_VIEW') && !Phpfox::getService('pages')->hasPerm(null, 'photo.view_browse_photos')) || (!defined('PHPFOX_IS_PAGES_VIEW') && $aRow['module_id'] == 'pages' && !Phpfox::getService('pages')->hasPerm($aRow['group_id'], 'photo.view_browse_photos')))
        {
            return false;
        }

        $bIsPhotoAlbum = false;
        
        if ($aRow['album_id'])
        {
            $bIsPhotoAlbum = true;
        }

        $sLink = Phpfox::permalink('photo', $aRow['photo_id'], $aRow['title']) . ($bIsPhotoAlbum ? 'albumid_' . $aRow['album_id'] : 'userid_' . $aRow['user_id']) . '/';
        $sFeedImageOnClick = '';

        if (($aRow['mature'] == 0 || (($aRow['mature'] == 1 || $aRow['mature'] == 2) && Phpfox::getUserId() && Phpfox::getUserParam('photo.photo_mature_age_limit') <= Phpfox::getUserBy('age'))) || $aRow['user_id'] == Phpfox::getUserId())
        {
            $sCustomCss = 'photo_holder_image';
            $sImage = Phpfox::getLib('image.helper')->display(array(
                'server_id' => $aRow['server_id'],
                'path' => 'photo.url_photo',
                'file' => Phpfox::getService('photo')->getPhotoUrl(array_merge($aRow, array('full_name' => $aItem['full_name']))),
                'suffix' => '',
                'class' => 'photo_holder'));
        }
        else
        {
            $sImage = Phpfox::getLib('image.helper')->display(array('theme' => 'misc/no_access.png'));
            $sFeedImageOnClick = ' onclick="tb_show(\'' . Phpfox::getPhrase('photo.warning') . '\', $.ajaxBox(\'photo.warning\', \'height=300&width=350&link=' . $sLink . '\')); return false;" ';
            $sCustomCss = 'no_ajax_link';
        }
        $aListPhotos = array();
        if ($aRow['extra_photo_id'] > 0)
        {
            $aPhotos = $this->database()->select('p.photo_id, p.album_id, p.user_id, p.title, p.server_id, p.destination, p.mature')->from(Phpfox::getT('photo_feed'), 'pfeed')->join(Phpfox::getT('photo'), 'p', 'p.photo_id = pfeed.photo_id')->where('pfeed.feed_id = ' . (int)$aItem['feed_id'])->limit(3)->order('p.time_stamp DESC')->execute('getSlaveRows');
            foreach ($aPhotos as $aPhoto)
            {
                if (($aPhoto['mature'] == 0 || (($aPhoto['mature'] == 1 || $aPhoto['mature'] == 2) && Phpfox::getUserId() && Phpfox::getUserParam('photo.photo_mature_age_limit') <= Phpfox::getUserBy('age'))) || $aPhoto['user_id'] == Phpfox::getUserId())
                {
                    $aListPhotos[] = '<a href="' . Phpfox::permalink('photo', $aPhoto['photo_id'], $aPhoto['title']) . ($bIsPhotoAlbum ? 'albumid_' . $aRow['album_id'] : 'userid_' . $aRow['user_id']) . '/" class="photo_holder_image" rel="' . $aPhoto['photo_id'] . '">' . Phpfox::getLib('image.helper')->display(array(
                        'server_id' => $aPhoto['server_id'],
                        'path' => 'photo.url_photo',
                        'file' => Phpfox::getService('photo')->getPhotoUrl(array_merge($aPhoto, array('full_name' => $aItem['full_name']))),
                        'suffix' => '_100',
                        'max_width' => 100,
                        'max_height' => 100,
                        'class' => 'photo_holder',
                        'userid' => isset($aItem['user_id']) ? $aItem['user_id'] : '')) . '</a>';
                }
                else
                {
                    $aListPhotos[] = '<a href="#" class="no_ajax_link" onclick="tb_show(\'' . Phpfox::getPhrase('photo.warning') . '\', $.ajaxBox(\'photo.warning\', \'height=300&width=350&link=' . Phpfox::permalink('photo', $aPhoto['photo_id'], $aPhoto['title']) . ($bIsPhotoAlbum ? 'albumid_' . $aRow['album_id'] : 'userid_' . $aRow['user_id']) . '/\')); return false;">' . $sImage . '</a>';
                }
            }
            $aListPhotos = array_merge($aListPhotos, array('<a href="' . Phpfox::permalink('photo', $aRow['photo_id'], $aRow['title']) . ($bIsPhotoAlbum ? 'albumid_' . $aRow['album_id'] : 'userid_' . $aRow['user_id']) . '/" ' . (empty($sFeedImageOnClick) ? ' class="photo_holder_image" rel="' . $aRow['photo_id'] . '" ' : $sFeedImageOnClick . ' class="no_ajax_link"') . '>' . $sImage . '</a>'));
        }

        $aReturn = array(
            'feed_title' => '',
            'feed_info' => Phpfox::getPhrase('foxfavorite.favorited_a_photo'),
            'feed_image' => (count($aListPhotos) ? $aListPhotos : $sImage),
            'feed_status' => $aRow['description'],
            'feed_link' => $sLink,
            'feed_icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)),
            'time_stamp' => $aRow['time_stamp'],
            'custom_css' => $sCustomCss,
            'custom_rel' => $aRow['photo_id'],
            'custom_js' => $sFeedImageOnClick,
        );

        return $aReturn;
    }

    public function getActivityFeedProfile($aItem)
    {
        return false;
    }

    public function getActivityFeedPages($aRow)
    {
        if (!phpfox::isModule('pages'))
        {
            return false;
        }
        
        $this->getItemIdByFavoriteItemId($aRow);
        
        if (Phpfox::isUser())
        {
            $this->database()->select('l.like_id AS is_liked, ')->leftJoin(Phpfox::getT('like'), 'l', 'l.type_id = \'pages\' AND l.item_id = p.page_id AND l.user_id = ' . Phpfox::getUserId());
        }

        $aRow = $this->database()->select('p.page_id, p.title, f.time_stamp, p.total_comment, p.total_like, pu.vanity_url, p.image_path')->from(Phpfox::getT('pages'), 'p')->join(phpfox::getT('foxfavorite'), 'f', 'f.item_id = p.page_id')->leftJoin(Phpfox::getT('pages_url'), 'pu', 'pu.page_id = p.page_id')->where('p.page_id = ' . (int)$aRow['item_id'] . ' and f.type_id = "pages"')->execute('getSlaveRow');
        
        if (empty($aRow))
        {
            return false;
        }
        
        $aReturn = array(
            'feed_title' => $aRow['title'],
            'feed_info' => Phpfox::getPhrase('foxfavorite.favorited_a_page'),
            'feed_link' => phpfox::getService('pages')->getUrl($aRow['page_id'], $aRow['title'], $aRow['vanity_url']),
            'feed_content' => '',
            'feed_icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)),
            'time_stamp' => $aRow['time_stamp'],
            );
        
        if (!empty($aRow['image_path']))
        {
            $sImage = Phpfox::getLib('image.helper')->display(array(
                'server_id' => 0,
                'path' => 'pages.url_image',
                'file' => $aRow['image_path'],
                'suffix' => ''));

            $aReturn['feed_image_banner'] = $sImage;
        }

        return $aReturn;
    }

    public function getActivityFeedKaraoke($aItem)
    {
        if (!phpfox::isModule('karaoke'))
        {
            return false;
        }
        
        $this->getItemIdByFavoriteItemId($aItem);
        
        $aFavor = $this->database()->select('kf.*')->from(Phpfox::getT('karaoke_favorite'), 'kf')->where('kf.favorite_id = ' . (int)$aItem['item_id'])->execute('getSlaveRow');
        
        if(!count($aFavor))
        {
            return false;
        }
        
        if($aFavor['item_type']=='song')
        {
            $aRow = $this->database()->select('ks.*, kf.*, f.time_stamp')->from(Phpfox::getT('karaoke_song'), 'ks')->join(Phpfox::getT('karaoke_favorite'), 'kf', 'kf.item_id = ks.song_id')->leftJoin(Phpfox::getT('foxfavorite'), 'f', 'f.item_id = kf.favorite_id')->where('f.type_id = "karaoke" AND kf.favorite_id = ' . (int)$aItem['item_id'])->execute('getSlaveRow');
    
            if (!isset($aRow['song_id']))
            {
                return false;
            }
    
            $iTitleLength = (Phpfox::isModule('notification') ? (Phpfox::isModule('notification') ? Phpfox::getParam('notification.total_notification_title_length') : $this->_iFallbackLength) : 50);
            $aReturn = array(
                'feed_title' => Phpfox::getLib('parse.output')->shorten($aRow['title'], $iTitleLength, '...'),
                'feed_status' => $aRow['description'],
                'feed_info' => Phpfox::getPhrase('foxfavorite.favorited_a_karaoke_song'),
                'feed_link' => Phpfox::permalink('karaoke.songdetail', $aRow['song_id'], $aRow['title']),
                'feed_icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)),
                'time_stamp' => $aRow['time_stamp'],
                );
            
            if (!empty($aRow['image_path']))
            {
                $aReturn['feed_image_banner'] = Phpfox::getLib('image.helper')->display(array(
                    'server_id' => 0,
                    'path' => 'core.url_file',
                    'file' => 'karaoke/image'.$aRow['image_path'],
                    'suffix' => ''));
            }
            else
            {
                $aReturn['feed_image_banner'] = '<img src="'.Phpfox::getParam('core.path').'module/karaoke/static/image/kara-icon.jpg" width="100" />';
            }
            
            return $aReturn;
        }
        elseif($aFavor['item_type']=='recording')
        {
            $aRow = $this->database()->select('kr.*, kf.*, f.time_stamp')->from(Phpfox::getT('karaoke_recording'), 'kr')->join(Phpfox::getT('karaoke_favorite'), 'kf', 'kf.item_id = kr.recording_id')->leftJoin(Phpfox::getT('foxfavorite'), 'f', 'f.item_id = kf.favorite_id')->where('f.type_id = "karaoke" AND kf.favorite_id = ' . (int)$aItem['item_id'])->execute('getSlaveRow');
    
            if (!isset($aRow['recording_id']))
            {
                return false;
            }
    
            $iTitleLength = (Phpfox::isModule('notification') ? (Phpfox::isModule('notification') ? Phpfox::getParam('notification.total_notification_title_length') : $this->_iFallbackLength) : 50);
            $aReturn = array(
                'feed_title' => Phpfox::getLib('parse.output')->shorten($aRow['title'], $iTitleLength, '...'),
                'feed_status' => $aRow['description'],
                'feed_info' => Phpfox::getPhrase('foxfavorite.favorited_a_karaoke_recording'),
                'feed_link' => Phpfox::permalink('karaoke.recordingdetail', $aRow['recording_id'], $aRow['title']),
                'feed_icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)),
                'time_stamp' => $aRow['time_stamp'],
                );
            
            if (!empty($aRow['image_path']))
            {
                $aReturn['feed_image_banner'] = Phpfox::getLib('image.helper')->display(array(
                    'server_id' => 0,
                    'path' => 'core.url_file',
                    'file' => 'karaoke/image'.$aRow['image_path'],
                    'suffix' => ''));
            }
            else
            {
                $aReturn['feed_image_banner'] = '<img src="'.Phpfox::getParam('core.path').'module/karaoke/static/image/kara-icon.jpg" width="100" />';
            }
            
            return $aReturn;
        }
        else
        {
            return false;
        }
    }

    public function getActivityFeedDocument($aRow)
    {
        if (!phpfox::isModule('document'))
        {
            return false;
        }
        
        $this->getItemIdByFavoriteItemId($aRow);
        
        if (Phpfox::isUser())
        {
            $this->database()->select('l.like_id AS is_liked, ')->leftJoin(Phpfox::getT('like'), 'l', 'l.type_id = \'document\' AND l.item_id = d.document_id AND l.user_id = ' . Phpfox::getUserId());
        }

        $aRow = $this->database()->select('d.*, f.time_stamp')->from(Phpfox::getT('document'), 'd')->join(phpfox::getT('foxfavorite'), 'f', 'f.item_id = d.document_id')->where('d.document_id = ' . (int)$aRow['item_id'] . ' and f.type_id = "document"')->execute('getSlaveRow');
        
        if (empty($aRow))
        {
            return false;
        }
        
        $aReturn = array(
            'feed_title' => $aRow['title'],
            'feed_info' => Phpfox::getPhrase('foxfavorite.favorited_a_document'),
            'feed_link' => Phpfox::permalink('document', $aRow['document_id'], $aRow['title']),
            'feed_content' => '',
            'feed_icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)),
            'time_stamp' => $aRow['time_stamp'],
            );
        
        if (!empty($aRow['image_url']))
        {
            $aReturn['feed_image_banner'] = '<img src="' . $aRow['image_url'] . '" style="max-width:98px; max-height:98px; border:solid 1px #EFEFEF;" />';
        }
        else
        {
            $aReturn['feed_image_banner'] = Phpfox::getLib('image.helper')->display(array(
                'server_id' => '',
                'path' => '',
                'file' => '',
                'suffix' => ''
                ));
        }
        
        return $aReturn;
    }

    public function getActivityFeedFEvent($aItem)
    {
        if (!phpfox::isModule('fevent'))
        {
            return false;
        }
        
        $this->getItemIdByFavoriteItemId($aItem);
        
        $aRow = $this->database()->select('e.event_id, e.module_id, e.item_id, e.title, f.time_stamp, e.image_path, e.server_id, e.total_like, e.total_comment, et.description_parsed, l.like_id AS is_liked')->from(Phpfox::getT('fevent'), 'e')->leftJoin(Phpfox::getT('fevent_text'), 'et', 'et.event_id = e.event_id')->join(phpfox::getT('foxfavorite'), 'f', 'f.item_id = e.event_id')->leftJoin(Phpfox::getT('like'), 'l', 'l.type_id = \'fevent\' AND l.item_id = e.event_id AND l.user_id = ' . Phpfox::getUserId())->where('e.event_id = ' . (int)$aItem['item_id'] . ' and f.type_id = "fevent"')->execute('getSlaveRow');

        if (!isset($aRow['event_id']))
        {
            return false;
        }

        if ((defined('PHPFOX_IS_PAGES_VIEW') && !Phpfox::getService('pages')->hasPerm(null, 'event.view_browse_events')) || (!defined('PHPFOX_IS_PAGES_VIEW') && $aRow['module_id'] == 'pages' && !Phpfox::getService('pages')->hasPerm($aRow['item_id'], 'event.view_browse_events')))
        {
            return false;
        }

        $aReturn = array(
            'feed_title' => $aRow['title'],
            'feed_info' => Phpfox::getPhrase('foxfavorite.favorited_an_event'),
            'feed_link' => Phpfox::permalink('fevent', $aRow['event_id'], $aRow['title']),
            'feed_content' => $aRow['description_parsed'],
            'feed_icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)),
            'time_stamp' => $aRow['time_stamp'],
            );

        if (!empty($aRow['image_path']))
        {
            $sImage = Phpfox::getLib('image.helper')->display(array(
                'server_id' => $aRow['server_id'],
                'path' => 'event.url_image',
                'file' => $aRow['image_path'],
                'suffix' => ''));

            $aReturn['feed_image_banner'] = $sImage;
        }

        return $aReturn;
    }

    public function getActivityFeedAdvancedmarketplace($aItem)
    {
        if (!phpfox::isModule('advancedmarketplace'))
        {
            return false;
        }
        
        $this->getItemIdByFavoriteItemId($aItem);
        
        $aRow = $this->database()->select('e.listing_id, e.title, f.time_stamp, e.image_path, e.server_id, e.total_like, e.total_comment, et.description_parsed, l.like_id AS is_liked')->from(Phpfox::getT('advancedmarketplace'), 'e')->leftJoin(Phpfox::getT('advancedmarketplace_text'), 'et', 'et.listing_id = e.listing_id')->join(phpfox::getT('foxfavorite'), 'f', 'f.item_id = e.listing_id')->leftJoin(Phpfox::getT('like'), 'l', 'l.type_id = \'advancedmarketplace\' AND l.item_id = e.listing_id AND l.user_id = ' . Phpfox::getUserId())->where('e.listing_id = ' . (int)$aItem['item_id'] . ' and f.type_id = "advancedmarketplace"')->execute('getSlaveRow');

        if (!isset($aRow['listing_id']))
        {
            return false;
        }

        $aReturn = array(
            'feed_title' => $aRow['title'],
            'feed_info' => Phpfox::getPhrase('foxfavorite.favorited_a_listing'),
            'feed_link' => Phpfox::permalink('advancedmarketplace.detail', $aRow['listing_id'], $aRow['title']),
            'feed_content' => $aRow['description_parsed'],
            'feed_icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)),
            'time_stamp' => $aRow['time_stamp'],
            );

        if (!empty($aRow['image_path']))
        {
            $aReturn['feed_image_banner'] = '<img src="' . Phpfox::getParam('core.url_pic') . 'advancedmarketplace/' . sprintf($aRow['image_path'], '') . '" />';
        }

        return $aReturn;
    }

    public function getActivityFeedChannelVideo($aItem, $aCallback = null)
    {
        if (!phpfox::isModule('videochannel'))
        {
            return false;
        }
        
        $this->getItemIdByFavoriteItemId($aItem);
        
        if ($aCallback === null)
        {
            $this->database()->select(Phpfox::getUserField('u', 'parent_') . ', ')->leftJoin(Phpfox::getT('user'), 'u', 'u.user_id = v.parent_user_id');
        }

        $aRow = $this->database()->select('v.video_id, v.module_id, v.item_id, v.title, f.time_stamp, v.total_comment, v.total_like, v.image_path, v.image_server_id, l.like_id AS is_liked, vt.text_parsed')->from(Phpfox::getT('channel_video'), 'v')->leftJoin(Phpfox::getT('like'), 'l', 'l.type_id = \'videochannel\' AND l.item_id = v.video_id AND l.user_id = ' . Phpfox::getUserId())->leftJoin(Phpfox::getT('video_text'), 'vt', 'vt.video_id = v.video_id')->leftjoin(phpfox::getT('foxfavorite'), 'f', 'f.item_id = v.video_id')->where('f.type_id = "videochannel" AND v.video_id = ' . (int)$aItem['item_id'])->execute('getSlaveRow');

        if (!isset($aRow['video_id']))
        {
            return false;
        }

        if ((defined('PHPFOX_IS_PAGES_VIEW') && !Phpfox::getService('pages')->hasPerm(null, 'videochannel.view_browse_videos')) || (!defined('PHPFOX_IS_PAGES_VIEW') && $aRow['module_id'] == 'pages' && !Phpfox::getService('pages')->hasPerm($aRow['item_id'], 'videochannel.view_browse_videos')))
        {
            return false;
        }

        $aReturn = array(
            'feed_title' => $aRow['title'],
            'feed_info' => Phpfox::getPhrase('foxfavorite.favorited_a_video'),
            'feed_link' => Phpfox::permalink('videochannel', $aRow['video_id'], $aRow['title']),
            'feed_content' => $aRow['text_parsed'],
            'feed_icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)),
            'time_stamp' => $aRow['time_stamp'],
            );

        if ($aRow['module_id'] == 'pages')
        {
            $aRow['parent_user_id'] = '';
            $aRow['parent_user_name'] = '';
        }

        if (empty($aRow['parent_user_id']))
        {
            $aReturn['feed_info'] = Phpfox::getPhrase('foxfavorite.favorited_a_video');
        }

        if ($aCallback === null)
        {
            if (!empty($aRow['parent_user_name']) && !defined('PHPFOX_IS_USER_PROFILE') && empty($_POST))
            {
                $aReturn['parent_user'] = Phpfox::getService('user')->getUserFields(true, $aRow, 'parent_');
            }

            if (!PHPFOX_IS_AJAX && defined('PHPFOX_IS_USER_PROFILE') && !empty($aRow['parent_user_name']) && $aRow['parent_user_id'] != Phpfox::getService('profile')->getProfileUserId())
            {
                $aReturn['feed_mini'] = true;
                $aReturn['feed_mini_content'] = Phpfox::getPhrase('feed.full_name_posted_a_href_link_a_video_a_on_a_href_profile_parent_full_name_a_s_a_href_profile_link_wall_a', array(
                    'full_name' => Phpfox::getService('user')->getFirstName($aItem['full_name']),
                    'link' => Phpfox::permalink('videochannel', $aRow['video_id'], $aRow['title']),
                    'profile' => Phpfox::getLib('url')->makeUrl($aRow['parent_user_name']),
                    'parent_full_name' => $aRow['parent_full_name'],
                    'profile_link' => Phpfox::getLib('url')->makeUrl($aRow['parent_user_name'])));
                $aReturn['feed_title'] = '';
                unset($aReturn['feed_status'], $aReturn['feed_image'], $aReturn['feed_content']);
            }
        }

        if (!PHPFOX_IS_AJAX && defined('PHPFOX_IS_USER_PROFILE') && !empty($aRow['parent_user_name']) && $aRow['parent_user_id'] != Phpfox::getService('profile')->getProfileUserId())
        {

        }
        else
        {
            if (!empty($aRow['image_path']))
            {
                $sImage = Phpfox::getLib('image.helper')->display(array(
                    'server_id' => $aRow['image_server_id'],
                    'path' => 'core.url_pic',
                    'file' => $aRow['image_path'],
                    'suffix' => ''));

                $aReturn['feed_image_banner'] = $sImage;
            }

            $aReturn['feed_image_onclick'] = '$Core.box(\'videochannel.play\', 700, \'id=' . $aRow['video_id'] . '&amp;feed_id=' . $aItem['feed_id'] . '&amp;popup=true\', \'GET\'); return false;';
        }

        return $aReturn;
    }

    public function getActivityFeedAdvancedPhoto($aItem, $aCallback = null)
    {
        if (!phpfox::isModule('advancedphoto'))
        {
            return false;
        }

        $this->getItemIdByFavoriteItemId($aItem);

        $aRow = $this->database()->select('photo.*, f.time_stamp, l.like_id AS is_liked, pi.description, pfeed.photo_id AS extra_photo_id, pa.album_id, pa.name')->from(phpfox::getT('photo'), 'photo')->join(Phpfox::getT('photo_info'), 'pi', 'pi.photo_id = photo.photo_id')->leftJoin(Phpfox::getT('foxfavorite'), 'f', 'f.item_id = photo.photo_id')->leftJoin(Phpfox::getT('like'), 'l', 'l.type_id = \'photo\' AND l.item_id = photo.photo_id AND l.user_id = ' . Phpfox::getUserId())->leftJoin(Phpfox::getT('photo_feed'), 'pfeed', 'pfeed.feed_id = ' . (int)$aItem['feed_id'])->leftJoin(Phpfox::getT('photo_album'), 'pa', 'pa.album_id = photo.album_id')->where('f.type_id = "advancedphoto" AND photo.photo_id = ' . (int)$aItem['item_id'])->execute('getSlaveRow');

        if (!isset($aRow['photo_id']))
        {
            return false;
        }

        if ((defined('PHPFOX_IS_PAGES_VIEW') && !Phpfox::getService('pages')->hasPerm(null, 'photo.view_browse_photos')) || (!defined('PHPFOX_IS_PAGES_VIEW') && $aRow['module_id'] == 'pages' && !Phpfox::getService('pages')->hasPerm($aRow['group_id'], 'photo.view_browse_photos')))
        {
            return false;
        }

        $bIsPhotoAlbum = false;
        
        if ($aRow['album_id'])
        {
            $bIsPhotoAlbum = true;
        }

        $sLink = Phpfox::permalink('advancedphoto', $aRow['photo_id'], $aRow['title']) . ($bIsPhotoAlbum ? 'albumid_' . $aRow['album_id'] : 'userid_' . $aRow['user_id']) . '/';
        $sFeedImageOnClick = '';

        if (($aRow['mature'] == 0 || (($aRow['mature'] == 1 || $aRow['mature'] == 2) && Phpfox::getUserId() && Phpfox::getUserParam('photo.photo_mature_age_limit') <= Phpfox::getUserBy('age'))) || $aRow['user_id'] == Phpfox::getUserId())
        {
            $sCustomCss = 'photo_holder_image';
            $sImage = Phpfox::getLib('image.helper')->display(array(
                'server_id' => $aRow['server_id'],
                'path' => 'photo.url_photo',
                'file' => Phpfox::getService('photo')->getPhotoUrl(array_merge($aRow, array('full_name' => $aItem['full_name']))),
                'suffix' => '',
                'class' => 'photo_holder'));
        }
        else
        {
            $sImage = Phpfox::getLib('image.helper')->display(array('theme' => 'misc/no_access.png'));
            $sFeedImageOnClick = ' onclick="tb_show(\'' . Phpfox::getPhrase('photo.warning') . '\', $.ajaxBox(\'advancedphoto.warning\', \'height=300&width=350&link=' . $sLink . '\')); return false;" ';
        }

        $aListPhotos = array();
        if ($aRow['extra_photo_id'] > 0)
        {
            $aPhotos = $this->database()->select('p.photo_id, p.album_id, p.user_id, p.title, p.server_id, p.destination, p.mature')->from(Phpfox::getT('photo_feed'), 'pfeed')->join(Phpfox::getT('photo'), 'p', 'p.photo_id = pfeed.photo_id')->where('pfeed.feed_id = ' . (int)$aItem['feed_id'])->limit(3)->order('p.time_stamp DESC')->execute('getSlaveRows');
            foreach ($aPhotos as $aPhoto)
            {
                if (($aPhoto['mature'] == 0 || (($aPhoto['mature'] == 1 || $aPhoto['mature'] == 2) && Phpfox::getUserId() && Phpfox::getUserParam('photo.photo_mature_age_limit') <= Phpfox::getUserBy('age'))) || $aPhoto['user_id'] == Phpfox::getUserId())
                {
                    $aListPhotos[] = '<a href="' . Phpfox::permalink('advancedphoto', $aPhoto['photo_id'], $aPhoto['title']) . ($bIsPhotoAlbum ? 'albumid_' . $aRow['album_id'] : 'userid_' . $aRow['user_id']) . '/" class="photo_holder_image" rel="' . $aPhoto['photo_id'] . '">' . Phpfox::getLib('image.helper')->display(array(
                        'server_id' => $aPhoto['server_id'],
                        'path' => 'photo.url_photo',
                        'file' => Phpfox::getService('photo')->getPhotoUrl(array_merge($aPhoto, array('full_name' => $aItem['full_name']))),
                        'suffix' => '_100',
                        'max_width' => 100,
                        'max_height' => 100,
                        'class' => 'photo_holder',
                        'userid' => isset($aItem['user_id']) ? $aItem['user_id'] : '')) . '</a>';
                }
                else
                {
                    $aListPhotos[] = '<a href="#" class="no_ajax_link" onclick="tb_show(\'' . Phpfox::getPhrase('photo.warning') . '\', $.ajaxBox(\'advancedphoto.warning\', \'height=300&width=350&link=' . Phpfox::permalink('advancedphoto', $aPhoto['photo_id'], $aPhoto['title']) . ($bIsPhotoAlbum ? 'albumid_' . $aRow['album_id'] : 'userid_' . $aRow['user_id']) . '/\')); return false;">' . $sImage . '</a>';
                }
            }

            $aListPhotos = array_merge($aListPhotos, array('<a href="' . Phpfox::permalink('advancedphoto', $aRow['photo_id'], $aRow['title']) . ($bIsPhotoAlbum ? 'albumid_' . $aRow['album_id'] : 'userid_' . $aRow['user_id']) . '/" ' . (empty($sFeedImageOnClick) ? ' class="photo_holder_image" rel="' . $aRow['photo_id'] . '" ' : $sFeedImageOnClick . ' class="no_ajax_link"') . '>' . $sImage . '</a>'));
        }

        $aReturn = array(
            'feed_title' => '',
            'feed_info' => Phpfox::getPhrase('foxfavorite.favorited_a_photo'),
            'feed_image' => (count($aListPhotos) ? $aListPhotos : $sImage),
            'feed_status' => $aRow['description'],
            'feed_link' => $sLink,
            'feed_icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)),
            'time_stamp' => $aRow['time_stamp'],
        );

        return $aReturn;
    }

    public function getActivityFeedDirectory($aItem)
    {
        if (!phpfox::isModule('directory'))
        {
            return false;
        }
        
        $this->getItemIdByFavoriteItemId($aItem);
        
        $aRow = $this->database()
            ->select('c.business_id, c.module_id, c.item_id, c.name as title, f.time_stamp, c.logo_path as image_path, c.server_id, c.total_like, c.total_comment, ct.description_parsed, l.like_id AS is_liked')
            ->from(Phpfox::getT('directory_business'), 'c')
            ->leftJoin(Phpfox::getT('directory_business_text'), 'ct', 'ct.business_id = c.business_id')
            ->join(Phpfox::getT('foxfavorite'), 'f', 'f.item_id = c.business_id')
            ->leftJoin(Phpfox::getT('like'), 'l', 'l.type_id = \'directory\' AND l.item_id = c.business_id AND l.user_id = ' . Phpfox::getUserId())
            ->where('c.business_id = ' . (int)$aItem['item_id'] . ' and f.type_id = "directory"')
            ->execute('getSlaveRow');
        if (!isset($aRow['business_id']))
        {
            return false;
        }

        $aReturn = array(
            'feed_title' => $aRow['title'],
            'feed_info' => Phpfox::getPhrase('foxfavorite.favorited_a_business'),
            'feed_link' => Phpfox::permalink('directory.detail', $aRow['business_id'], $aRow['title']),
            'feed_content' => $aRow['description_parsed'],
            'feed_icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)),
            'time_stamp' => $aRow['time_stamp'],
            );

        if (!empty($aRow['image_path']))
        {
            $sImage = Phpfox::getLib('image.helper')->display(array(
                    'server_id' => $aRow['server_id'],
                    'path' => 'core.url_pic',
                    'file' => $aRow['image_path'],
                    'yndirectory_overridenoimage' => true,
                    'suffix' => '',
                    'return_url' => true, 
                )
            );
            $aReturn['feed_image'] = '<img src="' . $sImage . '" style="max-width:100px; max-height:100px;" />';
        }

        return $aReturn;
    }    

    public function getActivityFeedAuction($aItem)
    {
        if (!phpfox::isModule('auction'))
        {
            return false;
        }
        
        $this->getItemIdByFavoriteItemId($aItem);
        
        $sWhere = '';
        $sWhere .= ' and e.product_status IN ( \'running\',\'approved\',\'bidden\',\'completed\') ';
        $aRow = $this->database()->select('u.user_id, e.product_id, e.module_id, e.item_id, e.product_id, e.name, e.product_creation_datetime as time_stamp, e.logo_path as image_path, e.server_id as image_server_id, e.total_like, e.total_comment, et.description_parsed as description_parsed, l.like_id AS is_liked')
            ->from(Phpfox::getT('ecommerce_product'), 'e')
            ->join(PHpfox::getT('user'),'u','u.user_id = e.user_id')
            ->leftJoin(Phpfox::getT('ecommerce_product_text'), 'et', 'et.product_id = e.product_id')
            ->leftJoin(Phpfox::getT('like'), 'l', 'l.type_id = \'auction\' AND l.item_id = e.product_id AND l.user_id = ' . Phpfox::getUserId())
            ->where('e.product_id = ' . (int) $aItem['item_id'] . $sWhere)
            ->execute('getSlaveRow');

        if (!isset($aRow['product_id']))
        {
            return false;
        }

        $aReturn = array(
            'feed_title' => $aRow['name'],
            'feed_info' => Phpfox::getPhrase('foxfavorite.favorited_a_product'),
            'feed_link' => Phpfox::permalink('auction.detail', $aRow['product_id'], $aRow['name']),
            'feed_content' => $aRow['description_parsed'],
            'feed_icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/auction.png', 'return_url' => true)),
            'time_stamp' => $aRow['time_stamp'],           
        );

        if (NULL != $aRow['image_path'])
        {
            $sImage = Phpfox::getLib('image.helper')->display(array(
                    'server_id' => $aRow['image_server_id'],
                    'path' => 'core.url_pic',
                    'file' => $aRow['image_path'],
                    'ynauction_overridenoimage' => true,
                    'suffix' => '',
                    'return_url' => true,             
                )
            );
            
            $aReturn['feed_image_banner'] = $sImage;
        }   

        return $aReturn;
    }   

    public function getActivityFeedCoupon($aItem)
    {
        if (!phpfox::isModule('coupon'))
        {
            return false;
        }
        
        $this->getItemIdByFavoriteItemId($aItem);
        
        $aRow = $this->database()->select('c.coupon_id, c.module_id, c.item_id, c.title, f.time_stamp, c.image_path, c.server_id, c.total_like, c.total_comment, ct.description_parsed, l.like_id AS is_liked')->from(Phpfox::getT('coupon'), 'c')->leftJoin(Phpfox::getT('coupon_text'), 'ct', 'ct.coupon_id = c.coupon_id')->join(Phpfox::getT('foxfavorite'), 'f', 'f.item_id = c.coupon_id')->leftJoin(Phpfox::getT('like'), 'l', 'l.type_id = \'coupon\' AND l.item_id = c.coupon_id AND l.user_id = ' . Phpfox::getUserId())->where('c.coupon_id = ' . (int)$aItem['item_id'] . ' and f.type_id = "coupon"')->execute('getSlaveRow');
        if (!isset($aRow['coupon_id']))
        {
            return false;
        }

        if ((defined('PHPFOX_IS_PAGES_VIEW') && !Phpfox::getService('pages')->hasPerm(null, 'coupon.view_browse_coupons')) || (!defined('PHPFOX_IS_PAGES_VIEW') && $aRow['module_id'] == 'pages' && !Phpfox::getService('pages')->hasPerm($aRow['item_id'], 'coupon.view_browse_coupons')))
        {
            return false;
        }

        $aReturn = array(
            'feed_title' => $aRow['title'],
            'feed_info' => Phpfox::getPhrase('foxfavorite.favorited_a_coupon'),
            'feed_link' => Phpfox::permalink('coupon.detail', $aRow['coupon_id'], $aRow['title']),
            'feed_content' => $aRow['description_parsed'],
            'feed_icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)),
            'time_stamp' => $aRow['time_stamp'],
            );

        if (!empty($aRow['image_path']))
        {
            $aReturn['feed_image'] = '<img src="' . Phpfox::getParam('core.url_pic') . sprintf($aRow['image_path'], '_100') . '" style="max-width:100px; max-height:100px;" />';
        }

        return $aReturn;
    }

    public function getActivityFeedContest($aItem)
    {
        if (!Phpfox::isModule('contest'))
        {
            return false;
        }
        
        $this->getItemIdByFavoriteItemId($aItem);
        
        if (Phpfox::isUser())
        {
            $this->database()->select('l.like_id AS is_liked, ')->leftJoin(Phpfox::getT('like'), 'l', 'l.type_id = \'contest\' AND l.item_id = c.contest_id AND l.user_id = ' . Phpfox::getUserId());
        }

        $aRow = $this->database()->select('c.*, f.time_stamp')
        ->from(Phpfox::getT('contest'), 'c')
        ->join(phpfox::getT('foxfavorite'), 'f', 'f.item_id = c.contest_id')
        ->where('f.item_id = ' . (int)$aItem['item_id'] . ' AND f.type_id = "contest"')
        ->execute('getSlaveRow');
        
        if (empty($aRow))
        {
            return false;
        }
        
        $aReturn = array(
            'feed_title' => $aRow['contest_name'],
            'feed_info' => Phpfox::getPhrase('foxfavorite.favorited_a_contest'),
            'feed_link' => Phpfox::permalink('contest', $aRow['contest_id'], $aRow['contest_name']),
            'feed_content' => $aRow['short_description_parsed'],
            'feed_icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)),
            'time_stamp' => $aRow['time_stamp']);
        
        $aReturn['feed_image_banner'] = Phpfox::getLib('image.helper')->display(array(
            'server_id' => $aRow['server_id'],
            'path' => 'core.url_pic',
            'file' => 'contest/'.$aRow['image_path'],
            'suffix' => ''));
        
        return $aReturn;
    }

    public function getActivityFeedResume($aItem)
    {
        if (!Phpfox::isModule('resume'))
        {
            return false;
        }
        
        $this->getItemIdByFavoriteItemId($aItem);
        
        if (Phpfox::isUser())
        {
            $this->database()->select('l.like_id AS is_liked, ')->leftJoin(Phpfox::getT('like'), 'l', 'l.type_id = \'resume\' AND l.item_id = rbi.resume_id AND l.user_id = ' . Phpfox::getUserId());
        }

        $aRow = $this->database()->select('rbi.*, rbi.server_id as item_server_id, f.time_stamp')
        ->from(Phpfox::getT('resume_basicinfo'), 'rbi')
        ->join(phpfox::getT('foxfavorite'), 'f', 'f.item_id = rbi.resume_id')
        ->where('f.item_id = ' . (int)$aItem['item_id'] . ' AND f.type_id = "resume"')
        ->execute('getSlaveRow');
        
        if (empty($aRow))
        {
            return false;
        }
        
        $aReturn = array(
            'feed_title' => $aRow['headline'],
            'feed_info' => Phpfox::getPhrase('foxfavorite.favorited_a_resume'),
            'feed_link' => Phpfox::permalink('resume.view', $aRow['resume_id'], $aRow['headline']),
            'feed_content' => '',
            'feed_icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)),
            'time_stamp' => $aRow['time_stamp']);
        
        $aReturn['feed_image_banner'] = Phpfox::getLib('image.helper')->display(array(
            'server_id' => $aRow['item_server_id'],
            'path' => 'core.url_pic',
            'file' => 'resume/'.$aRow['image_path'],
            'suffix' => ''));
        
        return $aReturn;
    }

    public function getActivityFeedJobposting($aItem)
    {
        if (!Phpfox::isModule('jobposting'))
        {
            return false;
        }
        
        $this->getItemIdByFavoriteItemId($aItem);
        
        if (Phpfox::isUser())
        {
            $this->database()->select('l.like_id AS is_liked, ')->leftJoin(Phpfox::getT('like'), 'l', 'l.type_id = \'jobposting_job\' AND l.item_id = j.job_id AND l.user_id = ' . Phpfox::getUserId());
        }

        $aRow = $this->database()->select('j.*, jt.description_parsed, c.image_path, c.server_id as item_server_id, f.time_stamp')
        ->from(Phpfox::getT('jobposting_job'), 'j')
        ->join(Phpfox::getT('jobposting_job_text'), 'jt', 'jt.job_id = j.job_id')
        ->join(Phpfox::getT('jobposting_company'), 'c', 'c.company_id = j.company_id')
        ->join(phpfox::getT('foxfavorite'), 'f', 'f.item_id = j.job_id')
        ->where('f.item_id = ' . (int)$aItem['item_id'] . ' AND f.type_id = "jobposting"')
        ->execute('getSlaveRow');
        
        if (empty($aRow))
        {
            return false;
        }
        
        $aReturn = array(
            'feed_title' => $aRow['title'],
            'feed_info' => Phpfox::getPhrase('foxfavorite.favorited_a_job'),
            'feed_link' => Phpfox::permalink('jobposting', $aRow['job_id'], $aRow['title']),
            'feed_content' => $aRow['description_parsed'],
            'feed_icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)),
            'time_stamp' => $aRow['time_stamp']);
        
        $aReturn['feed_image_banner'] = Phpfox::getLib('image.helper')->display(array(
            'server_id' => $aRow['item_server_id'],
            'path' => 'core.url_pic',
            'file' => 'jobposting/'.$aRow['image_path'],
            'suffix' => ''));
        
        return $aReturn;
    }

    public function getActivityFeedFoxfeedspro($aItem)
    {
        if (!Phpfox::isModule('foxfeedspro'))
        {
            return false;
        }
        
        $this->getItemIdByFavoriteItemId($aItem);
        
        if (Phpfox::isUser())
        {
            $this->database()->select('l.like_id AS is_liked, ')->leftJoin(Phpfox::getT('like'), 'l', 'l.type_id = \'foxfeedspro\' AND l.item_id = ni.item_id AND l.user_id = ' . Phpfox::getUserId());
        }

        $aRow = $this->database()->select('ni.*, f.time_stamp')
        ->from(Phpfox::getT('ynnews_items'), 'ni')
        ->join(phpfox::getT('foxfavorite'), 'f', 'f.item_id = ni.item_id')
        ->where('f.item_id = ' . (int)$aItem['item_id'] . ' AND f.type_id = "foxfeedspro"')
        ->execute('getSlaveRow');
        
        if (empty($aRow))
        {
            return false;
        }
        
        $aReturn = array(
            'feed_title' => $aRow['item_title'],
            'feed_info' => Phpfox::getPhrase('foxfavorite.favorited_a_news'),
            'feed_link' => Phpfox::permalink('news.newsdetails', 'item_'.$aRow['item_id'], $aRow['item_title']),
            'feed_content' => $aRow['item_description_parse'],
            'feed_icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)),
            'time_stamp' => $aRow['time_stamp']);
        
        $aReturn['feed_image_banner'] = Phpfox::getLib('image.helper')->display(array(
            'server_id' => $aRow['server_id'],
            'path' => 'core.url_pic',
            'file' => str_replace(Phpfox::getParam('core.url_pic'), '', $aRow['item_image']),
            'suffix' => ''));
        
        return $aReturn;
    }

    public function getActivityFeedPetition($aItem)
    {
        if (!Phpfox::isModule('petition'))
        {
            return false;
        }
        
        $this->getItemIdByFavoriteItemId($aItem);
        
        if (Phpfox::isUser())
        {
            $this->database()->select('l.like_id AS is_liked, ')->leftJoin(Phpfox::getT('like'), 'l', 'l.type_id = \'petition\' AND l.item_id = p.item_id AND l.user_id = ' . Phpfox::getUserId());
        }

        $aRow = $this->database()->select('p.*, pt.short_description_parsed, f.time_stamp')
        ->from(Phpfox::getT('petition'), 'p')
		->join(Phpfox::getT('petition_text'), 'pt', 'pt.petition_id = p.petition_id')
        ->join(phpfox::getT('foxfavorite'), 'f', 'f.item_id = p.petition_id')
        ->where('f.item_id = ' . (int)$aItem['item_id'] . ' AND f.type_id = "petition"')
        ->execute('getSlaveRow');
        
        if (empty($aRow))
        {
            return false;
        }
        
        $aReturn = array(
            'feed_title' => $aRow['title'],
            'feed_info' => Phpfox::getPhrase('foxfavorite.favorited_a_petition'),
            'feed_link' => Phpfox::permalink('petition', $aRow['petition_id'], $aRow['title']),
            'feed_content' => $aRow['short_description_parsed'],
            'feed_icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)),
            'time_stamp' => $aRow['time_stamp']);
        
        $aReturn['feed_image_banner'] = Phpfox::getLib('image.helper')->display(array(
            'server_id' => $aRow['server_id'],
            'path' => 'core.url_pic',
            'file' => $aRow['image_path'],
            'suffix' => ''));
        
        return $aReturn;
    }

    public function getActivityFeedMusicsharing($aItem)
    {
        if (!Phpfox::isModule('musicsharing'))
        {
            return false;
        }
        
        $this->getItemIdByFavoriteItemId($aItem);
        
        if (Phpfox::isUser())
        {
            $this->database()->select('l.like_id AS is_liked, ')->leftJoin(Phpfox::getT('like'), 'l', 'l.type_id = \'musicsharing\' AND l.item_id = s.song_id AND l.user_id = ' . Phpfox::getUserId());
        }

        $aRow = $this->database()->select('s.*, a.user_id, a.album_image,a.server_id, f.time_stamp')
        ->from(Phpfox::getT('m2bmusic_album_song'), 's')
        ->join(Phpfox::getT('m2bmusic_album'), 'a', 'a.album_id = s.album_id')
        ->join(phpfox::getT('foxfavorite'), 'f', 'f.item_id = s.song_id')
        ->where('f.item_id = ' . (int)$aItem['item_id'] . ' AND f.type_id = "musicsharing"')
        ->execute('getSlaveRow');
        
        if (empty($aRow))
        {
            return false;
        }
        $sLink = Phpfox::permalink('musicsharing.listen', 'music_'.$aRow['song_id']);
        $aReturn = array(
            'feed_title' => $aRow['title'],
            'feed_info' => Phpfox::getPhrase('foxfavorite.favorited_a_song'),
            'feed_link' => Phpfox::permalink('musicsharing.listen', 'music_'.$aRow['song_id']),
            'feed_content' => ($aRow['play_count'] > 1) ? $aRow['play_count'].' '.Phpfox::getPhrase('foxfavorite.plays') : $aRow['play_count'].' '.Phpfox::getPhrase('foxfavorite.play'),
            'feed_icon' => Phpfox::getLib('image.helper')->display(array('theme' => 'module/favorite.png', 'return_url' => true)),
            'time_stamp' => $aRow['time_stamp']
            );

        $aReturn['feed_image_banner'] = '<a href= "'.$sLink.'">'.phpFox::getLib('image.helper')->display(array('theme' => 'misc/play_button.png')).'</a>';
        if (!empty($aRow['album_image']))
        {
            $sImage = Phpfox::getLib('image.helper')->display(array(
                                                                  'server_id' => $aRow['server_id'],
                                                                  'path' => 'core.url_pic',
                                                                  'file' => 'musicsharing/'.$aRow['album_image'],
                                                                  'suffix' => '',
                                                                  'return_url' => true,
                                                              )
            );
            $aReturn['feed_image_banner'] = '<a href= "'.$sLink.'"><img src="' . $sImage . '" style="max-width:200px; max-height:200px;" /></a>';

        }
        return $aReturn;
    }

    public function updateCounterList()
    {
        $aList = array();

        $aList[] = array('name' => 'User Favorite Count', 'id' => 'foxfavorite-total');

        return $aList;
    }

    public function updateCounter($iId, $iPage, $iPageLimit)
    {
        (($sPlugin = Phpfox_Plugin::get('foxfavorite.component_service_callback_updatecounter__start')) ? eval($sPlugin) : false);

        if ($iId == 'foxfavorite-total')
        {
            $iCnt = $this->database()->select('COUNT(*)')->from(Phpfox::getT('user'))->execute('getSlaveField');

            $aRows = $this->database()->select('u.user_id, u.user_name, u.full_name, COUNT(b.favorite_id) AS total_items')->from(Phpfox::getT('user'), 'u')->leftJoin(Phpfox::getT('foxfavorite'), 'b', 'b.user_id = u.user_id')->limit($iPage, $iPageLimit, $iCnt)->group('u.user_id')->execute('getSlaveRows');

            foreach ($aRows as $aRow)
            {
                $this->database()->update(Phpfox::getT('user_field'), array('total_foxfavorite' => $aRow['total_items']), 'user_id = ' . $aRow['user_id']);
            }
        }

        return $iCnt;
    }

    public function getItemIdByFavoriteItemId(&$aItem)
    {
        $iFavoriteId = phpfox::getLib('database')->select('item_id')->from(phpfox::getT('foxfavorite'))->where('favorite_id = ' . $aItem['item_id'])->execute('getField');
        $aItem['item_id'] = $iFavoriteId;

    }

    public function getNotificationSettings()
    {
        (($sPlugin = Phpfox_Plugin::get('foxfavorite.component_service_callback_getnotificationsettings__start')) ? eval($sPlugin) : false);
        return array(
            'foxfavorite.add_new_favorites' => array(
                'phrase' => Phpfox::getPhrase('foxfavorite.follow_members_whose_profile_whose_i_favorited'), 
                'default' => 1
            ), 
            'foxfavorite.user_favorited_my_item' => array(
                'phrase' => Phpfox::getPhrase('foxfavorite.notify_me_when_users_favorited_my_items'), 
                'default' => 1
            )
        );
    }
    /**
     * If a call is made to an unknown method attempt to connect
     * it to a specific plug-in with the same name thus allowing 
     * plug-in developers the ability to extend classes.
     *
     * @param string $sMethod is the name of the method
     * @param array $aArguments is the array of arguments of being passed
     */
    public function __call($sMethod, $aArguments)
    {
        /**
         * Check if such a plug-in exists and if it does call it.
         */
        if ($sPlugin = Phpfox_Plugin::get('favorite.service_callback__call'))
        {
            return eval($sPlugin);
        }

        /**
         * No method or plug-in found we must throw a error.
         */
        Phpfox_Error::trigger('Call to undefined method ' . __class__ . '::' . $sMethod . '()', E_USER_ERROR);
    }
}

?>
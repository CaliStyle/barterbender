<?php

// Prevent Like button on feeds from phpFox 3.7.0
/*
foreach ($aRows as $k => $aRow)
{
    if (strpos($aRow['like_type_id'], "foxfavorite_") !== false)
    {
        unset($aRows[$k]['like_type_id']);
    }
}
 * 
 */

?>
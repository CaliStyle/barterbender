<?php

require_once '../server.php';

require_once APP_PATH. '/config/linkedin.php';
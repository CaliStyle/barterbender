<?php
$aPluginFiles[] = 'PF.Base/module/socialad/include/plugin/ad.component_block_display_process__start.php';
$aPluginFiles[] = 'PF.Base/module/socialad/include/plugin/core.template_block_template_menu_1.php';
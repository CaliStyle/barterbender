{module name='socialad.campaign.campaign-filter'}
<div id="js_ynsa_campaign_list">
{module name='socialad.campaign.campaign-list'}
</div>


<?php
if(Phpfox::isModule('socialad')){
	echo "
	<style type=\"text/css\">
		.activity_feed_content_image{
			float: none;
		}
	</style>";
}



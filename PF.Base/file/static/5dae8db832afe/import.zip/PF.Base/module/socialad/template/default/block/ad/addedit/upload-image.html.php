
<div id="js_ynsa_ad_upload_image_holder_frame" class="ynsaImageIframeHolder">
	<div id="js_upload_image_holder" class="ajax_link_reset form-group">
		<form method="post" action="#" target="upload_ad_iframe" enctype="multipart/form-data" id="js_ynsa_add_form_upload_image_form" >
            {module name='core.upload-form' type='socialad'}
            <div><input type="hidden" name="ad_size" value="728x90" id="js_upload_ad_size" /></div>
		</form>
	</div>
	<iframe framewidth="400" frameheight="200" name="upload_ad_iframe" id="upload_ad_iframe" style="display:none;"></iframe>
</div>

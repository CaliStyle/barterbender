{module name='socialad.sub-menu'}

{module name='socialad.campaign.campaign-filter'}
<div id="js_ynsa_campaign_list" class="ynsaCampaignList"> 
{module name='socialad.campaign.campaign-list'}
</div>


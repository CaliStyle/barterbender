
<span class="ynsaGlossaryTip  {$sExtraClass}" style="padding: 5px 10px;">
	<a href="#" onclick="return false;" role="button">
		<sup>?</sup>
	</a>
	<span class="tip right">
		<span class="tipTitle">{$sTooltipTitle}</span>
		<span class="tipBody">{$sTooltipDescription}</span>
		<span class="tipArrow"></span>
	</span>
</span>

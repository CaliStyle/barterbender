
{foreach from=$aSaReminders item=sReminder} 
<div class="public_message ynsaDisplayVisible"> {$sReminder} </div>
{/foreach}

<?php 

defined('PHPFOX') or exit('NO DICE!'); 

?>
<div class="clear"></div>
{if ( $type == 'web' && Phpfox::isModule('ynchat')) }
	<link id="ynchat_link_css" type="text/css" href="{$sSiteLink}ynchat/css.php?v={php} echo time(); {/php}" rel="stylesheet" charset="utf-8">
	<script id="ynchat_script_js" type="text/javascript" src="{$sSiteLink}ynchat/js.php?v={php} echo time(); {/php}" charset="utf-8"></script>
{/if}


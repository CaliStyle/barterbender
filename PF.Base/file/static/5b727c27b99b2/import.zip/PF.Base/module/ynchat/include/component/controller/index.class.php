<?php
/**
 * [PHPFOX_HEADER]
 */

defined('PHPFOX') or exit('NO DICE!');

class Ynchat_Component_Controller_Index extends Phpfox_Component
{
	public function process()
	{		
	}
}
?>
<?php
$aPluginFiles[] = 'PF.Base/module/fevent/include/plugin/fevent.component_controller_index_clean.php';
$aPluginFiles[] = 'PF.Base/module/fevent/include/plugin/fevent.component_controller_pagecalendar_clean.php';
$aPluginFiles[] = 'PF.Base/module/fevent/include/plugin/groups.component_controller_view_clean.php';
$aPluginFiles[] = 'PF.Base/module/fevent/include/plugin/pages.component_controller_view_clean.php';

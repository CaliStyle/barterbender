<?php
/**
 * [PHPFOX_HEADER]
 */

defined('PHPFOX') or exit('NO DICE!');
/**
 * 
 * 
 * @copyright       [YOUNET_COPYRIGHT]
 * @author          YouNet Company
 * @package         YouNet_Event
 */
?>
<div class="sub_section_menu">
	<ul class="action" name="" id="">
		<li><a href="{$sURL}" >{_p var='fevent.m_mypagesevents'}</a></li>
	</ul>
</div>

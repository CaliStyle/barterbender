<?php
defined('PHPFOX') or exit('NO DICE!');

function profile_completeness_install402()
{
    $oDatabase = db();
}

profile_completeness_install402();

<?php

if(Phpfox::isModule('foxfeedspro')){
	if(isset($sType) && 'foxfeedspro' == $sType
		&& isset($iParentUserId) && (int)$iParentUserId > 0
		&& isset($iParentUserId) && (int)$iParentUserId > 0
		){
		$this->_bIsNewLoop = false;
	}
}

?> 

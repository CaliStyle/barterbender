<?php
/**
 * [PHPFOX_HEADER]
 */

defined('PHPFOX') or exit('NO DICE!');

/**
 *
 * @copyright      YouNet Company
 * @author         TienNPL
 * @package        Module_FoxFeedsPro
 * @version        3.02
 *
 */
?>
<!-- News Popup Content Space -->
<iframe scrolling="auto" src="{$aNews.item_url_detail}" width="100%" height="96%" style="border:none;background: url({$sCorePath}/theme/frontend/default/style/default/image/misc/loading_animation.gif) no-repeat scroll center;">
</iframe>
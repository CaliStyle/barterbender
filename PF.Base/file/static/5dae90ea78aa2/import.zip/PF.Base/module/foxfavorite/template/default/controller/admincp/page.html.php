<div class="panel panel-default">
    <div class="panel-heading">
        <div class="panel-title">
            {phrase var='foxfavorite.page_migration'}
        </div>
    </div>
    <div class="panel-body">
         {phrase var='foxfavorite.migration_data_from_pagesfavorite_to_foxfavorite'}
    </div>
    <div class="panel-footer">
        <input class="btn btn-primary" type="submit" value="{phrase var='foxfavorite.confirm'}" onclick="window.location.href='{$sUrl}'"/>
    </div>
</div>
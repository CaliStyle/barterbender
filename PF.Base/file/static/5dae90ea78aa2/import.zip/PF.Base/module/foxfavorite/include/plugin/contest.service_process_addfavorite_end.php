<?php

Phpfox::getService('foxfavorite.process')->add('contest', $iContestId);

?>
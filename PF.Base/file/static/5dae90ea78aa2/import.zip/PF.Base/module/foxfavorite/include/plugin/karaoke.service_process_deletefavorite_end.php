<?php

Phpfox::getService('foxfavorite.process')->UnFavorite('karaoke', $iId);

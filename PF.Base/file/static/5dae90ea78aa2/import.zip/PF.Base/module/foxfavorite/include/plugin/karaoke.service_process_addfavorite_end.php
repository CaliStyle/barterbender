<?php

Phpfox::getService('foxfavorite.process')->add('karaoke', $iId);

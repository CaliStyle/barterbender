<?php

Phpfox::getService('foxfavorite.process')->add('resume', $iItemId);

?>
<?php

Phpfox::getService('foxfavorite.process')->add('coupon', $iItemId);

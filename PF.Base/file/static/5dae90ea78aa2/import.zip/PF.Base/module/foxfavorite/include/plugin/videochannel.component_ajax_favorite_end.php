<?php

Phpfox::getService('foxfavorite.process')->add('videochannel', $iVideoId);

<?php

Phpfox::getService('foxfavorite.process')->add('foxfeedspro', $iNewsId);

?>
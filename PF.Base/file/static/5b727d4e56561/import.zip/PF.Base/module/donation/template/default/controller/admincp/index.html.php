<div class="panel panel-default">
    <div class="panel-heading">
        <div class="panel-title">
            {phrase var='donation.donation_setting'}
        </div>
    </div>
    <div class="panel-body">
        {template file='donation.block.admincp.config'}

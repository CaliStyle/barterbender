<div class="yc_onwer">
	{img path='core.url_pic' file="user/".$aItem.user_image suffix='_50_square' max_width=50 max_height='50' class='js_mp_fix_width'}
	<a href="{url link=''}{$aItem.user_name}/"> {$aItem.full_name} </a>
</div>
<div class="clear"></div>
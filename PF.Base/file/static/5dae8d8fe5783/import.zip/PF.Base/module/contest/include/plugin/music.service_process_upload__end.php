<?php

Phpfox::getService('contest.contest')->handlerAfterAddingEntry('music', $iId);

?>
<?php
	Phpfox::getService('contest.global')->setItemId($iId);
?>
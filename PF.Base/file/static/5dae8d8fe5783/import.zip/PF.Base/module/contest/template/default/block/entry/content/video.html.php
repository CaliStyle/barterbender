<div class="ycvideocontainer">
   {$aVideoEntry.embed_code}
</div>
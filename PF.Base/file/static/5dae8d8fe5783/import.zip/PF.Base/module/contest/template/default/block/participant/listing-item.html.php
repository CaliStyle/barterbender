<div class="participant-item">
	{img user=$aItem suffix='_50_square' max_width=50 max_height=50}
</div>
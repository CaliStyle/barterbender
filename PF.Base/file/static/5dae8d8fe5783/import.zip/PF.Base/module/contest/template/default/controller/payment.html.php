<div class="ync_box_payment">
	<h3>{phrase var='contest.payment_methods'}</h3>
	{module name='api.gateway.form'}			
</div>
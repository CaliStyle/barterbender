<?php

defined('PHPFOX') or exit('NO DICE!');

class Ecommerce_Service_Invoice_Process extends Phpfox_Service {

    

}

?>
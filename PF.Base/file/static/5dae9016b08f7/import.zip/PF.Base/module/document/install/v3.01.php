<?php

defined('PHPFOX') or exit('NO DICE!');

function ynd_install301()
{
    // Do nothing
}

ynd_install301();

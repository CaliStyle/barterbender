<?php

$aBundleScripts[] = [
    'documentdetail.css' => 'module__document',
    'tipTip.css' => 'module__document',
    'admin.js' => 'module__document',
    'document.js' => 'module__document',
    'edit.js' => 'module__document',
    'jquery.tipTip.js' => 'module__document',
    'scribd_api.js' => 'module__document',
    'view.js' => 'module__document',
    'autoload.js' => 'module__document',
    'autoload.css' => 'module__document',
];
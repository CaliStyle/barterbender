<?php if (Phpfox::isModule('suggestion') && Phpfox::isUser()){?>
<?php }/*end check module; does not have element id to get username*/?>
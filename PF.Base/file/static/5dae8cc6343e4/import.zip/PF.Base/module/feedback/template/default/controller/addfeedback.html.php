<?php
/*
 * @copyright        [YouNet_COPYRIGHT]
 * @author           YouNet Company
 * @package          Module_FeedBack
 * @version          2.01
 *
 */
?>
{literal}
<style tyep="text/css">
.table_left_addfeedback
    {
        float:left;
    }
    
#formaddfeed h3 {
    margin:0 0 10px;
}
</style>
{/literal}
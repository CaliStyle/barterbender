<module>
	<data>
		<module_id>feedback</module_id>
		<product_id>younet_feedback4</product_id>
		<is_core>0</is_core>
		<is_active>1</is_active>
		<is_menu>0</is_menu>
		<menu />
		<phrase_var_name>module_feedback</phrase_var_name>
		<writable />
	</data>	
</module>
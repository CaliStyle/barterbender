<?php

$aBundleScripts[] = [
    'autoload.js' => 'module__feedback',
    'fileprogress.js' => 'module__feedback',
    'handlers.js' => 'module__feedback',
    'swfupload.js' => 'module__feedback',
    'swfupload.queue.js' => 'module__feedback',
    'jquery.colourPicker.js' => 'module__feedback',
    'jquery.lightbox-0.5.pack.js' => 'module__feedback',
    'jquery.swfupload.js' => 'module__feedback',
    'autoload.css' => 'module__feedback',
    'backend.css' => 'module__feedback',
];
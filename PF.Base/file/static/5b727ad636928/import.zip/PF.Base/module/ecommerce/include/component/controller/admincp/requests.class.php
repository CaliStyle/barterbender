<?php

defined('PHPFOX') or exit('NO DICE!');

class Ecommerce_Component_Controller_Admincp_Requests extends Phpfox_Component {

    public function process()
    {

        Phpfox::isUser(true);
        $sModule = "admincp.ecommerce.requests";
        $this->template()
                ->setTitle(_p('manage_requests'))
                ->setBreadCrumb(_p("Apps"), $this->url()->makeUrl('admincp.apps'))
                ->setBreadCrumb(_p('module_ecommerce'), $this->url()->makeUrl('admincp.app').'?id=__module_ecommerce')
                ->setBreadcrumb(_p('manage_requests'), $this->url()->makeUrl($sModule));

        // Page Number & Limit Per Page
        $iPage = $this->request()->getInt('page');

        // Variables
        $aConds = array();
        
        // Search Filter
        $oSearch = Phpfox::getLib('search')->set(array(
                'type'   => 'request',
                'search' => 'search',
        ));

        $aForms['requester_name']    = $oSearch->get('requester_name'); 
		$aForms['request_status']      = $oSearch->get('request_status');  
        $aForms['submit']           = $oSearch->get('submit');
		$aForms['reset'] 			= $this->request()->get('reset');

		if($aForms['reset'])
		{
			$this->url()->send('admincp.ecommerce.requests');
		}
		
        if($aForms['requester_name'])
        {
            $aConds[] = 'AND u.full_name LIKE "%' . Phpfox::getLib('parse.input')->clean($aForms['requester_name']) . '%"';
        }
		
        if($aForms['request_status'])
        {
        	if($aForms['request_status'] != 'all')
        	{
            	$aConds[] = 'AND ecmr.creditmoneyrequest_status = "' . $aForms['request_status'] . '"';
			}	
        }

        $formatDatePicker = str_split(Phpfox::getParam('core.date_field_order'));

        $aFormatIntial = array();
        foreach ($formatDatePicker as $key => $value) {
       
            if($formatDatePicker[$key] != 'Y'){
                $formatIntial = strtolower($formatDatePicker[$key]);
            }
            else{
                $formatIntial = $formatDatePicker[$key];
            }
       
            $aFormatIntial[] = $formatIntial;

            $formatDatePicker[$key] .= $formatDatePicker[$key];
            $formatDatePicker[$key] = strtolower($formatDatePicker[$key]);                
        }

        $sFormatDatePicker = implode("/", $formatDatePicker);
        $sSearchFromDate  = $oSearch->get('fromdate');
        $sSearchToDate  = $oSearch->get('todate');
        $sFormatIntial = implode("/", $aFormatIntial);
        $sFromDate = Phpfox::getTime($sFormatIntial, PHPFOX_TIME, false) ;
        $sToDate = Phpfox::getTime($sFormatIntial, PHPFOX_TIME + 24 * 60 * 60, false) ;

        if(!empty($sSearchFromDate) && !empty($sSearchToDate)){

            $aSearchFromDate = explode("/", $sSearchFromDate);
            $aSearchToDate = explode("/", $sSearchToDate);
            
            $aFromDate = array();
            $aToDate = array();

            if(!empty($aFormatIntial)){
                foreach ($aFormatIntial as $key => $aItem) {
                    $aFromDate[$aItem] = $aSearchFromDate[$key];
                    $aToDate[$aItem] = $aSearchToDate[$key];
                }
            }

            if (count($aFromDate) && count($aToDate))
            {
                    $iStartTime = Phpfox::getLib('date')->mktime(0, 0, 0, $aFromDate['m'], $aFromDate['d'], $aFromDate['Y']);
                    $iEndTime = Phpfox::getLib('date')->mktime(23, 59, 59, $aToDate['m'], $aToDate['d'], $aToDate['Y']);
                    if ($iStartTime > $iEndTime)
                    {
                            $iTemp = $iStartTime;
                            $iStartTime = $iEndTime;
                            $iEndTime = $iTemp;
                    }
                    $aConds[] = 'AND ecmr.creditmoneyrequest_creation_datetime > ' . $iStartTime . ' AND ecmr.creditmoneyrequest_creation_datetime < ' . $iEndTime;
            }

            $sFromDate = !empty($iStartTime) ? Phpfox::getTime($sFormatIntial, $iStartTime, false) : Phpfox::getTime($sFormatIntial,PHPFOX_TIME,false);
            $sToDate = !empty($iEndTime) ? Phpfox::getTime($sFormatIntial, $iEndTime, false) : Phpfox::getTime($sFormatIntial,PHPFOX_TIME,false);
            
        }
        
        /*sort table*/
        if($this->request()->get('sortfield') !='' ){
            $sSortField = $this->request()->get('sortfield'); 
            Phpfox::getLib('session')->set('ynecommerce_requests_sortfield',$sSortField);  
        }
        $sSortField = Phpfox::getLib('session')->get('ynecommerce_requests_sortfield');
        if(empty($sSortField)){
            $sSortField = ($this->request()->get('sortfield') !='' )?$this->request()->get('sortfield'):'time'; 
            Phpfox::getLib('session')->set('ynecommerce_requests_sortfield',$sSortField);  
        }

        if($this->request()->get('sorttype') !='' ){
            $sSortType = $this->request()->get('sorttype'); 
            Phpfox::getLib('session')->set('ynecommerce_requests_sorttype',$sSortType);  
        }
        $sSortType = Phpfox::getLib('session')->get('ynecommerce_requests_sorttype');
        if(empty($sSortType)){
            $sSortType = ($this->request()->get('sorttype') !='' )?$this->request()->get('sorttype'):'asc'; 
            Phpfox::getLib('session')->set('ynecommerce_requests_sorttype',$sSortType);  
        }

        $sSortFieldDB = 'ecmr.creditmoneyrequest_id';
        switch ($sSortField) {
			case 'request_date':
				$sSortFieldDB = 'ecmr.creditmoneyrequest_creation_datetime';
                break;
			case 'amount':
				$sSortFieldDB = 'ecmr.creditmoneyrequest_amount';
                break;
			case 'status':
				$sSortFieldDB = 'ecmr.creditmoneyrequest_status';
                break;
			case 'requester':
				$sSortFieldDB = 'u.full_name';
                break;	
			case 'response_date':
				$sSortFieldDB = 'ecmr.creditmoneyrequest_modification_datetime';
                break;	
            default:
                break;
        }
        $aSort = array('field' => $sSortFieldDB,'type' => $sSortType);
        $sSort = implode(" ", $aSort);

        $iLimit = 10;
        

        list($iCnt, $aRequestRows) = Phpfox::getService('ecommerce.request')->getRequest($aConds,$sSort, $oSearch->getPage(), $iLimit);
        
        $sCustomBaseLink  = Phpfox::getLib('url')->makeUrl($sModule); 
        Phpfox::getLib('pager')->set(array('page' => $iPage, 'size' => $iLimit, 'count' => $oSearch->getSearchTotal($iCnt)));

        $this->template()
                ->setHeader('cache', array(
                    'ynecommerce.js' => 'module_ecommerce'          
                ))
                ->assign(array(
                    'aRequestRows' => $aRequestRows, 
                    'sCustomBaseLink' => $sCustomBaseLink,
                    'aForms'     => $aForms,
                    'iTotalAmount'     => $iCnt,
                    'sFromDate' => $sFromDate,
                    'sToDate' => $sToDate,
                    'sFormatDatePicker' => $sFormatDatePicker,
                    'sModule' => $sModule,
                ));


    }

    /**
     * This function is used to add plugin. Do not delete.
     */
    public function clean()
    {
        (($sPlugin = Phpfox_Plugin::get('ynecommerce.component_controller_admincp_transactions_clean')) ? eval($sPlugin) : false);
    }

}

?>
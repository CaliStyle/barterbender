<?php 
/**
 *
 * @copyright		[YouNetCo]
 * @author  		MinhNTK
 */

defined('PHPFOX') or exit('NO DICE!'); 

?>
this is index page 
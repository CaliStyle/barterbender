# Material Template

## App Info

- `Theme name`: Material
- `Version`: 4.7.8
- `Link on Store`: https://store.phpfox.com/product/2004/material-template
- `Demo site`: https://v4.phpfox.com
- `Owner`: phpFox

## Installation Guide

Please follow below steps to install the app:

1. Install the **Material** theme from the store.

2. Clear cache on your site.

Congratulation! You have completed the installation process.
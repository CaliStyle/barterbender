<?php
 
defined('PHPFOX') or exit('NO DICE!'); 

?>
{_p var="We are processing your photo, please hold on."}
{img theme='ajax/small.gif'}